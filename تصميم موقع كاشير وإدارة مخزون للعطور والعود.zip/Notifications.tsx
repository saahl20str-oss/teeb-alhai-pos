import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import {
  Bell, AlertTriangle, CheckCircle, Trash2, Clock, Send,
  MessageCircle, Mail, Package, RefreshCw, Loader2, BellOff, X
} from "lucide-react";
import { cn } from "@/lib/utils";

type Notification = {
  id: number; type: string; title: string; message: string;
  productId?: number | null; isRead: boolean;
  snoozedUntil?: Date | null; sentToSupplier?: boolean;
  createdAt: Date;
};

export default function Notifications() {
  const utils = trpc.useUtils();
  const [supplierDialog, setSupplierDialog] = useState<Notification | null>(null);
  const [supplierMsg, setSupplierMsg] = useState("");
  const [supplierEmail, setSupplierEmail] = useState("");
  const [supplierWhatsapp, setSupplierWhatsapp] = useState("");
  const [showAll, setShowAll] = useState(false);

  const { data: notifications = [], isLoading } = trpc.notifications.list.useQuery({ unreadOnly: false });

  const markRead = trpc.notifications.markRead.useMutation({
    onSuccess: () => utils.notifications.list.invalidate(),
  });

  const markAllRead = trpc.notifications.markAllRead.useMutation({
    onSuccess: () => { toast.success("تم تحديد جميع الإشعارات كمقروءة"); utils.notifications.list.invalidate(); },
  });

  const deleteNotif = trpc.notifications.delete.useMutation({
    onSuccess: () => { toast.success("تم حذف الإشعار"); utils.notifications.list.invalidate(); },
    onError: (e) => toast.error(e.message),
  });

  const snooze = trpc.notifications.snooze.useMutation({
    onSuccess: () => { toast.success("تم تأجيل الإشعار لمدة ساعة"); utils.notifications.list.invalidate(); },
    onError: (e) => toast.error(e.message),
  });

  const displayed = showAll ? notifications : notifications.filter((n) => !n.isRead);
  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const openSupplierDialog = (notif: Notification) => {
    setSupplierDialog(notif);
    setSupplierMsg(
      `السلام عليكم،\n\nنحتاج إلى إعادة تزويدنا بالمنتج التالي:\n\n` +
      `${notif.message}\n\n` +
      `الكمية المطلوبة: [أدخل الكمية]\n\n` +
      `نرجو التواصل في أقرب وقت ممكن.\n\nشكراً`
    );
  };

  const handleSendWhatsApp = () => {
    if (!supplierWhatsapp.trim()) { toast.error("يرجى إدخال رقم واتساب المورد"); return; }
    const msg = encodeURIComponent(supplierMsg);
    const phone = supplierWhatsapp.replace(/\D/g, "");
    window.open(`https://wa.me/${phone}?text=${msg}`, "_blank");
    toast.success("تم فتح واتساب");
    if (supplierDialog) markRead.mutate({ id: supplierDialog.id });
    setSupplierDialog(null);
  };

  const handleSendEmail = () => {
    if (!supplierEmail.trim()) { toast.error("يرجى إدخال إيميل المورد"); return; }
    const subject = encodeURIComponent(`طلب تزويد - ${supplierDialog?.title}`);
    const body = encodeURIComponent(supplierMsg);
    window.open(`mailto:${supplierEmail}?subject=${subject}&body=${body}`, "_blank");
    toast.success("تم فتح تطبيق الإيميل");
    if (supplierDialog) markRead.mutate({ id: supplierDialog.id });
    setSupplierDialog(null);
  };

  const typeIcon = (type: string) => {
    if (type === "low_stock") return <AlertTriangle className="w-4 h-4 text-orange-400" />;
    if (type === "out_of_stock") return <Package className="w-4 h-4 text-red-400" />;
    if (type === "sale") return <CheckCircle className="w-4 h-4 text-green-400" />;
    return <Bell className="w-4 h-4 text-blue-400" />;
  };

  const typeBg = (type: string, isRead: boolean) => {
    if (isRead) return "bg-muted/10 border-border/30";
    if (type === "low_stock") return "bg-orange-900/10 border-orange-700/30";
    if (type === "out_of_stock") return "bg-red-900/10 border-red-700/30";
    return "bg-amber-900/10 border-amber-700/30";
  };

  return (
    <div className="space-y-5" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-amber-300 flex items-center gap-2" style={{ fontFamily: "'Amiri', serif" }}>
            <Bell className="w-6 h-6" />
            مركز الإشعارات
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            {unreadCount > 0 ? <><strong className="text-amber-300">{unreadCount}</strong> إشعار غير مقروء</> : "جميع الإشعارات مقروءة"}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="border-amber-600/40 text-amber-400 gap-1.5" onClick={() => setShowAll(!showAll)}>
            {showAll ? <><BellOff className="w-3.5 h-3.5" /> غير المقروءة فقط</> : <><Bell className="w-3.5 h-3.5" /> جميع الإشعارات</>}
          </Button>
          {unreadCount > 0 && (
            <Button variant="outline" size="sm" className="border-green-600/40 text-green-400 gap-1.5" onClick={() => markAllRead.mutate()}>
              <CheckCircle className="w-3.5 h-3.5" /> تحديد الكل كمقروء
            </Button>
          )}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "غير مقروءة", count: unreadCount, color: "text-amber-400" },
          { label: "نقص مخزون", count: notifications.filter(n => n.type === "low_stock" && !n.isRead).length, color: "text-orange-400" },
          { label: "نفاد مخزون", count: notifications.filter(n => n.type === "out_of_stock" && !n.isRead).length, color: "text-red-400" },
        ].map((s) => (
          <Card key={s.label} className="border-amber-800/30 bg-card">
            <CardContent className="p-3 text-center">
              <p className={`text-2xl font-bold ${s.color}`}>{s.count}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{s.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Notifications list */}
      {isLoading ? (
        <div className="flex items-center justify-center py-16"><Loader2 className="w-8 h-8 animate-spin text-amber-400" /></div>
      ) : displayed.length === 0 ? (
        <Card className="border-amber-800/30 bg-card">
          <CardContent className="py-16 text-center">
            <Bell className="w-12 h-12 text-muted-foreground mx-auto mb-3 opacity-30" />
            <p className="text-muted-foreground">{showAll ? "لا توجد إشعارات" : "لا توجد إشعارات غير مقروءة"}</p>
            {!showAll && (
              <Button variant="outline" size="sm" className="mt-3 border-amber-600/40 text-amber-400" onClick={() => setShowAll(true)}>
                عرض جميع الإشعارات
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {displayed.map((notif) => (
            <Card key={notif.id} className={cn("border transition-all", typeBg(notif.type, notif.isRead))}>
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <div className="mt-0.5 shrink-0">{typeIcon(notif.type)}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className={cn("font-medium text-sm", notif.isRead ? "text-muted-foreground" : "text-foreground")}>
                          {notif.title}
                          {!notif.isRead && <span className="inline-block w-2 h-2 rounded-full bg-amber-400 mr-2 mb-0.5" />}
                        </p>
                        <p className="text-xs text-muted-foreground mt-0.5">{notif.message}</p>
                        {notif.productId && (
                          <div className="flex items-center gap-2 mt-1.5">
                            <Badge variant="outline" className="text-xs border-amber-600/40 text-amber-400">
                              منتج #{notif.productId}
                            </Badge>
                          </div>
                        )}
                        <p className="text-xs text-muted-foreground/60 mt-1.5">
                          {new Date(notif.createdAt).toLocaleString("ar-SA")}
                        </p>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        {/* Send to supplier */}
                        {(notif.type === "low_stock" || notif.type === "out_of_stock") && (
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-7 w-7 text-blue-400 hover:bg-blue-900/20"
                            title="إرسال للمورد"
                            onClick={() => openSupplierDialog(notif as Notification)}
                          >
                            <Send className="w-3.5 h-3.5" />
                          </Button>
                        )}
                        {/* Snooze */}
                        {!notif.isRead && (
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-7 w-7 text-amber-400 hover:bg-amber-900/20"
                            title="تأجيل ساعة"
                            onClick={() => snooze.mutate({ id: notif.id, hours: 1 })}
                          >
                            <Clock className="w-3.5 h-3.5" />
                          </Button>
                        )}
                        {/* Mark read */}
                        {!notif.isRead && (
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-7 w-7 text-green-400 hover:bg-green-900/20"
                            title="تحديد كمقروء"
                            onClick={() => markRead.mutate({ id: notif.id })}
                          >
                            <CheckCircle className="w-3.5 h-3.5" />
                          </Button>
                        )}
                        {/* Delete */}
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-7 w-7 text-red-400/60 hover:bg-red-900/20 hover:text-red-400"
                          title="حذف"
                          onClick={() => deleteNotif.mutate({ id: notif.id })}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Supplier Contact Dialog */}
      <Dialog open={!!supplierDialog} onOpenChange={(open) => { if (!open) setSupplierDialog(null); }}>
        <DialogContent className="border-amber-800/30 bg-card max-w-lg" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-amber-300 flex items-center gap-2">
              <Send className="w-5 h-5" />
              إرسال طلب للمورد
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
                {supplierDialog && (
              <div className="p-3 rounded-lg bg-orange-900/20 border border-orange-700/30">
                <p className="text-sm text-orange-300 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4" />
                  {supplierDialog.title}
                </p>
              </div>
            )}
            <div>
              <Label className="text-xs text-muted-foreground mb-1 block">نص الرسالة</Label>
              <Textarea
                value={supplierMsg}
                onChange={(e) => setSupplierMsg(e.target.value)}
                rows={6}
                className="bg-input border-border resize-none text-sm"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs text-muted-foreground mb-1 block flex items-center gap-1">
                  <MessageCircle className="w-3 h-3 text-green-400" /> واتساب المورد
                </Label>
                <Input
                  value={supplierWhatsapp}
                  onChange={(e) => setSupplierWhatsapp(e.target.value)}
                  placeholder="05xxxxxxxx"
                  className="bg-input border-border"
                  dir="ltr"
                />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground mb-1 block flex items-center gap-1">
                  <Mail className="w-3 h-3 text-blue-400" /> إيميل المورد
                </Label>
                <Input
                  value={supplierEmail}
                  onChange={(e) => setSupplierEmail(e.target.value)}
                  placeholder="supplier@example.com"
                  className="bg-input border-border"
                  dir="ltr"
                />
              </div>
            </div>
          </div>
          <DialogFooter className="gap-2 mt-2">
            <Button variant="outline" className="border-amber-600/40" onClick={() => setSupplierDialog(null)}>
              <X className="w-4 h-4 ml-1" /> إلغاء
            </Button>
            <Button onClick={handleSendEmail} variant="outline" className="border-blue-600/40 text-blue-400 hover:bg-blue-900/20 gap-1.5">
              <Mail className="w-4 h-4" /> إرسال إيميل
            </Button>
            <Button onClick={handleSendWhatsApp} className="bg-green-700 hover:bg-green-600 text-white gap-1.5">
              <MessageCircle className="w-4 h-4" /> إرسال واتساب
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
