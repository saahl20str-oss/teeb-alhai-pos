import { useState, useEffect, useRef } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Settings as SettingsIcon, Save, Building2, Phone, MapPin, Stamp, Upload, Loader2, Mail, Globe, Send, CheckCircle, Eye, EyeOff } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";

const DEFAULT_LOGO = "/manus-storage/teeb-logo_ab292981.jpeg";

const CURRENCIES = [
  { code: "SAR", symbol: "ريال", name: "الريال السعودي", flag: "🇸🇦" },
  { code: "AED", symbol: "درهم", name: "الدرهم الإماراتي", flag: "🇦🇪" },
  { code: "KWD", symbol: "دينار", name: "الدينار الكويتي", flag: "🇰🇼" },
  { code: "BHD", symbol: "دينار", name: "الدينار البحريني", flag: "🇧🇭" },
  { code: "QAR", symbol: "ريال", name: "الريال القطري", flag: "🇶🇦" },
  { code: "OMR", symbol: "ريال", name: "الريال العُماني", flag: "🇴🇲" },
  { code: "JOD", symbol: "دينار", name: "الدينار الأردني", flag: "🇯🇴" },
  { code: "EGP", symbol: "جنيه", name: "الجنيه المصري", flag: "🇪🇬" },
  { code: "USD", symbol: "$", name: "الدولار الأمريكي", flag: "🇺🇸" },
  { code: "EUR", symbol: "€", name: "اليورو", flag: "🇪🇺" },
  { code: "GBP", symbol: "£", name: "الجنيه الإسترليني", flag: "🇬🇧" },
];

export default function Settings() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { data: settings, isLoading, refetch } = trpc.shop.getSettings.useQuery();

  const [smtpForm, setSmtpForm] = useState({ smtpEmail: "", smtpPassword: "", smtpFromName: "", testTo: "" });
  const [showSmtpPass, setShowSmtpPass] = useState(false);

  const saveSmtpMutation = trpc.shop.saveSmtp.useMutation({
    onSuccess: () => toast.success("تم حفظ إعدادات الإيميل ✓"),
    onError: (e) => toast.error("فشل الحفظ: " + e.message),
  });

  const testSmtpMutation = trpc.shop.testSmtp.useMutation({
    onSuccess: () => toast.success("✅ تم إرسال إيميل الاختبار بنجاح! تحقق من صندوق الوارد."),
    onError: (e) => toast.error("فشل الاختبار: " + e.message),
  });

  const [form, setForm] = useState({
    shopName: "طيب الحي للعود والأدهان",
    shopNameEn: "Teeb Al Hai",
    address: "",
    phone: "",
    email: "",
    logoUrl: DEFAULT_LOGO,
    stampText: "طيب الحي للعود والأدهان",
    taxNumber: "",
    currencyCode: "SAR",
    currencySymbol: "ريال",
    supplierEmail: "",
    supplierWhatsapp: "",
  });

  useEffect(() => {
    if (settings) {
      setSmtpForm({
        smtpEmail: settings.smtpEmail ?? "",
        smtpPassword: settings.smtpPassword ?? "",
        smtpFromName: settings.smtpFromName ?? "",
        testTo: "",
      });
      setForm({
        shopName: settings.shopName ?? "طيب الحي للعود والأدهان",
        shopNameEn: settings.shopNameEn ?? "Teeb Al Hai",
        address: settings.address ?? "",
        phone: settings.phone ?? "",
        email: settings.email ?? "",
        logoUrl: settings.logoUrl ?? DEFAULT_LOGO,
        stampText: settings.stampText ?? "طيب الحي للعود والأدهان",
        taxNumber: settings.taxNumber ?? "",
        currencyCode: settings.currencyCode ?? "SAR",
        currencySymbol: settings.currencySymbol ?? "ريال",
        supplierEmail: settings.supplierEmail ?? "",
        supplierWhatsapp: settings.supplierWhatsapp ?? "",
      });
    }
  }, [settings]);

  const updateMutation = trpc.shop.updateSettings.useMutation({
    onSuccess: () => { toast.success("تم حفظ الإعدادات بنجاح ✓"); refetch(); },
    onError: (e) => toast.error(e.message),
  });

  const uploadLogoMutation = trpc.shop.uploadLogo.useMutation({
    onSuccess: (data) => {
      setForm((f) => ({ ...f, logoUrl: data.url }));
      toast.success("تم رفع الشعار بنجاح ✓");
      refetch();
    },
    onError: (e) => toast.error("فشل رفع الشعار: " + e.message),
  });

  const f = (key: keyof typeof form, val: string) => setForm((p) => ({ ...p, [key]: val }));

  const handleCurrencyChange = (code: string) => {
    const currency = CURRENCIES.find((c) => c.code === code);
    if (currency) setForm((prev) => ({ ...prev, currencyCode: code, currencySymbol: currency.symbol }));
  };

  const handleLogoFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) { toast.error("حجم الصورة يجب أن يكون أقل من 2 ميجابايت"); return; }
    const reader = new FileReader();
    reader.onload = (ev) => {
      const base64 = (ev.target?.result as string).split(",")[1];
      if (base64) uploadLogoMutation.mutate({ base64, mimeType: file.type });
    };
    reader.readAsDataURL(file);
  };

  if (!isAdmin) {
    return (
      <div className="flex items-center justify-center h-64" dir="rtl">
        <div className="text-center text-muted-foreground">
          <SettingsIcon className="w-12 h-12 mx-auto mb-3 text-amber-500/50" />
          <p className="text-lg font-semibold">صلاحية المدير مطلوبة</p>
          <p className="text-sm mt-1">هذه الصفحة متاحة للمدير فقط</p>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-3xl" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-amber-300 flex items-center gap-2" style={{ fontFamily: "'Amiri', serif" }}>
            <SettingsIcon className="w-6 h-6" />
            إعدادات المحل
          </h1>
          <p className="text-muted-foreground text-sm mt-1">تخصيص هوية المحل والفواتير والعملة</p>
        </div>
        <Button
          onClick={() => updateMutation.mutate(form)}
          disabled={updateMutation.isPending}
          className="bg-amber-600 hover:bg-amber-500 text-white gap-2"
        >
          {updateMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          حفظ
        </Button>
      </div>

      {/* Logo */}
      <Card className="border-amber-800/30 bg-card">
        <CardHeader className="pb-3">
          <CardTitle className="text-base text-amber-300 flex items-center gap-2">
            <Building2 className="w-4 h-4" />
            شعار المحل
          </CardTitle>
        </CardHeader>
        <CardContent className="flex items-center gap-6">
          <div className="w-24 h-24 rounded-full overflow-hidden border-2 border-amber-500/60 shrink-0 shadow-lg shadow-amber-900/40 bg-white">
            <img
              src={form.logoUrl || DEFAULT_LOGO}
              alt="شعار المحل"
              className="w-full h-full object-contain"
              onError={(e) => { (e.target as HTMLImageElement).src = DEFAULT_LOGO; }}
            />
          </div>
          <div className="flex-1 space-y-3">
            <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleLogoFile} />
            <Button
              type="button"
              variant="outline"
              onClick={() => fileInputRef.current?.click()}
              disabled={uploadLogoMutation.isPending}
              className="gap-2 border-amber-600/40 hover:bg-amber-900/20 text-amber-300"
            >
              {uploadLogoMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
              رفع صورة الشعار
            </Button>
            <p className="text-xs text-muted-foreground">PNG, JPG, SVG — حجم أقصى 2 ميجابايت</p>
            <div>
              <Label className="text-xs text-muted-foreground mb-1 block">أو أدخل رابط الشعار مباشرة</Label>
              <Input
                value={form.logoUrl}
                onChange={(e) => f("logoUrl", e.target.value)}
                placeholder="https://example.com/logo.png"
                className="bg-input border-border text-sm"
                dir="ltr"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Shop Info */}
      <Card className="border-amber-800/30 bg-card">
        <CardHeader className="pb-3">
          <CardTitle className="text-base text-amber-300 flex items-center gap-2">
            <Building2 className="w-4 h-4" />
            بيانات المحل
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-xs text-muted-foreground mb-1 block">اسم المحل (عربي)</Label>
              <Input value={form.shopName} onChange={(e) => f("shopName", e.target.value)} className="bg-input border-border" />
            </div>
            <div>
              <Label className="text-xs text-muted-foreground mb-1 block">اسم المحل (إنجليزي)</Label>
              <Input value={form.shopNameEn} onChange={(e) => f("shopNameEn", e.target.value)} className="bg-input border-border" dir="ltr" />
            </div>
          </div>
          <div>
            <Label className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
              <MapPin className="w-3 h-3" /> العنوان
            </Label>
            <Input value={form.address} onChange={(e) => f("address", e.target.value)} placeholder="المدينة، الحي، الشارع" className="bg-input border-border" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                <Phone className="w-3 h-3" /> رقم الهاتف
              </Label>
              <Input value={form.phone} onChange={(e) => f("phone", e.target.value)} placeholder="+966 5X XXX XXXX" className="bg-input border-border" dir="ltr" />
            </div>
            <div>
              <Label className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                <Mail className="w-3 h-3" /> البريد الإلكتروني
              </Label>
              <Input value={form.email} onChange={(e) => f("email", e.target.value)} placeholder="info@teeb.com" className="bg-input border-border" dir="ltr" type="email" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                <Stamp className="w-3 h-3" /> نص الختم على الفاتورة
              </Label>
              <Input value={form.stampText} onChange={(e) => f("stampText", e.target.value)} placeholder="طيب الحي للعود والأدهان" className="bg-input border-border" />
            </div>
            <div>
              <Label className="text-xs text-muted-foreground mb-1 block">الرقم الضريبي</Label>
              <Input value={form.taxNumber} onChange={(e) => f("taxNumber", e.target.value)} placeholder="300XXXXXXXXX" className="bg-input border-border" dir="ltr" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Currency */}
      <Card className="border-amber-800/30 bg-card">
        <CardHeader className="pb-3">
          <CardTitle className="text-base text-amber-300 flex items-center gap-2">
            <Globe className="w-4 h-4" />
            العملة — تُطبَّق تلقائياً في كافة أنحاء النظام
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-xs text-muted-foreground mb-1 block">اختر العملة</Label>
              <Select value={form.currencyCode} onValueChange={handleCurrencyChange}>
                <SelectTrigger className="bg-input border-border">
                  <SelectValue placeholder="اختر العملة" />
                </SelectTrigger>
                <SelectContent>
                  {CURRENCIES.map((c) => (
                    <SelectItem key={c.code} value={c.code}>
                      <span className="flex items-center gap-2">
                        <span>{c.flag}</span>
                        <span>{c.name}</span>
                        <span className="text-muted-foreground text-xs">({c.symbol})</span>
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground mb-1 block">رمز العملة (للعرض)</Label>
              <Input
                value={form.currencySymbol}
                onChange={(e) => f("currencySymbol", e.target.value)}
                placeholder="ريال"
                className="bg-input border-border"
                maxLength={10}
              />
            </div>
          </div>
          <div className="bg-amber-900/20 rounded-lg p-3 border border-amber-700/30">
            <p className="text-sm text-amber-300">
              <strong>معاينة:</strong> سعر المنتج سيظهر هكذا: <span className="font-bold text-amber-200">١٢٥.٠٠ {form.currencySymbol}</span>
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Supplier Contact */}
      <Card className="border-amber-800/30 bg-card">
        <CardHeader className="pb-3">
          <CardTitle className="text-base text-amber-300 flex items-center gap-2">
            <Phone className="w-4 h-4" />
            بيانات المورد (لإرسال تنبيهات نقص المخزون)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                <Mail className="w-3 h-3" /> بريد المورد
              </Label>
              <Input
                value={form.supplierEmail}
                onChange={(e) => f("supplierEmail", e.target.value)}
                placeholder="supplier@example.com"
                className="bg-input border-border"
                dir="ltr"
                type="email"
              />
            </div>
            <div>
              <Label className="text-xs text-muted-foreground mb-1 block">واتساب المورد</Label>
              <Input
                value={form.supplierWhatsapp}
                onChange={(e) => f("supplierWhatsapp", e.target.value)}
                placeholder="+966 5X XXX XXXX"
                className="bg-input border-border"
                dir="ltr"
              />
            </div>
          </div>
          <p className="text-xs text-muted-foreground">
            عند نقص مخزون أي منتج، يمكنك إرسال تنبيه للمورد مباشرة من صفحة الإشعارات
          </p>
        </CardContent>
      </Card>

      {/* SMTP Email Settings */}
      <Card className="border-amber-800/30 bg-card">
        <CardHeader className="pb-3">
          <CardTitle className="text-base text-amber-300 flex items-center gap-2">
            <Mail className="w-4 h-4" />
            إعدادات الإيميل (Gmail)
          </CardTitle>
          <p className="text-xs text-muted-foreground mt-1">
            أدخل بيانات Gmail لإرسال إيميلات تلقائية للمورد والعملاء. تحتاج إلى تفعيل <strong>App Password</strong> من إعدادات Google.
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                <Mail className="w-3 h-3" /> بريد Gmail المُرسِل
              </Label>
              <Input
                value={smtpForm.smtpEmail}
                onChange={(e) => setSmtpForm(p => ({ ...p, smtpEmail: e.target.value }))}
                placeholder="yourshop@gmail.com"
                className="bg-input border-border"
                dir="ltr"
                type="email"
              />
            </div>
            <div>
              <Label className="text-xs text-muted-foreground mb-1 block">اسم المُرسِل (يظهر للمستلم)</Label>
              <Input
                value={smtpForm.smtpFromName}
                onChange={(e) => setSmtpForm(p => ({ ...p, smtpFromName: e.target.value }))}
                placeholder="طيب الحي للعود والأدهان"
                className="bg-input border-border"
              />
            </div>
          </div>
          <div>
            <Label className="text-xs text-muted-foreground mb-1 block">App Password (كلمة مرور التطبيق - 16 حرف)</Label>
            <div className="relative">
              <Input
                value={smtpForm.smtpPassword}
                onChange={(e) => setSmtpForm(p => ({ ...p, smtpPassword: e.target.value }))}
                placeholder="xxxx xxxx xxxx xxxx"
                className="bg-input border-border pr-10"
                dir="ltr"
                type={showSmtpPass ? "text" : "password"}
              />
              <button
                type="button"
                className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-amber-300"
                onClick={() => setShowSmtpPass(p => !p)}
              >
                {showSmtpPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              احصل عليها من: <a href="https://myaccount.google.com/apppasswords" target="_blank" rel="noopener noreferrer" className="text-amber-400 underline">myaccount.google.com/apppasswords</a>
            </p>
          </div>
          <div className="flex gap-3 items-end">
            <div className="flex-1">
              <Label className="text-xs text-muted-foreground mb-1 block">إيميل الاختبار (لاختبار الإرسال)</Label>
              <Input
                value={smtpForm.testTo}
                onChange={(e) => setSmtpForm(p => ({ ...p, testTo: e.target.value }))}
                placeholder="test@example.com"
                className="bg-input border-border"
                dir="ltr"
                type="email"
              />
            </div>
            <Button
              variant="outline"
              className="border-green-600/40 text-green-400 hover:bg-green-900/20 gap-2 shrink-0"
              disabled={testSmtpMutation.isPending || !smtpForm.smtpEmail || !smtpForm.smtpPassword || !smtpForm.testTo}
              onClick={() => testSmtpMutation.mutate({ smtpEmail: smtpForm.smtpEmail, smtpPassword: smtpForm.smtpPassword, testTo: smtpForm.testTo })}
            >
              {testSmtpMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
              اختبار الإرسال
            </Button>
          </div>
          <Button
            onClick={() => saveSmtpMutation.mutate({ smtpEmail: smtpForm.smtpEmail, smtpPassword: smtpForm.smtpPassword, smtpFromName: smtpForm.smtpFromName })}
            disabled={saveSmtpMutation.isPending || !smtpForm.smtpEmail || !smtpForm.smtpPassword}
            className="bg-amber-700 hover:bg-amber-600 text-white gap-2"
          >
            {saveSmtpMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            حفظ إعدادات الإيميل
          </Button>
        </CardContent>
      </Card>

      <Separator className="border-amber-800/30" />

      <Button
        onClick={() => updateMutation.mutate(form)}
        disabled={updateMutation.isPending}
        className="w-full bg-amber-600 hover:bg-amber-500 text-white font-bold py-5 text-base gap-2 shadow-lg shadow-amber-900/40"
      >
        {updateMutation.isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
        {updateMutation.isPending ? "جاري الحفظ..." : "حفظ جميع الإعدادات"}
      </Button>
    </div>
  );
}
