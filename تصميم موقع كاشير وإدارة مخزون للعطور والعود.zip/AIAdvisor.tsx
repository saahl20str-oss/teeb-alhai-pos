import { useState, useRef, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Bot, Send, User, Sparkles, RefreshCw, TrendingUp, Package,
  AlertTriangle, BarChart3, Lightbulb, Target, ShoppingCart, Loader2
} from "lucide-react";
import { Streamdown } from "streamdown";
import { cn } from "@/lib/utils";

type Message = { role: "user" | "assistant"; content: string };

const QUICK_ACTIONS = [
  { icon: TrendingUp, label: "تحليل المبيعات", q: "حلل أداء مبيعاتي خلال الفترة الأخيرة وأخبرني بالاتجاهات الرئيسية والمنتجات الأكثر والأقل مبيعاً" },
  { icon: Package, label: "تقييم المخزون", q: "قيّم وضع مخزوني الحالي وأخبرني بالمنتجات التي تحتاج إعادة طلب وتلك التي لديها فائض" },
  { icon: AlertTriangle, label: "تنبيهات عاجلة", q: "ما هي أهم التنبيهات والمشاكل العاجلة التي تحتاج انتباهي الآن في المحل؟" },
  { icon: Target, label: "استراتيجية التسعير", q: "بناءً على بيانات مبيعاتي، هل أسعاري مناسبة؟ وما هي توصياتك لتحسين هامش الربح؟" },
  { icon: Lightbulb, label: "فرص النمو", q: "ما هي أفضل فرص النمو المتاحة لمحلي بناءً على بيانات المبيعات والمخزون الحالية؟" },
  { icon: ShoppingCart, label: "تحسين الكاشير", q: "كيف يمكنني تحسين تجربة الشراء وزيادة متوسط قيمة الفاتورة في محلي؟" },
  { icon: BarChart3, label: "تقرير شهري", q: "أعطني تقريراً شاملاً عن أداء المحل هذا الشهر مع مقارنة بالشهر السابق وتوصيات للتحسين" },
  { icon: Sparkles, label: "توصيات موسمية", q: "ما هي التوصيات الموسمية لمحل العطور والعود؟ وكيف أستعد للمواسم القادمة؟" },
];

export default function AIAdvisor() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Load real data for context display
  const { data: dayStats } = trpc.analytics.stats.useQuery({ period: "day" });
  const { data: monthStats } = trpc.analytics.stats.useQuery({ period: "month" });
  const { data: topProducts = [] } = trpc.analytics.topProducts.useQuery({ limit: 5 });
  const { data: inventoryValue } = trpc.analytics.inventoryValue.useQuery();
  const { data: notifications = [] } = trpc.notifications.list.useQuery({ unreadOnly: true });
  const { data: settings } = trpc.shop.getSettings.useQuery();

  const currency = settings?.currencySymbol ?? "ريال";
  const lowStockAlerts = notifications.filter(n => n.type === "low_stock" || n.type === "out_of_stock");

  const chatMutation = trpc.ai.chat.useMutation({
    onSuccess: (data) => {
      setMessages((prev) => [...prev, { role: "assistant", content: typeof data.content === "string" ? data.content : String(data.content) }]);
    },
    onError: (e) => {
      setMessages((prev) => [...prev, { role: "assistant", content: `عذراً، حدث خطأ: ${e.message}` }]);
    },
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = (text?: string) => {
    const msg = text ?? input.trim();
    if (!msg || chatMutation.isPending) return;
    const newMessages: Message[] = [...messages, { role: "user", content: msg }];
    setMessages(newMessages);
    setInput("");
    chatMutation.mutate({ messages: newMessages });
  };

  const clearChat = () => setMessages([]);

  return (
    <div className="flex gap-4 h-[calc(100vh-120px)]" dir="rtl">
      {/* Left: Data Context Panel */}
      <div className="hidden xl:flex flex-col w-64 shrink-0 space-y-3 overflow-y-auto">
        <Card className="border-amber-800/30 bg-card">
          <CardHeader className="pb-2 pt-3 px-3">
            <CardTitle className="text-xs text-amber-400 flex items-center gap-1.5">
              <BarChart3 className="w-3.5 h-3.5" /> بيانات المحل الحالية
            </CardTitle>
          </CardHeader>
          <CardContent className="px-3 pb-3 space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-muted-foreground">مبيعات اليوم</span>
              <span className="text-amber-400 font-bold">{(dayStats?.totalRevenue ?? 0).toFixed(0)} {currency}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-muted-foreground">فواتير اليوم</span>
              <span className="text-amber-400 font-bold">{dayStats?.totalSales ?? 0}</span>
            </div>
            <Separator className="bg-amber-800/20" />
            <div className="flex justify-between text-xs">
              <span className="text-muted-foreground">مبيعات الشهر</span>
              <span className="text-green-400 font-bold">{(monthStats?.totalRevenue ?? 0).toFixed(0)} {currency}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-muted-foreground">فواتير الشهر</span>
              <span className="text-green-400 font-bold">{monthStats?.totalSales ?? 0}</span>
            </div>
            <Separator className="bg-amber-800/20" />
            <div className="flex justify-between text-xs">
              <span className="text-muted-foreground">قيمة المخزون</span>
              <span className="text-blue-400 font-bold">{(inventoryValue?.sellingValue ?? 0).toFixed(0)} {currency}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-muted-foreground">هامش الربح</span>
              <span className="text-purple-400 font-bold">
                {inventoryValue ? ((inventoryValue.sellingValue - inventoryValue.costValue) / Math.max(inventoryValue.sellingValue, 1) * 100).toFixed(1) : 0}%
              </span>
            </div>
          </CardContent>
        </Card>

        {/* Top products */}
        {topProducts.length > 0 && (
          <Card className="border-amber-800/30 bg-card">
            <CardHeader className="pb-2 pt-3 px-3">
              <CardTitle className="text-xs text-amber-400 flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5" /> أكثر المنتجات مبيعاً
              </CardTitle>
            </CardHeader>
            <CardContent className="px-3 pb-3 space-y-1.5">
              {topProducts.slice(0, 5).map((p, i) => (
                <div key={p.productId} className="flex items-center gap-2">
                  <span className="w-4 h-4 rounded-full bg-amber-900/40 text-amber-400 text-xs flex items-center justify-center font-bold shrink-0">{i + 1}</span>
                  <span className="text-xs truncate flex-1 text-muted-foreground">{p.productName}</span>
                  <span className="text-xs text-amber-400 shrink-0">{p.totalQty}</span>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {/* Alerts */}
        {lowStockAlerts.length > 0 && (
          <Card className="border-orange-700/30 bg-orange-900/10">
            <CardHeader className="pb-2 pt-3 px-3">
              <CardTitle className="text-xs text-orange-400 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5" /> تنبيهات نشطة ({lowStockAlerts.length})
              </CardTitle>
            </CardHeader>
            <CardContent className="px-3 pb-3 space-y-1">
              {lowStockAlerts.slice(0, 4).map((n) => (
                <p key={n.id} className="text-xs text-orange-300/80 truncate">• {n.title}</p>
              ))}
            </CardContent>
          </Card>
        )}

        {/* Quick actions */}
        <Card className="border-amber-800/30 bg-card">
          <CardHeader className="pb-2 pt-3 px-3">
            <CardTitle className="text-xs text-amber-400">أسئلة سريعة</CardTitle>
          </CardHeader>
          <CardContent className="px-3 pb-3 space-y-1.5">
            {QUICK_ACTIONS.slice(0, 4).map((a) => (
              <button
                key={a.label}
                onClick={() => sendMessage(a.q)}
                disabled={chatMutation.isPending}
                className="w-full text-right text-xs px-2.5 py-2 rounded-lg border border-amber-700/30 text-amber-300/70 bg-amber-900/10 hover:bg-amber-900/20 hover:text-amber-300 transition-colors flex items-center gap-1.5"
              >
                <a.icon className="w-3 h-3 shrink-0" />
                {a.label}
              </button>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Right: Chat */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <div className="flex items-center justify-between mb-3 shrink-0">
          <div>
            <h1 className="text-xl font-bold text-amber-300 flex items-center gap-2" style={{ fontFamily: "'Amiri', serif" }}>
              <Bot className="w-5 h-5" />
              المستشار الذكي لطيب الحي
            </h1>
            <p className="text-muted-foreground text-xs mt-0.5">يحلل بيانات محلك الفعلية ويقدم توصيات مخصصة</p>
          </div>
          {messages.length > 0 && (
            <Button variant="ghost" size="sm" onClick={clearChat} className="gap-1 text-muted-foreground hover:text-amber-300 text-xs">
              <RefreshCw className="w-3 h-3" /> محادثة جديدة
            </Button>
          )}
        </div>

        {/* Chat area */}
        <Card className="flex-1 border-amber-800/30 bg-card flex flex-col overflow-hidden">
          <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
            {/* Welcome */}
            {messages.length === 0 && (
              <div className="flex flex-col items-center justify-center h-full text-center py-6">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-amber-900/50 to-amber-700/30 flex items-center justify-center mb-4 border border-amber-600/40 shadow-lg shadow-amber-900/30">
                  <Bot className="w-8 h-8 text-amber-400" />
                </div>
                <h2 className="text-lg font-bold text-amber-300 mb-1" style={{ fontFamily: "'Amiri', serif" }}>مرحباً، أنا مستشارك الذكي</h2>
                <p className="text-muted-foreground text-sm max-w-sm mb-5">
                  أحلل بيانات مبيعاتك ومخزونك الفعلية وأقدم لك توصيات دقيقة ومخصصة لمحل طيب الحي.
                </p>
                {/* Quick action grid */}
                <div className="grid grid-cols-2 gap-2 max-w-lg w-full">
                  {QUICK_ACTIONS.map((a) => (
                    <button
                      key={a.label}
                      onClick={() => sendMessage(a.q)}
                      className="flex items-center gap-2 px-3 py-2.5 rounded-xl text-xs border border-amber-700/30 text-amber-300/80 bg-amber-900/10 hover:bg-amber-900/25 hover:border-amber-600/50 transition-all text-right"
                    >
                      <a.icon className="w-3.5 h-3.5 shrink-0 text-amber-400" />
                      {a.label}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Messages */}
            {messages.map((msg, idx) => (
              <div key={idx} className={cn("flex gap-3", msg.role === "user" ? "flex-row-reverse" : "flex-row")}>
                <div className={cn("w-8 h-8 rounded-full flex items-center justify-center shrink-0 mt-1", msg.role === "user" ? "bg-amber-600/30 border border-amber-600/50" : "bg-blue-900/30 border border-blue-700/50")}>
                  {msg.role === "user" ? <User className="w-4 h-4 text-amber-400" /> : <Bot className="w-4 h-4 text-blue-400" />}
                </div>
                <div className={cn("max-w-[82%] rounded-2xl px-4 py-3 text-sm", msg.role === "user" ? "bg-amber-900/30 border border-amber-700/40 text-amber-100 rounded-tr-sm" : "bg-card border border-border text-foreground rounded-tl-sm")}>
                  {msg.role === "assistant" ? (
                    <Streamdown className="prose prose-invert prose-sm max-w-none [&_ul]:list-disc [&_ul]:pr-4 [&_ol]:list-decimal [&_ol]:pr-4 [&_strong]:text-amber-300 [&_h3]:text-amber-300 [&_h4]:text-amber-300">{msg.content}</Streamdown>
                  ) : (
                    <p>{msg.content}</p>
                  )}
                </div>
              </div>
            ))}

            {/* Loading */}
            {chatMutation.isPending && (
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-full bg-blue-900/30 border border-blue-700/50 flex items-center justify-center shrink-0">
                  <Bot className="w-4 h-4 text-blue-400" />
                </div>
                <div className="bg-card border border-border rounded-2xl rounded-tl-sm px-4 py-3">
                  <div className="flex gap-1 items-center h-5">
                    <span className="w-2 h-2 bg-amber-400 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                    <span className="w-2 h-2 bg-amber-400 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                    <span className="w-2 h-2 bg-amber-400 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </CardContent>

          {/* Input */}
          <div className="p-4 border-t border-amber-800/30 shrink-0">
            <div className="flex gap-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && sendMessage()}
                placeholder="اسأل عن مبيعاتك، مخزونك، أو استراتيجية عملك..."
                className="bg-input border-border flex-1"
                disabled={chatMutation.isPending}
              />
              <Button
                onClick={() => sendMessage()}
                disabled={!input.trim() || chatMutation.isPending}
                className="bg-amber-600 hover:bg-amber-500 text-white px-4"
              >
                {chatMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              </Button>
            </div>
            <p className="text-xs text-muted-foreground mt-1.5 text-center">
              يستخدم بيانات محلك الفعلية · مبيعات اليوم: <span className="text-amber-400">{(dayStats?.totalRevenue ?? 0).toFixed(0)} {currency}</span>
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
}
