import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import { sdk } from "./sdk";
import { jwtVerify } from "jose";
import { ENV } from "./env";
import { COOKIE_NAME } from "@shared/const";
import { getDb } from "../db";
import { users } from "../../drizzle/schema";
import { eq } from "drizzle-orm";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
};

function getSessionSecret() {
  return new TextEncoder().encode(ENV.cookieSecret);
}

/**
 * Try to authenticate a request using the local email/password JWT session.
 * Returns the User row if the session is valid and the user exists in the DB.
 */
async function authenticateLocalSession(req: CreateExpressContextOptions["req"]): Promise<User | null> {
  try {
    const cookieHeader = req.headers.cookie ?? "";
    // Parse the session cookie manually
    const cookies: Record<string, string> = {};
    cookieHeader.split(";").forEach((part) => {
      const [key, ...rest] = part.trim().split("=");
      if (key) cookies[key.trim()] = decodeURIComponent(rest.join("="));
    });

    const token = cookies[COOKIE_NAME];
    if (!token) return null;

    const { payload } = await jwtVerify(token, getSessionSecret());

    // Only handle local auth sessions here
    if (!payload.localAuth) return null;

    const userId = payload.userId as number | undefined;
    if (!userId) return null;

    const db = await getDb();
    if (!db) return null;

    const result = await db.select().from(users).where(eq(users.id, userId)).limit(1);
    const user = result[0];
    if (!user) return null;

    // Check if user is active
    if ((user as User & { isActive?: boolean }).isActive === false) return null;

    return user;
  } catch {
    return null;
  }
}

export async function createContext(
  opts: CreateExpressContextOptions
): Promise<TrpcContext> {
  let user: User | null = null;

  // First, try local auth (email/password sessions)
  try {
    user = await authenticateLocalSession(opts.req);
  } catch {
    user = null;
  }

  // If not a local auth session, fall back to Manus OAuth
  if (!user) {
    try {
      user = await sdk.authenticateRequest(opts.req);
    } catch {
      user = null;
    }
  }

  return {
    req: opts.req,
    res: opts.res,
    user,
  };
}
