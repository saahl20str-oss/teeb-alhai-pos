import { useEffect, useRef, useState, useCallback } from "react";
import { Html5Qrcode, Html5QrcodeSupportedFormats } from "html5-qrcode";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Camera, CameraOff, ScanLine, Loader2, RefreshCw, ZoomIn, ZoomOut } from "lucide-react";
import { cn } from "@/lib/utils";

interface BarcodeScannerProps {
  open: boolean;
  onClose: () => void;
  onScan: (code: string) => void;
  title?: string;
  hint?: string;
}

const SCANNER_ID = "teeb-barcode-scanner";

export function BarcodeScanner({
  open,
  onClose,
  onScan,
  title = "مسح الباركود",
  hint = "وجّه الكاميرا نحو الباركود أو رمز QR",
}: BarcodeScannerProps) {
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const [isStarting, setIsStarting] = useState(false);
  const [isRunning, setIsRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastScanned, setLastScanned] = useState<string | null>(null);
  const [cameras, setCameras] = useState<{ id: string; label: string }[]>([]);
  const [selectedCamera, setSelectedCamera] = useState<string | null>(null);
  const [zoom, setZoom] = useState(1);
  const cooldownRef = useRef(false);

  const stopScanner = useCallback(async () => {
    if (scannerRef.current && isRunning) {
      try {
        await scannerRef.current.stop();
        scannerRef.current.clear();
      } catch {
        // ignore
      }
    }
    setIsRunning(false);
    setIsStarting(false);
  }, [isRunning]);

  const startScanner = useCallback(
    async (cameraId?: string) => {
      if (!document.getElementById(SCANNER_ID)) return;
      setIsStarting(true);
      setError(null);
      setLastScanned(null);

      try {
        if (!scannerRef.current) {
          scannerRef.current = new Html5Qrcode(SCANNER_ID, {
            formatsToSupport: [
              Html5QrcodeSupportedFormats.QR_CODE,
              Html5QrcodeSupportedFormats.EAN_13,
              Html5QrcodeSupportedFormats.EAN_8,
              Html5QrcodeSupportedFormats.CODE_128,
              Html5QrcodeSupportedFormats.CODE_39,
              Html5QrcodeSupportedFormats.UPC_A,
              Html5QrcodeSupportedFormats.UPC_E,
              Html5QrcodeSupportedFormats.DATA_MATRIX,
            ],
            verbose: false,
          });
        }

        // Get available cameras
        const devices = await Html5Qrcode.getCameras();
        if (devices.length === 0) {
          setError("لم يتم العثور على كاميرا. تأكد من منح الإذن للكاميرا.");
          setIsStarting(false);
          return;
        }
        setCameras(devices);

        // Prefer back camera
        const backCamera = devices.find(
          (d) =>
            d.label.toLowerCase().includes("back") ||
            d.label.toLowerCase().includes("rear") ||
            d.label.toLowerCase().includes("environment") ||
            d.label.includes("الخلفية")
        );
        const targetCamera = cameraId ?? backCamera?.id ?? devices[0]?.id;
        setSelectedCamera(targetCamera ?? null);

        await scannerRef.current.start(
          targetCamera ?? { facingMode: "environment" },
          {
            fps: 15,
            qrbox: { width: 260, height: 180 },
            aspectRatio: 1.5,
            disableFlip: false,
          },
          (decodedText) => {
            if (cooldownRef.current) return;
            cooldownRef.current = true;
            setLastScanned(decodedText);

            // Visual feedback then callback
            setTimeout(() => {
              onScan(decodedText);
              cooldownRef.current = false;
              setLastScanned(null);
            }, 600);
          },
          () => {
            // Scanning in progress - no error
          }
        );

        setIsRunning(true);
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : String(err);
        if (msg.includes("Permission") || msg.includes("NotAllowed")) {
          setError("تم رفض إذن الكاميرا. يرجى السماح بالوصول إلى الكاميرا من إعدادات المتصفح.");
        } else if (msg.includes("NotFound") || msg.includes("DevicesNotFound")) {
          setError("لم يتم العثور على كاميرا في هذا الجهاز.");
        } else {
          setError("تعذّر تشغيل الكاميرا. " + msg);
        }
      } finally {
        setIsStarting(false);
      }
    },
    [onScan]
  );

  // Start scanner when dialog opens
  useEffect(() => {
    if (open) {
      // Small delay to ensure DOM is ready
      const timer = setTimeout(() => startScanner(), 300);
      return () => clearTimeout(timer);
    } else {
      stopScanner();
      setLastScanned(null);
      setError(null);
    }
  }, [open]); // eslint-disable-line react-hooks/exhaustive-deps

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (scannerRef.current) {
        scannerRef.current.stop().catch(() => {});
        scannerRef.current = null;
      }
    };
  }, []);

  const handleSwitchCamera = async () => {
    if (cameras.length < 2) return;
    const currentIndex = cameras.findIndex((c) => c.id === selectedCamera);
    const nextCamera = cameras[(currentIndex + 1) % cameras.length];
    await stopScanner();
    setTimeout(() => startScanner(nextCamera?.id), 300);
  };

  const handleZoom = async (direction: "in" | "out") => {
    const newZoom = direction === "in" ? Math.min(zoom + 0.5, 3) : Math.max(zoom - 0.5, 1);
    setZoom(newZoom);
    // html5-qrcode doesn't expose zoom directly, but we can scale the video element
    const video = document.querySelector(`#${SCANNER_ID} video`) as HTMLVideoElement;
    if (video) {
      video.style.transform = `scale(${newZoom})`;
      video.style.transformOrigin = "center center";
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent
        className="max-w-sm p-0 overflow-hidden border-amber-800/40 bg-zinc-950"
        dir="rtl"
      >
        <DialogHeader className="px-4 pt-4 pb-2">
          <DialogTitle className="text-amber-300 flex items-center gap-2 text-base">
            <ScanLine className="w-4 h-4" />
            {title}
          </DialogTitle>
        </DialogHeader>

        {/* Scanner viewport */}
        <div className="relative bg-black">
          {/* Scanner container */}
          <div
            id={SCANNER_ID}
            className="w-full"
            style={{ minHeight: 240 }}
          />

          {/* Overlay: loading */}
          {isStarting && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 gap-3">
              <Loader2 className="w-8 h-8 animate-spin text-amber-400" />
              <p className="text-amber-300 text-sm">جاري تشغيل الكاميرا...</p>
            </div>
          )}

          {/* Overlay: error */}
          {error && !isStarting && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/90 gap-3 p-4">
              <CameraOff className="w-10 h-10 text-red-400" />
              <p className="text-red-300 text-sm text-center">{error}</p>
              <Button
                size="sm"
                variant="outline"
                className="border-amber-700/40 text-amber-300 hover:bg-amber-900/20 gap-1.5"
                onClick={() => startScanner()}
              >
                <RefreshCw className="w-3.5 h-3.5" /> إعادة المحاولة
              </Button>
            </div>
          )}

          {/* Scan success flash */}
          {lastScanned && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-green-900/80 gap-2 pointer-events-none">
              <div className="w-14 h-14 rounded-full bg-green-500/30 border-2 border-green-400 flex items-center justify-center">
                <ScanLine className="w-7 h-7 text-green-300" />
              </div>
              <p className="text-green-300 text-sm font-medium">تم المسح!</p>
              <Badge className="bg-green-900/80 text-green-200 border-green-600/50 font-mono text-xs max-w-[200px] truncate">
                {lastScanned}
              </Badge>
            </div>
          )}

          {/* Scanning frame overlay (decorative) */}
          {isRunning && !lastScanned && !error && (
            <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
              <div className="relative w-[260px] h-[180px]">
                {/* Corner markers */}
                <div className="absolute top-0 left-0 w-6 h-6 border-t-2 border-l-2 border-amber-400 rounded-tl" />
                <div className="absolute top-0 right-0 w-6 h-6 border-t-2 border-r-2 border-amber-400 rounded-tr" />
                <div className="absolute bottom-0 left-0 w-6 h-6 border-b-2 border-l-2 border-amber-400 rounded-bl" />
                <div className="absolute bottom-0 right-0 w-6 h-6 border-b-2 border-r-2 border-amber-400 rounded-br" />
                {/* Scan line animation */}
                <div
                  className="absolute left-1 right-1 h-0.5 bg-amber-400/70"
                  style={{
                    animation: "scanLine 2s linear infinite",
                    top: "50%",
                  }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Controls */}
        <div className="px-4 py-3 space-y-3 bg-zinc-900">
          <p className="text-xs text-muted-foreground text-center">{hint}</p>

          <div className="flex items-center justify-between gap-2">
            {/* Zoom controls */}
            <div className="flex items-center gap-1">
              <Button
                size="sm"
                variant="outline"
                className="h-8 w-8 p-0 border-zinc-700 hover:bg-zinc-800"
                onClick={() => handleZoom("out")}
                disabled={zoom <= 1}
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </Button>
              <span className="text-xs text-muted-foreground w-8 text-center">{zoom}×</span>
              <Button
                size="sm"
                variant="outline"
                className="h-8 w-8 p-0 border-zinc-700 hover:bg-zinc-800"
                onClick={() => handleZoom("in")}
                disabled={zoom >= 3}
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </Button>
            </div>

            {/* Switch camera (if multiple cameras) */}
            {cameras.length > 1 && (
              <Button
                size="sm"
                variant="outline"
                className="h-8 gap-1.5 text-xs border-zinc-700 hover:bg-zinc-800"
                onClick={handleSwitchCamera}
                disabled={isStarting}
              >
                <Camera className="w-3.5 h-3.5" />
                تبديل الكاميرا
              </Button>
            )}

            {/* Close */}
            <Button
              size="sm"
              variant="outline"
              className="h-8 text-xs border-red-800/40 text-red-400 hover:bg-red-900/20"
              onClick={onClose}
            >
              إغلاق
            </Button>
          </div>

          {/* Camera label */}
          {selectedCamera && cameras.length > 0 && (
            <p className="text-xs text-muted-foreground/50 text-center truncate">
              {cameras.find((c) => c.id === selectedCamera)?.label ?? "الكاميرا"}
            </p>
          )}
        </div>
      </DialogContent>

      {/* Scan line animation keyframes */}
      <style>{`
        @keyframes scanLine {
          0% { top: 10%; opacity: 1; }
          50% { top: 90%; opacity: 0.6; }
          100% { top: 10%; opacity: 1; }
        }
      `}</style>
    </Dialog>
  );
}

// ─── Compact inline trigger button ───────────────────────────────────────────
interface ScanButtonProps {
  onScan: (code: string) => void;
  title?: string;
  hint?: string;
  className?: string;
  label?: string;
  size?: "sm" | "default" | "lg";
}

export function ScanButton({
  onScan,
  title,
  hint,
  className,
  label = "مسح",
  size = "default",
}: ScanButtonProps) {
  const [open, setOpen] = useState(false);

  const handleScan = (code: string) => {
    setOpen(false);
    onScan(code);
  };

  return (
    <>
      <Button
        type="button"
        variant="outline"
        size={size}
        className={cn(
          "gap-1.5 border-amber-700/40 text-amber-300 hover:bg-amber-900/20",
          className
        )}
        onClick={() => setOpen(true)}
      >
        <ScanLine className="w-4 h-4" />
        {label}
      </Button>
      <BarcodeScanner
        open={open}
        onClose={() => setOpen(false)}
        onScan={handleScan}
        title={title}
        hint={hint}
      />
    </>
  );
}
