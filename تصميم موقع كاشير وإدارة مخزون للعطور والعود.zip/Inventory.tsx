import { useState, useRef } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { BarcodeScanner } from "@/components/BarcodeScanner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import {
  Package, Plus, Search, AlertTriangle, Edit, Trash2, ArrowUpCircle,
  ArrowDownCircle, ScanLine, Filter, Scale, Loader2, Hash, Tag
} from "lucide-react";
import { cn } from "@/lib/utils";

const UNIT_TYPES = [
  "قطعة", "علبة", "جرام", "توله", "مثقال", "كيلو", "لتر", "مل",
  "زجاجة", "كرتون", "دزينة", "أخرى"
];

type Product = {
  id: number;
  code: string;
  name: string;
  description: string | null;
  categoryId: number | null;
  categoryName?: string | null;
  quantity: number;
  unit: string | null;
  costPrice: string;
  sellingPrice: string;
  lowStockThreshold: number;
  supplier: string | null;
  supplierPhone: string | null;
  imageUrl: string | null;
};

const emptyForm = {
  code: "", name: "", description: "", categoryId: "",
  quantity: "0", unit: "قطعة", costPrice: "", sellingPrice: "",
  lowStockThreshold: "5", supplier: "", supplierPhone: "",
};

export default function Inventory() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [unitFilter, setUnitFilter] = useState("all");
  const [showForm, setShowForm] = useState(false);
  const [editProduct, setEditProduct] = useState<Product | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [stockDialog, setStockDialog] = useState<{ product: Product; type: "in" | "out" } | null>(null);
  const [stockQty, setStockQty] = useState("1");
  const [stockNote, setStockNote] = useState("");
  const [codeInput, setCodeInput] = useState("");
  const [scannerOpen, setScannerOpen] = useState(false);
  const codeRef = useRef<HTMLInputElement>(null);
  const utils = trpc.useUtils();

  const { data: settings } = trpc.shop.getSettings.useQuery();
  const currency = settings?.currencySymbol ?? "ريال";

  const { data: categories = [] } = trpc.categories.list.useQuery();
  const { data: products = [], isLoading } = trpc.products.list.useQuery({});
  const { data: lowStock = [] } = trpc.products.getLowStock.useQuery();

  const { data: scannedProduct } = trpc.products.getByCode.useQuery(
    { code: codeInput }, { enabled: codeInput.length > 2 }
  );

  const createMutation = trpc.products.create.useMutation({
    onSuccess: () => { toast.success("تم إضافة المنتج بنجاح"); utils.products.list.invalidate(); utils.products.getLowStock.invalidate(); setShowForm(false); setForm(emptyForm); },
    onError: (e) => toast.error(e.message),
  });

  const updateMutation = trpc.products.update.useMutation({
    onSuccess: () => { toast.success("تم تحديث المنتج بنجاح"); utils.products.list.invalidate(); utils.products.getLowStock.invalidate(); setEditProduct(null); },
    onError: (e) => toast.error(e.message),
  });

  const deleteMutation = trpc.products.delete.useMutation({
    onSuccess: () => { toast.success("تم حذف المنتج"); utils.products.list.invalidate(); },
    onError: (e) => toast.error(e.message),
  });

  const addStockMutation = trpc.products.addStock.useMutation({
    onSuccess: () => { toast.success("تم تحديث المخزون بنجاح"); utils.products.list.invalidate(); utils.products.getLowStock.invalidate(); setStockDialog(null); setStockQty("1"); setStockNote(""); },
    onError: (e) => toast.error(e.message),
  });

  const openEdit = (p: Product) => {
    setEditProduct(p);
    setForm({
      code: p.code, name: p.name, description: p.description ?? "",
      categoryId: p.categoryId?.toString() ?? "", quantity: p.quantity.toString(),
      unit: p.unit ?? "قطعة", costPrice: p.costPrice, sellingPrice: p.sellingPrice,
      lowStockThreshold: p.lowStockThreshold.toString(), supplier: p.supplier ?? "",
      supplierPhone: p.supplierPhone ?? "",
    });
  };

  const handleSubmit = () => {
    if (!form.code.trim() || !form.name.trim()) { toast.error("الكود والاسم مطلوبان"); return; }
    if (!form.sellingPrice || Number(form.sellingPrice) <= 0) { toast.error("يرجى إدخال سعر البيع"); return; }
    const payload = {
      code: form.code.trim(), name: form.name.trim(),
      description: form.description.trim() || undefined,
      categoryId: form.categoryId ? Number(form.categoryId) : (categories[0]?.id ?? 1),
      quantity: Number(form.quantity), unit: form.unit,
      costPrice: form.costPrice ? Number(form.costPrice) : 0,
      sellingPrice: Number(form.sellingPrice),
      lowStockThreshold: Number(form.lowStockThreshold) || 5,
      supplier: form.supplier.trim() || undefined,
      supplierPhone: form.supplierPhone.trim() || undefined,
    };
    if (editProduct) updateMutation.mutate({ id: editProduct.id, ...payload });
    else createMutation.mutate(payload);
  };

  const filtered = products.filter((p) => {
    const matchSearch = !search || p.name.includes(search) || p.code.toLowerCase().includes(search.toLowerCase());
    const matchCat = categoryFilter === "all" || p.categoryId?.toString() === categoryFilter;
    const matchUnit = unitFilter === "all" || p.unit === unitFilter;
    return matchSearch && matchCat && matchUnit;
  });

  const totalValue = products.reduce((s, p) => s + Number(p.costPrice) * p.quantity, 0);

  return (
    <div className="space-y-5" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-amber-300" style={{ fontFamily: "'Amiri', serif" }}>إدارة المخزون</h1>
          <p className="text-muted-foreground text-sm mt-1">{products.length} منتج · قيمة المخزون: {totalValue.toFixed(0)} {currency}</p>
        </div>
        <Button onClick={() => { setEditProduct(null); setForm(emptyForm); setShowForm(true); }} className="bg-amber-600 hover:bg-amber-500 text-white gap-2">
          <Plus className="w-4 h-4" /> إضافة منتج
        </Button>
      </div>

      {/* Low stock banner */}
      {lowStock.length > 0 && (
        <div className="flex items-center gap-3 p-3 rounded-lg bg-orange-900/20 border border-orange-700/40">
          <AlertTriangle className="w-5 h-5 text-orange-400 shrink-0" />
          <p className="text-sm text-orange-300">
            <strong>{lowStock.length} منتج</strong> بمخزون منخفض:{" "}
            {lowStock.slice(0, 4).map((p) => p.name).join(" · ")}
            {lowStock.length > 4 && ` · وأكثر...`}
          </p>
        </div>
      )}

      {/* Barcode scanner */}
      <Card className="border-amber-800/30 bg-card">
        <CardContent className="p-4">
          <div className="flex gap-3 items-center">
            <ScanLine className="w-5 h-5 text-amber-400 shrink-0" />
            <Input
              ref={codeRef}
              value={codeInput}
              onChange={(e) => setCodeInput(e.target.value)}
              placeholder="امسح الباركود أو أدخل الكود للبحث السريع..."
              className="bg-input border-border flex-1"
            />
            {/* Camera scan button */}
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setScannerOpen(true)}
              className="border-amber-700/40 text-amber-300 hover:bg-amber-900/20 gap-1.5 shrink-0"
              title="مسح بالكاميرا"
            >
              <ScanLine className="w-4 h-4" />
              <span className="hidden sm:inline text-xs">كاميرا</span>
            </Button>
            {codeInput && <Button variant="ghost" size="sm" onClick={() => setCodeInput("")} className="text-muted-foreground">✕</Button>}
          </div>
          {codeInput.length > 2 && (
            <div className="mt-3">
              {scannedProduct ? (
                <div className="flex items-center justify-between p-3 rounded-lg bg-green-900/20 border border-green-700/40">
                  <div>
                    <p className="font-medium text-green-300">{scannedProduct.name}</p>
                    <p className="text-xs text-muted-foreground">الكمية: <strong className="text-amber-300">{scannedProduct.quantity} {scannedProduct.unit ?? "قطعة"}</strong> · السعر: {Number(scannedProduct.sellingPrice).toFixed(2)} {currency}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" onClick={() => { setStockDialog({ product: scannedProduct as Product, type: "in" }); setCodeInput(""); }} className="bg-green-700 hover:bg-green-600 text-white gap-1 text-xs">
                      <ArrowUpCircle className="w-3 h-3" /> إضافة
                    </Button>
                    <Button size="sm" onClick={() => { openEdit(scannedProduct as Product); setCodeInput(""); }} variant="outline" className="border-amber-600/40 text-amber-400 gap-1 text-xs">
                      <Edit className="w-3 h-3" /> تعديل
                    </Button>
                  </div>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground p-2">لم يتم العثور على منتج بهذا الكود</p>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="بحث بالاسم أو الكود..." className="pr-9 bg-input border-border" />
        </div>
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-44 bg-input border-border text-sm">
            <Filter className="w-3.5 h-3.5 ml-1 text-amber-400" />
            <SelectValue placeholder="كل التصنيفات" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">كل التصنيفات</SelectItem>
            {categories.map((c) => <SelectItem key={c.id} value={c.id.toString()}>{c.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={unitFilter} onValueChange={setUnitFilter}>
          <SelectTrigger className="w-40 bg-input border-border text-sm">
            <Scale className="w-3.5 h-3.5 ml-1 text-amber-400" />
            <SelectValue placeholder="نوع الوحدة" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">جميع الوحدات</SelectItem>
            {UNIT_TYPES.map((u) => <SelectItem key={u} value={u}>{u}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {/* Products table */}
      <Card className="border-amber-800/30 bg-card">
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex items-center justify-center py-16"><Loader2 className="w-8 h-8 animate-spin text-amber-400" /></div>
          ) : !filtered.length ? (
            <div className="p-10 text-center">
              <Package className="w-12 h-12 text-muted-foreground mx-auto mb-3 opacity-40" />
              <p className="text-muted-foreground">لا توجد منتجات مطابقة</p>
              <Button variant="outline" size="sm" className="mt-3 border-amber-600/40 text-amber-400" onClick={() => { setEditProduct(null); setForm(emptyForm); setShowForm(true); }}>
                <Plus className="w-3.5 h-3.5 ml-1" /> إضافة أول منتج
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b border-border bg-muted/20">
                  <tr className="text-muted-foreground text-xs">
                    <th className="text-right p-3 font-medium">الكود</th>
                    <th className="text-right p-3 font-medium">المنتج</th>
                    <th className="text-right p-3 font-medium">التصنيف</th>
                    <th className="text-right p-3 font-medium">الكمية</th>
                    <th className="text-right p-3 font-medium">الوحدة</th>
                    <th className="text-right p-3 font-medium">التكلفة</th>
                    <th className="text-right p-3 font-medium">البيع</th>
                    <th className="text-right p-3 font-medium">المورد</th>
                    <th className="text-right p-3 font-medium">الإجراءات</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((product) => {
                    const isLow = product.quantity <= product.lowStockThreshold;
                    const isOut = product.quantity === 0;
                    return (
                      <tr key={product.id} className={cn("border-b border-border/30 hover:bg-muted/10 transition-colors", isOut ? "bg-red-900/10" : isLow ? "bg-orange-900/8" : "")}>
                        <td className="p-3"><Badge variant="outline" className="font-mono text-xs border-amber-600/40 text-amber-400">{product.code}</Badge></td>
                        <td className="p-3">
                          <p className="font-medium">{product.name}</p>
                          {product.description && <p className="text-xs text-muted-foreground truncate max-w-32">{product.description}</p>}
                        </td>
                        <td className="p-3">
                          {product.categoryName ? <Badge variant="secondary" className="text-xs">{product.categoryName}</Badge> : <span className="text-muted-foreground text-xs">—</span>}
                        </td>
                        <td className="p-3">
                          <div className="flex items-center gap-1.5">
                            {isOut ? (
                              <Badge className="bg-red-900/40 text-red-300 border-red-700/40 text-xs">نفد</Badge>
                            ) : isLow ? (
                              <Badge className="bg-orange-900/40 text-orange-300 border-orange-700/40 text-xs flex items-center gap-1">
                                <AlertTriangle className="w-3 h-3" />{product.quantity}
                              </Badge>
                            ) : (
                              <span className="font-semibold text-green-300">{product.quantity}</span>
                            )}
                          </div>
                        </td>
                        <td className="p-3"><span className="text-xs text-muted-foreground bg-muted/30 px-2 py-0.5 rounded">{product.unit ?? "قطعة"}</span></td>
                        <td className="p-3 text-muted-foreground text-xs">{Number(product.costPrice).toFixed(2)} {currency}</td>
                        <td className="p-3 text-amber-300 font-semibold">{Number(product.sellingPrice).toFixed(2)} {currency}</td>
                        <td className="p-3">
                          <p className="text-xs text-muted-foreground truncate max-w-24">{product.supplier ?? "—"}</p>
                          {product.supplierPhone && <p className="text-xs text-blue-400 font-mono">{product.supplierPhone}</p>}
                        </td>
                        <td className="p-3">
                          <div className="flex items-center gap-1">
                            <Button size="icon" variant="ghost" className="h-7 w-7 hover:bg-green-900/20 text-green-400" title="إضافة مخزون" onClick={() => { setStockDialog({ product: product as Product, type: "in" }); setStockQty("1"); setStockNote(""); }}>
                              <ArrowUpCircle className="w-4 h-4" />
                            </Button>
                            <Button size="icon" variant="ghost" className="h-7 w-7 hover:bg-red-900/20 text-red-400" title="خصم من المخزون" onClick={() => { setStockDialog({ product: product as Product, type: "out" }); setStockQty("1"); setStockNote(""); }}>
                              <ArrowDownCircle className="w-4 h-4" />
                            </Button>
                            <Button size="icon" variant="ghost" className="h-7 w-7 hover:bg-amber-900/20 text-amber-400" title="تعديل" onClick={() => openEdit(product as Product)}>
                              <Edit className="w-3.5 h-3.5" />
                            </Button>
                            {isAdmin && (
                              <Button size="icon" variant="ghost" className="h-7 w-7 hover:bg-red-900/20 text-red-400/60" title="حذف" onClick={() => { if (confirm(`هل تريد حذف "${product.name}"؟`)) deleteMutation.mutate({ id: product.id }); }}>
                                <Trash2 className="w-3.5 h-3.5" />
                              </Button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add/Edit Product Dialog */}
      <Dialog open={showForm || !!editProduct} onOpenChange={(open) => { if (!open) { setShowForm(false); setEditProduct(null); } }}>
        <DialogContent className="border-amber-800/30 bg-card max-w-xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-amber-300 flex items-center gap-2">
              <Package className="w-5 h-5" />
              {editProduct ? "تعديل المنتج" : "إضافة منتج جديد"}
            </DialogTitle>
          </DialogHeader>
          <Tabs defaultValue="basic">
            <TabsList className="bg-muted/30 border border-border/50 w-full">
              <TabsTrigger value="basic" className="flex-1 text-xs">الأساسي</TabsTrigger>
              <TabsTrigger value="pricing" className="flex-1 text-xs">التسعير والمخزون</TabsTrigger>
              <TabsTrigger value="supplier" className="flex-1 text-xs">المورد</TabsTrigger>
            </TabsList>

            <TabsContent value="basic" className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs text-muted-foreground mb-1 block flex items-center gap-1"><Hash className="w-3 h-3" /> الكود *</Label>
                  <Input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} placeholder="OUD-001" className="bg-input border-border font-mono" dir="ltr" disabled={!!editProduct} />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground mb-1 block flex items-center gap-1"><Tag className="w-3 h-3" /> التصنيف</Label>
                  <Select value={form.categoryId} onValueChange={(v) => setForm({ ...form, categoryId: v })}>
                    <SelectTrigger className="bg-input border-border text-sm"><SelectValue placeholder="اختر التصنيف" /></SelectTrigger>
                    <SelectContent>{categories.map((c) => <SelectItem key={c.id} value={c.id.toString()}>{c.name}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label className="text-xs text-muted-foreground mb-1 block">اسم المنتج *</Label>
                <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="اسم المنتج" className="bg-input border-border" />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground mb-1 block">الوصف</Label>
                <Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="وصف مختصر" className="bg-input border-border" />
              </div>
            </TabsContent>

            <TabsContent value="pricing" className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs text-muted-foreground mb-1 block">الكمية {!editProduct && "*"}</Label>
                  <Input type="number" min={0} value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} className="bg-input border-border" />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground mb-1 block flex items-center gap-1"><Scale className="w-3 h-3" /> نوع الوحدة</Label>
                  <Select value={form.unit} onValueChange={(v) => setForm({ ...form, unit: v })}>
                    <SelectTrigger className="bg-input border-border text-sm"><SelectValue /></SelectTrigger>
                    <SelectContent>{UNIT_TYPES.map((u) => <SelectItem key={u} value={u}>{u}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs text-muted-foreground mb-1 block">سعر التكلفة ({currency})</Label>
                  <Input type="number" min={0} step="0.01" value={form.costPrice} onChange={(e) => setForm({ ...form, costPrice: e.target.value })} placeholder="0.00" className="bg-input border-border" />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground mb-1 block">سعر البيع ({currency}) *</Label>
                  <Input type="number" min={0} step="0.01" value={form.sellingPrice} onChange={(e) => setForm({ ...form, sellingPrice: e.target.value })} placeholder="0.00" className="bg-input border-border" />
                </div>
              </div>
              <div>
                <Label className="text-xs text-muted-foreground mb-1 block flex items-center gap-1"><AlertTriangle className="w-3 h-3 text-amber-400" /> حد التنبيه (الكمية الدنيا)</Label>
                <Input type="number" min={0} value={form.lowStockThreshold} onChange={(e) => setForm({ ...form, lowStockThreshold: e.target.value })} className="bg-input border-border" />
              </div>
              {form.costPrice && form.sellingPrice && Number(form.costPrice) > 0 && (
                <div className="p-3 rounded-lg bg-green-900/20 border border-green-700/30 text-sm text-green-300">
                  هامش الربح: {(((Number(form.sellingPrice) - Number(form.costPrice)) / Number(form.costPrice)) * 100).toFixed(1)}%
                  ({(Number(form.sellingPrice) - Number(form.costPrice)).toFixed(2)} {currency} / وحدة)
                </div>
              )}
            </TabsContent>

            <TabsContent value="supplier" className="space-y-4 mt-4">
              <div>
                <Label className="text-xs text-muted-foreground mb-1 block">اسم المورد</Label>
                <Input value={form.supplier} onChange={(e) => setForm({ ...form, supplier: e.target.value })} placeholder="اسم المورد أو الشركة" className="bg-input border-border" />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground mb-1 block">رقم هاتف المورد</Label>
                <Input value={form.supplierPhone} onChange={(e) => setForm({ ...form, supplierPhone: e.target.value })} placeholder="05xxxxxxxx" className="bg-input border-border" dir="ltr" />
              </div>
            </TabsContent>
          </Tabs>
          <DialogFooter className="gap-2 mt-4">
            <Button variant="outline" className="border-amber-600/40" onClick={() => { setShowForm(false); setEditProduct(null); }}>إلغاء</Button>
            <Button onClick={handleSubmit} disabled={createMutation.isPending || updateMutation.isPending} className="bg-amber-600 hover:bg-amber-500 text-white gap-2">
              {(createMutation.isPending || updateMutation.isPending) && <Loader2 className="w-4 h-4 animate-spin" />}
              {editProduct ? "حفظ التعديلات" : "إضافة المنتج"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Stock Update Dialog */}
      <Dialog open={!!stockDialog} onOpenChange={(open) => { if (!open) setStockDialog(null); }}>
        <DialogContent className="border-amber-800/30 bg-card max-w-sm" dir="rtl">
          <DialogHeader>
            <DialogTitle className={`flex items-center gap-2 ${stockDialog?.type === "in" ? "text-green-300" : "text-red-300"}`}>
              {stockDialog?.type === "in" ? <><ArrowUpCircle className="w-5 h-5" /> إضافة للمخزون</> : <><ArrowDownCircle className="w-5 h-5" /> خصم من المخزون</>}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="p-3 rounded-lg bg-muted/30 border border-border/50">
              <p className="font-medium">{stockDialog?.product.name}</p>
              <p className="text-sm text-muted-foreground">الكمية الحالية: <strong className="text-amber-300">{stockDialog?.product.quantity} {stockDialog?.product.unit ?? "قطعة"}</strong></p>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground mb-1 block">الكمية المراد {stockDialog?.type === "in" ? "إضافتها" : "خصمها"}</Label>
              <Input type="number" min={1} value={stockQty} onChange={(e) => setStockQty(e.target.value)} className="bg-input border-border text-lg font-bold text-center" autoFocus />
            </div>
            <div>
              <Label className="text-xs text-muted-foreground mb-1 block">ملاحظة (اختياري)</Label>
              <Input value={stockNote} onChange={(e) => setStockNote(e.target.value)} placeholder="سبب التعديل" className="bg-input border-border" />
            </div>
          </div>
          <DialogFooter className="gap-2 mt-2">
            <Button variant="outline" className="border-amber-600/40" onClick={() => setStockDialog(null)}>إلغاء</Button>
            <Button
              onClick={() => stockDialog && addStockMutation.mutate({ productId: stockDialog.product.id, quantity: Number(stockQty), type: stockDialog.type, note: stockNote || undefined })}
              disabled={addStockMutation.isPending}
              className={stockDialog?.type === "in" ? "bg-green-700 hover:bg-green-600 text-white" : "bg-red-700 hover:bg-red-600 text-white"}
            >
              {addStockMutation.isPending && <Loader2 className="w-4 h-4 animate-spin ml-1" />}
              {stockDialog?.type === "in" ? "إضافة للمخزون" : "خصم من المخزون"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Camera Barcode Scanner */}
      <BarcodeScanner
        open={scannerOpen}
        onClose={() => setScannerOpen(false)}
        onScan={(code) => {
          setScannerOpen(false);
          setCodeInput(code);
          codeRef.current?.focus();
          // If product found, show it immediately
          const found = products.find((p) => p.code === code || p.code.includes(code) || code.includes(p.code));
          if (found) {
            toast.success(`تم العثور على: ${found.name}`);
          } else {
            toast.info(`كود مسح: ${code} — يمكنك إضافة منتج جديد بهذا الكود`);
          }
        }}
        title="مسح باركود المنتج"
        hint="وجّه الكاميرا نحو باركود المنتج للبحث أو تسجيل الوارد"
      />
    </div>
  );
}
