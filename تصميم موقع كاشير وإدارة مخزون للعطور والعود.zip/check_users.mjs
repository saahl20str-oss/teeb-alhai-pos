import { createPool } from "mysql2/promise";
const url = process.env.DATABASE_URL;
if (!url) { console.error("No DATABASE_URL"); process.exit(1); }
const pool = createPool({ uri: url, ssl: { rejectUnauthorized: false } });
const [rows] = await pool.query("SELECT id, name, email, role, permissions, isActive FROM users ORDER BY id");
console.log(JSON.stringify(rows, null, 2));
await pool.end();
