# طيب الحي - Project TODO

## Phase 1: Infrastructure & Schema

- [x] Upload logo to static assets

- [x] Design and migrate full database schema

- [x] Set up tRPC routers structure

## Phase 2: Landing Page

- [x] Luxury Arabic landing page with oud/perfume/saffron background

- [x] Display shop logo prominently

- [x] Login button

- [x] Settings button (owner only - customize logo and titles)

- [x] Animated saffron particles / decorative elements

- [x] Arabic RTL support throughout

## Phase 3: Authentication & Roles

- [x] Owner role: full access (reports, settings, user management)

- [x] Staff role: limited access (product entry, inventory input only)

- [x] Role-based route protection

- [x] User management page (owner only)

- [x] Add/invite staff users

## Phase 4: Inventory Management

- [x] Product catalog with categories (oud, perfumes, oils/adhaan)

- [x] Product entry: image, quantity, price, supplier, barcode/code

- [x] Barcode/code scan or manual entry for stock-in

- [x] Real-time inventory updates

- [x] Low-stock alerts with configurable threshold per product

- [x] Inventory list with filters by category

## Phase 5: POS Cashier

- [x] Scan or enter product codes to add to cart

- [x] Cart management (add, remove, update quantity)

- [x] Apply discounts (percentage or fixed)

- [x] Calculate totals

- [x] Complete transaction and record sale

- [x] Real-time inventory deduction on sale

## Phase 6: Invoices

- [x] Auto-numbered invoices

- [x] Invoice includes: shop name, logo, stamp, itemized products, totals, date

- [x] Printable invoice view

- [x] PDF download support

- [x] Invoice history list

## Phase 7: Analytics Dashboard

- [x] Daily, monthly, yearly sales charts

- [x] Top-selling products

- [x] Revenue summaries

- [x] Inventory value reports

- [x] Low-stock summary widget

## Phase 8: AI Advisor

- [x] Chat interface for AI market advisor

- [x] AI analyzes real sales and inventory data

- [x] Provides business insights and recommendations

- [x] Arabic language support

## Phase 9: Settings & Polish

- [x] Settings page (owner only): logo, shop name, address, branding

- [x] Global Arabic RTL layout

- [x] Responsive design

- [x] Vitest unit tests (22 tests passing)

- [x] Final checkpoint

## Phase 10: Major Improvements Round 2

### Ownership Transfer Model

- [x] First login auto-becomes owner/admin (no hardcoded owner)

- [x] Owner can transfer ownership to another user

### User Management

- [x] Full CRUD for staff: add, edit, delete

- [x] Defined permissions list per staff role (11 permissions across 4 groups)

- [x] Staff invite flow with email

- [x] Edit/delete buttons per user row

### Settings

- [x] Currency selector (SAR/AED/USD/KWD/BHD/QAR/OMR/EGP/JOD)

- [x] Currency auto-applied across entire system

- [x] Logo upload via image file (easier upload)

- [x] Supplier contact info (email + WhatsApp) for low-stock alerts

### Landing Page

- [x] Brighter background overlay so oud image is more visible

- [x] Fix Arabic/English title vertical overlap

### POS Cashier

- [x] Add customer name field

- [x] Add customer phone field

- [x] Staff name recorded on each sale

- [x] Customer database built from POS entries

### Inventory

- [x] Unit type selector: علبة/قطعة/جرام/توله/مل/كيلو/أخرى

- [x] Edit any product field inline

- [x] Unit shown in all product listings

- [x] supplierPhone field added

### Invoices

- [x] Customer phone number on invoice

- [x] Marketing/offers sending to customers (WhatsApp/SMS link)

### Analytics

- [x] Currency-aware (uses selected currency)

- [x] Full redesign for clarity and real data

- [x] Yearly chart added

### Notification Center

- [x] Delete individual notification

- [x] Snooze/remind later

- [x] Send low-stock alert to supplier via email or WhatsApp

- [x] Dedicated Notifications page

### AI Advisor

- [x] Full rebuild with real sales + inventory data injected

- [x] Comprehensive assistant with data context panel

- [x] Quick analysis buttons

### Dashboard

- [x] Currency-aware stats cards

- [x] 24 tests passing

## Phase 11: Camera Barcode Scanner

- [x] Install html5-qrcode library

- [x] Build reusable BarcodeScanner component (camera modal, torch, multi-format support)

- [x] Integrate scanner into POS cashier (camera button + auto-add to cart)

- [x] Integrate scanner into Inventory management (camera button + code lookup)

- [x] All 24 tests passing

## Phase 12: Independent Email + Password Auth

- [x] Install bcrypt for password hashing

- [x] Add passwordHash column to users table

- [x] Build server-side auth: register first admin, login, logout, JWT session

- [x] Build login page (email + password form, luxury design)

- [x] Build first-run setup page (register first admin)

- [x] Update all frontend auth hooks to use internal auth

- [x] Update user management: add staff with email + password + reset password

- [x] Remove Manus OAuth dependency from login flow

- [x] Update landing page buttons

- [x] 24 tests passing

## Phase 13: Auth Flow Fix

- [x] Fix hasAnyAdmin() to only count admins WITH a passwordHash (not OAuth-only users)

- [x] Delete all OAuth-only users from DB (no passwordHash)

- [x] /api/auth/local/setup-status now correctly returns {needsSetup:true} on fresh install

- [x] Login page: auto-check on load, redirect to /setup if no admin

- [x] Setup page: redirect to /login after successful admin creation

- [x] Landing page: login button routes to /login (not Manus OAuth)

- [x] Full flow verified: first visit → /login → auto-redirect to /setup → create admin → /login → /dashboard

- [x] 24 tests passing, TypeScript clean

## Phase 14: Bug Fixes + Customers Page

### Bug Fixes

- [x] Fix staff login: diagnosed - staff user (id=600003) was deactivated (isActive=0); active staff (id=690002) has valid passwordHash. Admin must use correct password or reset via Users page

- [x] Fix AI advisor SQL error: fixed DATE_FORMAT GROUP BY mismatch with only_full_group_by mode - removed table prefix from sql`` template literals

### New Feature: Customers Page

- [x] Create /customers route and page

- [x] Show customer list: name, phone, email, total purchases, last purchase date

- [x] Customer data auto-populated from POS sales (customerName, customerPhone)

- [x] Add to sidebar navigation (staff with customers.view permission can view)

- [x] Add customers.view permission check in AppLayout sidebar

- [x] Search/filter customers by name or phone

## Phase 15: Permissions Sidebar Fix + Email/WhatsApp

- [ ] Fix sidebar: nav items must be filtered by user permissions (not just adminOnly flag)

- [ ] Fix: dashboard, inventory, pos, invoices, notifications should only show if user has matching permission

- [ ] Fix: customers page must appear in sidebar when user has customers.view permission

- [ ] Fix: load user permissions from DB in auth context (currently permissions not passed to frontend)

- [ ] Add real email sending via nodemailer or built-in API for supplier/company emails

- [ ] Add WhatsApp link button for customers in Customers page

## Phase 16: SMTP Email Integration (In-App Settings)

- [ ] Add smtpEmail, smtpPassword, smtpFromName columns to shopSettings table

- [ ] Generate and apply migration SQL

- [ ] Install nodemailer package

- [ ] Create server/email.ts service with sendEmail() helper

- [ ] Add SMTP settings section in Settings page (email, password, from name, test button)

- [ ] Add smtp.save and smtp.test procedures in routers.ts

- [ ] Replace mailto: with real server-side email in Notifications page (supplier alert)

- [ ] Add "Send Email" button in Customers page for customer promotions

- [ ] TypeScript clean + tests pass

