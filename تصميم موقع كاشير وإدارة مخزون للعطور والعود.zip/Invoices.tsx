import { useState, useRef } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import {
  Search, FileText, Printer, Eye, Download, Phone, MessageCircle,
  Filter, Loader2, Send, Users, TrendingUp
} from "lucide-react";
import { cn } from "@/lib/utils";

const LOGO_URL = "/manus-storage/teeb-logo_ab292981.jpeg";

type SaleItem = { id: number; productName: string; productCode: string; quantity: number; unitPrice: string; total: string; };
type SaleWithItems = {
  id: number; invoiceNumber: string; customerName?: string | null; customerPhone?: string | null;
  staffName?: string | null; subtotal: string; discountAmount?: string | null; total: string;
  paymentMethod?: string | null; status?: string | null; createdAt: Date; items: SaleItem[];
};

function InvoicePrint({ sale, settings }: {
  sale: SaleWithItems;
  settings: { shopName?: string | null; shopNameEn?: string | null; address?: string | null; phone?: string | null; logoUrl?: string | null; stampText?: string | null; currencySymbol?: string | null } | null
}) {
  const logoUrl = settings?.logoUrl ?? LOGO_URL;
  const shopName = settings?.shopName ?? "طيب الحي للعود والأدهان";
  const shopNameEn = settings?.shopNameEn ?? "Teeb Al Hai";
  const address = settings?.address ?? "المملكة العربية السعودية";
  const phone = settings?.phone;
  const currency = settings?.currencySymbol ?? "ريال";
  const stampText = settings?.stampText ?? shopName;

  return (
    <div id="invoice-print" className="bg-white text-black p-8 max-w-2xl mx-auto" dir="rtl" style={{ fontFamily: "'Tajawal', sans-serif" }}>
      {/* Header */}
      <div className="flex items-start justify-between mb-6 pb-4 border-b-2 border-amber-600">
        <div className="flex items-center gap-4">
          <div className="w-20 h-20 rounded-full overflow-hidden border-2 border-amber-500 shrink-0">
            <img src={logoUrl} alt="شعار" className="w-full h-full object-cover" onError={(e) => { (e.target as HTMLImageElement).src = LOGO_URL; }} />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-amber-700" style={{ fontFamily: "'Amiri', serif" }}>{shopName}</h1>
            <p className="text-sm text-gray-500">{shopNameEn}</p>
            {address && <p className="text-xs text-gray-400 mt-1">{address}</p>}
            {phone && <p className="text-xs text-gray-400">📞 {phone}</p>}
          </div>
        </div>
        <div>
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-left">
            <p className="text-xs text-gray-500 mb-0.5">رقم الفاتورة</p>
            <p className="text-xl font-bold text-amber-700 font-mono">{sale.invoiceNumber}</p>
            <p className="text-xs text-gray-500 mt-1.5">التاريخ</p>
            <p className="text-sm font-medium">{new Date(sale.createdAt).toLocaleDateString("ar-SA", { year: "numeric", month: "long", day: "numeric" })}</p>
            <p className="text-xs text-gray-400">{new Date(sale.createdAt).toLocaleTimeString("ar-SA")}</p>
          </div>
        </div>
      </div>

      {/* Customer info */}
      {(sale.customerName || sale.customerPhone) && (
        <div className="mb-4 p-3 bg-amber-50 rounded-lg border border-amber-100">
          <p className="text-xs font-semibold text-amber-700 mb-1">بيانات العميل</p>
          {sale.customerName && <p className="text-sm text-gray-700">الاسم: <strong>{sale.customerName}</strong></p>}
          {sale.customerPhone && <p className="text-sm text-gray-700">الهاتف: <strong dir="ltr">{sale.customerPhone}</strong></p>}
        </div>
      )}

      {/* Items table */}
      <table className="w-full mb-6" style={{ borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ background: "#92400e", color: "white" }}>
            <th className="p-2 text-right text-sm font-medium">#</th>
            <th className="p-2 text-right text-sm font-medium">المنتج</th>
            <th className="p-2 text-right text-sm font-medium">الكود</th>
            <th className="p-2 text-center text-sm font-medium">الكمية</th>
            <th className="p-2 text-left text-sm font-medium">سعر الوحدة</th>
            <th className="p-2 text-left text-sm font-medium">الإجمالي</th>
          </tr>
        </thead>
        <tbody>
          {sale.items.map((item, idx) => (
            <tr key={item.id} style={{ background: idx % 2 === 0 ? "#fffbf5" : "white", borderBottom: "1px solid #e5e7eb" }}>
              <td className="p-2 text-sm text-gray-500">{idx + 1}</td>
              <td className="p-2 text-sm font-medium">{item.productName}</td>
              <td className="p-2 text-xs text-gray-500 font-mono">{item.productCode}</td>
              <td className="p-2 text-sm text-center">{item.quantity}</td>
              <td className="p-2 text-sm text-left">{Number(item.unitPrice).toFixed(2)} {currency}</td>
              <td className="p-2 text-sm font-semibold text-left">{Number(item.total).toFixed(2)} {currency}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Totals */}
      <div className="flex justify-end mb-6">
        <div className="w-64 space-y-2">
          <div className="flex justify-between text-sm text-gray-600">
            <span>المجموع الفرعي:</span>
            <span>{Number(sale.subtotal).toFixed(2)} {currency}</span>
          </div>
          {Number(sale.discountAmount ?? 0) > 0 && (
            <div className="flex justify-between text-sm text-green-600">
              <span>الخصم:</span>
              <span>- {Number(sale.discountAmount).toFixed(2)} {currency}</span>
            </div>
          )}
          <div className="flex justify-between font-bold text-lg border-t-2 border-amber-600 pt-2 text-amber-700">
            <span>الإجمالي:</span>
            <span>{Number(sale.total).toFixed(2)} {currency}</span>
          </div>
          <div className="text-xs text-gray-500">
            طريقة الدفع: {sale.paymentMethod === "cash" ? "نقدي" : sale.paymentMethod === "card" ? "بطاقة" : "تحويل"}
          </div>
          {sale.staffName && <div className="text-xs text-gray-400">الموظف: {sale.staffName}</div>}
        </div>
      </div>

      {/* Stamp */}
      <div className="flex justify-center mt-6">
        <div className="relative w-36 h-36 flex items-center justify-center" style={{ border: "3px solid #92400e", borderRadius: "50%", transform: "rotate(-12deg)", opacity: 0.8 }}>
          <div className="absolute inset-2 flex items-center justify-center" style={{ border: "1px solid #92400e", borderRadius: "50%" }}>
            <div className="text-center px-2">
              <p className="text-xs font-bold text-amber-700" style={{ fontFamily: "'Amiri', serif" }}>{stampText}</p>
              <p className="text-xs text-green-600 font-bold mt-1">✓ مدفوعة</p>
              <p className="text-xs text-gray-500 mt-1">{new Date(sale.createdAt).toLocaleDateString("ar-SA")}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="mt-6 pt-4 border-t border-gray-200 text-center">
        <p className="text-xs text-gray-400">شكراً لتعاملكم معنا — {shopName}</p>
        {phone && <p className="text-xs text-gray-400 mt-1">📞 {phone}</p>}
      </div>
    </div>
  );
}

export default function Invoices() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [showMarketing, setShowMarketing] = useState(false);
  const [marketingMsg, setMarketingMsg] = useState("");

  const { data: sales = [], isLoading } = trpc.sales.list.useQuery({ limit: 200 });
  const { data: selectedSale } = trpc.sales.getById.useQuery({ id: selectedId! }, { enabled: selectedId !== null });
  const { data: settings } = trpc.shop.getSettings.useQuery();

  const currency = settings?.currencySymbol ?? "ريال";

  const filtered = sales.filter((s) => {
    const matchSearch = !search || s.invoiceNumber.toLowerCase().includes(search.toLowerCase()) || (s.customerName ?? "").includes(search) || (s.customerPhone ?? "").includes(search);
    const matchStatus = statusFilter === "all" || s.status === statusFilter;
    return matchSearch && matchStatus;
  });

  // Customers with phone numbers
  const customersWithPhone = Array.from(
    new Map(
      sales
        .filter((s) => s.customerPhone)
        .map((s) => [s.customerPhone, { name: s.customerName ?? "عميل", phone: s.customerPhone! }])
    ).values()
  );

  const handlePrint = () => {
    const printContent = document.getElementById("invoice-print");
    if (!printContent) return;
    const win = window.open("", "_blank");
    if (!win) return;
    win.document.write(`
      <html dir="rtl">
        <head>
          <title>فاتورة ${selectedSale?.invoiceNumber}</title>
          <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&family=Amiri:wght@400;700&display=swap" rel="stylesheet">
          <style>body { margin: 0; padding: 20px; } @page { size: A4; margin: 15mm; }</style>
        </head>
        <body>${printContent.innerHTML}</body>
      </html>
    `);
    win.document.close();
    win.focus();
    setTimeout(() => { win.print(); win.close(); }, 600);
  };

  const handleWhatsApp = (phone: string, name: string) => {
    if (!marketingMsg.trim()) { toast.error("يرجى كتابة رسالة التسويق أولاً"); return; }
    const msg = encodeURIComponent(`${marketingMsg}\n\nمع تحيات ${settings?.shopName ?? "طيب الحي"}`);
    const cleanPhone = phone.replace(/\D/g, "");
    window.open(`https://wa.me/${cleanPhone}?text=${msg}`, "_blank");
    toast.success(`تم فتح واتساب للتواصل مع ${name}`);
  };

  const statusColor = (s?: string | null) => {
    if (s === "completed") return "bg-green-900/30 text-green-300 border-green-700/40";
    if (s === "refunded") return "bg-blue-900/30 text-blue-300 border-blue-700/40";
    return "bg-red-900/30 text-red-300 border-red-700/40";
  };
  const statusLabel = (s?: string | null) => {
    if (s === "completed") return "مكتملة";
    if (s === "refunded") return "مستردة";
    return "ملغاة";
  };

  const totalRevenue = filtered.filter(s => s.status === "completed").reduce((sum, s) => sum + Number(s.total), 0);

  return (
    <div className="space-y-5" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-amber-300" style={{ fontFamily: "'Amiri', serif" }}>الفواتير</h1>
          <p className="text-muted-foreground text-sm mt-1">{sales.length} فاتورة · إجمالي الإيرادات: {totalRevenue.toFixed(2)} {currency}</p>
        </div>
        {isAdmin && (
          <Button onClick={() => setShowMarketing(true)} variant="outline" className="border-green-600/40 text-green-400 hover:bg-green-900/20 gap-2">
            <MessageCircle className="w-4 h-4" />
            إرسال عروض للعملاء
          </Button>
        )}
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "مكتملة", count: sales.filter(s => s.status === "completed").length, color: "text-green-400" },
          { label: "ملغاة", count: sales.filter(s => s.status === "cancelled").length, color: "text-red-400" },
          { label: "عملاء بهاتف", count: customersWithPhone.length, color: "text-blue-400" },
        ].map((stat) => (
          <Card key={stat.label} className="border-amber-800/30 bg-card">
            <CardContent className="p-3 text-center">
              <p className={`text-2xl font-bold ${stat.color}`}>{stat.count}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{stat.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="بحث برقم الفاتورة أو اسم العميل أو الهاتف..." className="pr-9 bg-input border-border" />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-36 bg-input border-border text-sm">
            <Filter className="w-3.5 h-3.5 ml-1 text-amber-400" />
            <SelectValue placeholder="الحالة" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">جميع الحالات</SelectItem>
            <SelectItem value="completed">مكتملة</SelectItem>
            <SelectItem value="cancelled">ملغاة</SelectItem>
            <SelectItem value="refunded">مستردة</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Invoices table */}
      <Card className="border-amber-800/30 bg-card">
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex items-center justify-center py-16"><Loader2 className="w-8 h-8 animate-spin text-amber-400" /></div>
          ) : !filtered.length ? (
            <div className="p-10 text-center">
              <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-3 opacity-40" />
              <p className="text-muted-foreground">لا توجد فواتير</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b border-border bg-muted/20">
                  <tr className="text-muted-foreground text-xs">
                    <th className="text-right p-3 font-medium">رقم الفاتورة</th>
                    <th className="text-right p-3 font-medium">العميل</th>
                    <th className="text-right p-3 font-medium">الهاتف</th>
                    <th className="text-right p-3 font-medium">الموظف</th>
                    <th className="text-right p-3 font-medium">الإجمالي</th>
                    <th className="text-right p-3 font-medium">الدفع</th>
                    <th className="text-right p-3 font-medium">الحالة</th>
                    <th className="text-right p-3 font-medium">التاريخ</th>
                    <th className="text-right p-3 font-medium">إجراءات</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((sale) => (
                    <tr key={sale.id} className="border-b border-border/30 hover:bg-muted/10 transition-colors">
                      <td className="p-3"><Badge variant="outline" className="font-mono text-xs border-amber-600/40 text-amber-400">{sale.invoiceNumber}</Badge></td>
                      <td className="p-3 text-sm">{sale.customerName ?? <span className="text-muted-foreground">—</span>}</td>
                      <td className="p-3">
                        {sale.customerPhone ? (
                          <div className="flex items-center gap-1">
                            <span className="text-xs text-blue-400 font-mono" dir="ltr">{sale.customerPhone}</span>
                            <a href={`https://wa.me/${sale.customerPhone?.replace(/\D/g, "")}`} target="_blank" rel="noopener noreferrer" className="text-green-400 hover:text-green-300">
                              <MessageCircle className="w-3.5 h-3.5" />
                            </a>
                          </div>
                        ) : <span className="text-muted-foreground text-xs">—</span>}
                      </td>
                      <td className="p-3 text-xs text-muted-foreground">{sale.staffName ?? "—"}</td>
                      <td className="p-3 font-semibold text-green-400">{Number(sale.total).toFixed(2)} {currency}</td>
                      <td className="p-3 text-xs text-muted-foreground">
                        {sale.paymentMethod === "cash" ? "نقدي" : sale.paymentMethod === "card" ? "بطاقة" : "تحويل"}
                      </td>
                      <td className="p-3">
                        <Badge variant="outline" className={cn("text-xs", statusColor(sale.status))}>{statusLabel(sale.status)}</Badge>
                      </td>
                      <td className="p-3 text-xs text-muted-foreground">{new Date(sale.createdAt).toLocaleDateString("ar-SA")}</td>
                      <td className="p-3">
                        <Button size="icon" variant="ghost" className="h-7 w-7 text-amber-400 hover:bg-amber-900/20" onClick={() => setSelectedId(sale.id)} title="عرض الفاتورة">
                          <Eye className="w-3.5 h-3.5" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Invoice detail dialog */}
      <Dialog open={selectedId !== null} onOpenChange={() => setSelectedId(null)}>
        <DialogContent className="max-w-3xl bg-white text-black p-0 overflow-auto max-h-[92vh]" dir="rtl">
          <div className="flex items-center justify-between p-4 border-b bg-amber-50">
            <h2 className="font-bold text-amber-800 flex items-center gap-2"><FileText className="w-4 h-4" /> فاتورة {selectedSale?.invoiceNumber}</h2>
            <div className="flex gap-2">
              {selectedSale?.customerPhone && (
                <Button size="sm" variant="outline" onClick={() => handleWhatsApp(selectedSale.customerPhone!, selectedSale.customerName ?? "العميل")} className="gap-1 border-green-600 text-green-700 hover:bg-green-50 text-xs">
                  <MessageCircle className="w-3 h-3" /> واتساب
                </Button>
              )}
              <Button size="sm" variant="outline" onClick={handlePrint} className="gap-1 border-amber-600 text-amber-700 hover:bg-amber-50">
                <Printer className="w-3 h-3" /> طباعة
              </Button>
            </div>
          </div>
          {selectedSale && <InvoicePrint sale={selectedSale as SaleWithItems} settings={settings ?? null} />}
        </DialogContent>
      </Dialog>

      {/* Marketing Dialog */}
      <Dialog open={showMarketing} onOpenChange={setShowMarketing}>
        <DialogContent className="border-amber-800/30 bg-card max-w-lg" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-amber-300 flex items-center gap-2">
              <Users className="w-5 h-5" /> إرسال عروض للعملاء
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="p-3 rounded-lg bg-blue-900/20 border border-blue-700/30">
              <p className="text-sm text-blue-300 flex items-center gap-2">
                <Phone className="w-4 h-4" />
                {customersWithPhone.length} عميل لديهم أرقام هواتف مسجلة
              </p>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground mb-1 block">نص الرسالة التسويقية</Label>
              <Textarea
                value={marketingMsg}
                onChange={(e) => setMarketingMsg(e.target.value)}
                rows={4}
                placeholder="مثال: عروض خاصة على العود الهندي بخصم 20%! تفضلوا بزيارتنا..."
                className="bg-input border-border resize-none"
              />
            </div>
            <div className="max-h-48 overflow-y-auto space-y-2">
              <p className="text-xs text-muted-foreground font-medium">قائمة العملاء:</p>
              {customersWithPhone.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">لا يوجد عملاء بأرقام هواتف بعد</p>
              ) : (
                customersWithPhone.map((c) => (
                  <div key={c.phone} className="flex items-center justify-between p-2 rounded-lg bg-muted/20 border border-border/40">
                    <div>
                      <p className="text-sm font-medium">{c.name}</p>
                      <p className="text-xs text-muted-foreground font-mono" dir="ltr">{c.phone}</p>
                    </div>
                    <Button size="sm" onClick={() => handleWhatsApp(c.phone, c.name)} className="bg-green-700 hover:bg-green-600 text-white gap-1 text-xs h-7">
                      <Send className="w-3 h-3" /> إرسال
                    </Button>
                  </div>
                ))
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
