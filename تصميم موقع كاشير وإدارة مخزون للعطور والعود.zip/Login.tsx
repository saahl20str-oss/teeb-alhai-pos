import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Eye, EyeOff, LogIn, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

export default function Login() {
  const [, setLocation] = useLocation();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [checkingSetup, setCheckingSetup] = useState(true);
  const [logoUrl, setLogoUrl] = useState<string | null>(null);

  // Get shop settings for logo
  const { data: settings } = trpc.shop.getSettings.useQuery();

  useEffect(() => {
    if (settings?.logoUrl) setLogoUrl(settings.logoUrl);
  }, [settings]);

  // Check if first-run setup is needed
  useEffect(() => {
    fetch("/api/auth/local/setup-status")
      .then((r) => r.json())
      .then((data) => {
        if (data.needsSetup) {
          setLocation("/setup");
        } else {
          setCheckingSetup(false);
        }
      })
      .catch(() => setCheckingSetup(false));
  }, [setLocation]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error("يرجى إدخال البريد الإلكتروني وكلمة المرور");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/auth/local/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
        credentials: "include",
      });
      const data = await res.json();
      if (data.success) {
        toast.success(`مرحباً ${data.user?.name || ""}!`);
        // Small delay to allow cookie to be set
        setTimeout(() => {
          window.location.href = "/dashboard";
        }, 300);
      } else {
        toast.error(data.error || "فشل تسجيل الدخول");
      }
    } catch {
      toast.error("حدث خطأ في الاتصال. حاول مرة أخرى.");
    } finally {
      setLoading(false);
    }
  };

  if (checkingSetup) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0a0a0a]">
        <Loader2 className="h-8 w-8 animate-spin text-amber-400" />
      </div>
    );
  }

  return (
    <div
      className="min-h-screen flex items-center justify-center relative overflow-hidden"
      style={{
        background: "linear-gradient(135deg, #0a0a0a 0%, #1a0f00 50%, #0a0a0a 100%)",
      }}
    >
      {/* Decorative background circles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 rounded-full bg-amber-900/10 blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-96 h-96 rounded-full bg-amber-800/10 blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-amber-950/5 blur-3xl" />
      </div>

      {/* Saffron particles */}
      {[...Array(12)].map((_, i) => (
        <div
          key={i}
          className="absolute w-1 h-1 rounded-full bg-amber-400/30"
          style={{
            top: `${Math.random() * 100}%`,
            left: `${Math.random() * 100}%`,
            animation: `float ${3 + Math.random() * 4}s ease-in-out infinite`,
            animationDelay: `${Math.random() * 3}s`,
          }}
        />
      ))}

      <div className="relative z-10 w-full max-w-md px-4">
        {/* Logo */}
        <div className="flex flex-col items-center mb-8">
          {logoUrl ? (
            <img
              src={logoUrl}
              alt="طيب الحي"
              className="w-28 h-28 rounded-full object-cover border-4 border-amber-400/40 shadow-2xl shadow-amber-900/50 mb-4"
            />
          ) : (
            <div className="w-28 h-28 rounded-full bg-gradient-to-br from-amber-800 to-amber-600 flex items-center justify-center border-4 border-amber-400/40 shadow-2xl shadow-amber-900/50 mb-4">
              <span className="text-white text-3xl font-bold">ط</span>
            </div>
          )}
          <h1 className="text-2xl font-bold text-amber-300 text-center" style={{ fontFamily: "'Amiri', serif" }}>
            {settings?.shopName || "طيب الحي للعود والأدهان"}
          </h1>
          <p className="text-amber-500/70 text-sm mt-1">نظام إدارة المحل</p>
        </div>

        {/* Login Card */}
        <Card className="bg-black/60 border-amber-800/30 backdrop-blur-xl shadow-2xl">
          <CardHeader className="pb-4 pt-6 px-6">
            <h2 className="text-xl font-semibold text-amber-200 text-center">تسجيل الدخول</h2>
            <p className="text-amber-500/60 text-sm text-center mt-1">أدخل بيانات حسابك للمتابعة</p>
          </CardHeader>
          <CardContent className="px-6 pb-6">
            <form onSubmit={handleLogin} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-amber-300 text-sm">
                  البريد الإلكتروني
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="example@email.com"
                  dir="ltr"
                  className="bg-amber-950/20 border-amber-800/40 text-amber-100 placeholder:text-amber-700/50 focus:border-amber-500 focus:ring-amber-500/20"
                  autoComplete="email"
                  disabled={loading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-amber-300 text-sm">
                  كلمة المرور
                </Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    dir="ltr"
                    className="bg-amber-950/20 border-amber-800/40 text-amber-100 placeholder:text-amber-700/50 focus:border-amber-500 focus:ring-amber-500/20 pr-10"
                    autoComplete="current-password"
                    disabled={loading}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-amber-600 hover:text-amber-400 transition-colors"
                    tabIndex={-1}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <Button
                type="submit"
                disabled={loading}
                className="w-full bg-gradient-to-r from-amber-700 to-amber-600 hover:from-amber-600 hover:to-amber-500 text-white font-semibold py-2.5 shadow-lg shadow-amber-900/30 transition-all duration-200 active:scale-[0.98]"
              >
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin ml-2" />
                    جاري تسجيل الدخول...
                  </>
                ) : (
                  <>
                    <LogIn className="h-4 w-4 ml-2" />
                    دخول
                  </>
                )}
              </Button>
            </form>

            <div className="mt-6 pt-4 border-t border-amber-800/20 text-center">
              <p className="text-amber-600/50 text-xs">
                هذا النظام مخصص لموظفي المحل فقط
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Back to landing */}
        <div className="text-center mt-4">
          <button
            onClick={() => setLocation("/")}
            className="text-amber-600/60 hover:text-amber-400 text-sm transition-colors"
          >
            ← العودة للصفحة الرئيسية
          </button>
        </div>
      </div>

      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px) scale(1); opacity: 0.3; }
          50% { transform: translateY(-20px) scale(1.5); opacity: 0.6; }
        }
      `}</style>
    </div>
  );
}
