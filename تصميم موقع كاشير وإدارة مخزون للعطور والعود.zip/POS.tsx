import { useState, useRef } from "react";
import { trpc } from "@/lib/trpc";
import { BarcodeScanner } from "@/components/BarcodeScanner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import {
  ShoppingCart, ScanLine, Trash2, Plus, Minus, CheckCircle,
  Percent, DollarSign, User, Printer, Phone, Search, UserCheck, Receipt, Loader2
} from "lucide-react";
import { useLocation } from "wouter";

type CartItem = {
  productId: number;
  code: string;
  name: string;
  unit: string;
  unitPrice: number;
  quantity: number;
  maxQty: number;
};

export default function POS() {
  const [, setLocation] = useLocation();
  const [codeInput, setCodeInput] = useState("");
  const [searchInput, setSearchInput] = useState("");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [staffName, setStaffName] = useState("");
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [discountType, setDiscountType] = useState<"none" | "percentage" | "fixed">("none");
  const [discountValue, setDiscountValue] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<"cash" | "card" | "transfer">("cash");
  const [notes, setNotes] = useState("");
  const [completedSale, setCompletedSale] = useState<{ invoiceNumber: string; total: number } | null>(null);
  const [scannerOpen, setScannerOpen] = useState(false);
  const codeRef = useRef<HTMLInputElement>(null);
  const utils = trpc.useUtils();

  const { data: settings } = trpc.shop.getSettings.useQuery();
  const currency = settings?.currencySymbol ?? "ريال";

  const { data: allProducts = [] } = trpc.products.list.useQuery({});

  const { data: customerData, refetch: lookupCustomer } = trpc.customers.getByPhone.useQuery(
    { phone: customerPhone },
    { enabled: false }
  );

  const createSale = trpc.sales.create.useMutation({
    onSuccess: (sale) => {
      setCompletedSale({ invoiceNumber: sale.invoiceNumber, total: Number(sale.total) });
      setCart([]);
      setCustomerName("");
      setCustomerPhone("");
      setDiscountType("none");
      setDiscountValue("");
      setNotes("");
      utils.products.list.invalidate();
      utils.products.getLowStock.invalidate();
      utils.sales.list.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });

  const addToCart = (product: { id: number; code: string; name: string; unit?: string | null; sellingPrice: string; quantity: number }) => {
    if (product.quantity <= 0) {
      toast.error(`المنتج "${product.name}" غير متوفر في المخزون`);
      return;
    }
    setCart((prev) => {
      const existing = prev.find((i) => i.productId === product.id);
      if (existing) {
        if (existing.quantity >= product.quantity) {
          toast.warning(`الكمية المتاحة: ${product.quantity} فقط`);
          return prev;
        }
        return prev.map((i) => i.productId === product.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, {
        productId: product.id,
        code: product.code,
        name: product.name,
        unit: product.unit ?? "قطعة",
        unitPrice: Number(product.sellingPrice),
        quantity: 1,
        maxQty: product.quantity,
      }];
    });
    setSearchInput("");
    setCodeInput("");
    codeRef.current?.focus();
  };

  const handleScan = () => {
    const code = codeInput.trim();
    if (!code) return;
    const product = allProducts.find((p) => p.code === code);
    if (product) {
      addToCart(product);
    } else {
      toast.error(`لم يتم العثور على منتج بالكود: ${code}`);
    }
    setCodeInput("");
  };

  const handleCameraScan = (code: string) => {
    setScannerOpen(false);
    const product = allProducts.find((p) => p.code === code);
    if (product) {
      addToCart(product);
      toast.success(`تم إضافة: ${product.name}`);
    } else {
      // Try partial match
      const partial = allProducts.find((p) => p.code.includes(code) || code.includes(p.code));
      if (partial) {
        addToCart(partial);
        toast.success(`تم إضافة: ${partial.name}`);
      } else {
        setCodeInput(code);
        toast.warning(`الكود: ${code} — لم يُعثر على منتج مطابق. يمكنك تعديل الكود يدوياً.`);
        codeRef.current?.focus();
      }
    }
  };

  const updateQty = (productId: number, delta: number) => {
    setCart((prev) =>
      prev.map((i) => {
        if (i.productId !== productId) return i;
        const newQty = i.quantity + delta;
        if (newQty > i.maxQty) { toast.warning("تجاوز الكمية المتاحة"); return i; }
        return { ...i, quantity: Math.max(0, newQty) };
      }).filter((i) => i.quantity > 0)
    );
  };

  const removeItem = (productId: number) => setCart((prev) => prev.filter((i) => i.productId !== productId));

  const subtotal = cart.reduce((sum, i) => sum + i.unitPrice * i.quantity, 0);
  let discountAmount = 0;
  if (discountType === "percentage" && discountValue) discountAmount = (subtotal * Number(discountValue)) / 100;
  else if (discountType === "fixed" && discountValue) discountAmount = Math.min(Number(discountValue), subtotal);
  const total = subtotal - discountAmount;

  const handlePhoneLookup = async () => {
    if (!customerPhone.trim()) return;
    const result = await lookupCustomer();
    if (result.data) {
      setCustomerName(result.data.name);
      toast.success(`تم العثور على العميل: ${result.data.name} — ${result.data.totalPurchases} زيارة سابقة`);
    } else {
      toast.info("عميل جديد — سيتم تسجيله تلقائياً عند إتمام البيع");
    }
  };

  const handleCheckout = () => {
    if (!cart.length) { toast.error("السلة فارغة"); return; }
    if (!staffName.trim()) { toast.error("يرجى إدخال اسم الموظف المسؤول عن البيع"); return; }
    createSale.mutate({
      staffName: staffName.trim(),
      customerName: customerName.trim() || undefined,
      customerPhone: customerPhone.trim() || undefined,
      items: cart.map((i) => ({ productId: i.productId, quantity: i.quantity, unitPrice: i.unitPrice })),
      discountType: discountType !== "none" ? discountType : undefined,
      discountValue: discountValue ? Number(discountValue) : undefined,
      paymentMethod,
      notes: notes.trim() || undefined,
    });
  };

  const searchResults = searchInput.length >= 2
    ? allProducts.filter((p) => p.name.includes(searchInput) || p.code.toLowerCase().includes(searchInput.toLowerCase())).slice(0, 8)
    : [];

  return (
    <div className="space-y-4" dir="rtl">
      <div>
        <h1 className="text-2xl font-bold text-amber-300" style={{ fontFamily: "'Amiri', serif" }}>الكاشير</h1>
        <p className="text-muted-foreground text-sm mt-1">نقطة البيع — امسح الباركود أو أدخل الكود</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
        {/* Left: Scanner + Search */}
        <div className="lg:col-span-3 space-y-4">
          {/* Scanner */}
          <Card className="border-amber-800/30 bg-card">
            <CardContent className="p-4 space-y-3">
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <ScanLine className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-amber-400" />
                  <Input
                    ref={codeRef}
                    value={codeInput}
                    onChange={(e) => setCodeInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleScan()}
                    placeholder="امسح الباركود أو أدخل الكود + Enter..."
                    className="pr-9 bg-input border-border text-base"
                    autoFocus
                  />
                </div>
                {/* Camera scan button */}
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setScannerOpen(true)}
                  className="border-amber-700/40 text-amber-300 hover:bg-amber-900/20 gap-1.5 px-3 shrink-0"
                  title="مسح بالكاميرا"
                >
                  <ScanLine className="w-4 h-4" />
                  <span className="hidden sm:inline text-xs">كاميرا</span>
                </Button>
                <Button onClick={handleScan} className="bg-amber-600 hover:bg-amber-500 text-white px-4">
                  إضافة
                </Button>
              </div>

              {/* Product search */}
              <div className="relative">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  value={searchInput}
                  onChange={(e) => setSearchInput(e.target.value)}
                  placeholder="بحث بالاسم أو الكود..."
                  className="pr-9 bg-input border-border text-sm"
                />
                {searchResults.length > 0 && (
                  <div className="absolute top-full right-0 left-0 z-50 mt-1 bg-popover border border-border rounded-lg shadow-xl overflow-hidden">
                    {searchResults.map((p) => (
                      <button
                        key={p.id}
                        className="w-full flex items-center justify-between px-3 py-2.5 hover:bg-amber-900/20 text-sm transition-colors border-b border-border/50 last:border-0"
                        onClick={() => addToCart(p)}
                      >
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="text-xs border-amber-600/40 text-amber-400 font-mono">{p.code}</Badge>
                          <span className="font-medium">{p.name}</span>
                        </div>
                        <div className="flex items-center gap-3 shrink-0">
                          <span className="text-muted-foreground text-xs">مخزون: {p.quantity}</span>
                          <span className="text-amber-300 font-semibold">{Number(p.sellingPrice).toFixed(2)} {currency}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Cart items */}
          <Card className="border-amber-800/30 bg-card">
            <CardHeader className="pb-2 pt-4">
              <CardTitle className="text-base flex items-center gap-2 text-amber-300">
                <ShoppingCart className="w-4 h-4" />
                السلة
                {cart.length > 0 && <Badge className="bg-amber-900/50 text-amber-300 border-amber-700/50 mr-auto">{cart.length} صنف</Badge>}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {!cart.length ? (
                <div className="text-center py-8 text-muted-foreground">
                  <ShoppingCart className="w-10 h-10 mx-auto mb-2 opacity-30" />
                  <p className="text-sm">السلة فارغة — امسح كود منتج للبدء</p>
                </div>
              ) : (
                <div className="space-y-2 max-h-72 overflow-y-auto">
                  {cart.map((item) => (
                    <div key={item.productId} className="flex items-center gap-2 p-2 rounded-lg bg-muted/20 border border-border/50">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{item.name}</p>
                        <p className="text-xs text-muted-foreground font-mono">{item.code} · {item.unit}</p>
                        <p className="text-xs text-amber-400">{item.unitPrice.toFixed(2)} {currency} × {item.quantity} = <strong>{(item.unitPrice * item.quantity).toFixed(2)} {currency}</strong></p>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <Button size="icon" variant="ghost" className="w-6 h-6" onClick={() => updateQty(item.productId, -1)}><Minus className="w-3 h-3" /></Button>
                        <span className="w-6 text-center text-sm font-bold">{item.quantity}</span>
                        <Button size="icon" variant="ghost" className="w-6 h-6" onClick={() => updateQty(item.productId, 1)}><Plus className="w-3 h-3" /></Button>
                        <Button size="icon" variant="ghost" className="w-6 h-6 text-red-400" onClick={() => removeItem(item.productId)}><Trash2 className="w-3 h-3" /></Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Right: Checkout Panel */}
        <div className="lg:col-span-2">
          <Card className="border-amber-800/30 bg-card sticky top-4">
            <CardHeader className="pb-3">
              <CardTitle className="text-base text-amber-300">تفاصيل البيع</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Staff Name - Required */}
              <div>
                <Label className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                  <UserCheck className="w-3 h-3 text-amber-400" />
                  اسم الموظف <span className="text-red-400 mr-1">*</span>
                </Label>
                <Input
                  value={staffName}
                  onChange={(e) => setStaffName(e.target.value)}
                  placeholder="اسم الموظف المسؤول"
                  className="bg-input border-border text-sm h-9"
                />
              </div>

              <Separator className="bg-border/50" />

              {/* Customer Phone */}
              <div>
                <Label className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                  <Phone className="w-3 h-3" />
                  رقم هاتف العميل
                </Label>
                <div className="flex gap-1.5">
                  <Input
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    onBlur={handlePhoneLookup}
                    placeholder="05xxxxxxxx"
                    className="bg-input border-border text-sm h-9"
                    dir="ltr"
                  />
                  <Button size="icon" variant="outline" className="h-9 w-9 shrink-0 border-amber-600/40 hover:bg-amber-900/20" onClick={handlePhoneLookup} title="بحث عن العميل">
                    <Search className="w-3.5 h-3.5 text-amber-400" />
                  </Button>
                </div>
              </div>

              {/* Customer Name */}
              <div>
                <Label className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                  <User className="w-3 h-3" />
                  اسم العميل
                </Label>
                <Input
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="اسم العميل (اختياري)"
                  className="bg-input border-border text-sm h-9"
                />
              </div>

              <Separator className="bg-border/50" />

              {/* Discount */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                    <Percent className="w-3 h-3" /> نوع الخصم
                  </Label>
                  <Select value={discountType} onValueChange={(v) => setDiscountType(v as typeof discountType)}>
                    <SelectTrigger className="bg-input border-border h-9 text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">بدون خصم</SelectItem>
                      <SelectItem value="percentage">نسبة %</SelectItem>
                      <SelectItem value="fixed">مبلغ ثابت</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {discountType !== "none" && (
                  <div>
                    <Label className="text-xs text-muted-foreground mb-1 block">
                      {discountType === "percentage" ? "النسبة %" : `المبلغ (${currency})`}
                    </Label>
                    <Input
                      type="number"
                      value={discountValue}
                      onChange={(e) => setDiscountValue(e.target.value)}
                      className="bg-input border-border h-9 text-sm"
                    />
                  </div>
                )}
              </div>

              {/* Payment method */}
              <div>
                <Label className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                  <DollarSign className="w-3 h-3" /> طريقة الدفع
                </Label>
                <div className="flex gap-2">
                  {(["cash", "card", "transfer"] as const).map((m) => (
                    <button
                      key={m}
                      onClick={() => setPaymentMethod(m)}
                      className={`flex-1 py-2 rounded-lg text-xs font-medium border transition-colors ${
                        paymentMethod === m
                          ? "bg-amber-600/30 border-amber-600/60 text-amber-300"
                          : "border-border text-muted-foreground hover:border-amber-700/40"
                      }`}
                    >
                      {m === "cash" ? "💵 نقدي" : m === "card" ? "💳 بطاقة" : "🏦 تحويل"}
                    </button>
                  ))}
                </div>
              </div>

              {/* Notes */}
              <div>
                <Input
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="ملاحظات (اختياري)"
                  className="bg-input border-border text-sm h-9"
                />
              </div>

              <Separator className="bg-border/50" />

              {/* Totals */}
              <div className="space-y-1.5 text-sm">
                <div className="flex justify-between text-muted-foreground">
                  <span>المجموع الفرعي</span>
                  <span>{subtotal.toFixed(2)} {currency}</span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between text-green-400">
                    <span>الخصم</span>
                    <span>- {discountAmount.toFixed(2)} {currency}</span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-lg text-amber-300 pt-1 border-t border-border/50">
                  <span>الإجمالي</span>
                  <span>{total.toFixed(2)} {currency}</span>
                </div>
              </div>

              <Button
                onClick={handleCheckout}
                disabled={!cart.length || createSale.isPending}
                className="w-full bg-amber-600 hover:bg-amber-500 text-white font-bold py-5 text-base shadow-lg shadow-amber-900/40 gap-2"
              >
                {createSale.isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : <Receipt className="w-5 h-5" />}
                {createSale.isPending ? "جاري المعالجة..." : `إتمام البيع — ${total.toFixed(2)} ${currency}`}
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Success Dialog */}
      <Dialog open={!!completedSale} onOpenChange={() => setCompletedSale(null)}>
        <DialogContent className="border-amber-800/30 bg-card text-center" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-amber-300 text-xl flex items-center justify-center gap-2">
              <CheckCircle className="w-6 h-6 text-green-400" />
              تمت عملية البيع بنجاح
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="bg-amber-900/20 rounded-xl p-4 border border-amber-700/30">
              <p className="text-muted-foreground text-sm mb-1">رقم الفاتورة</p>
              <p className="text-2xl font-bold text-amber-300 font-mono">{completedSale?.invoiceNumber}</p>
            </div>
            <div className="bg-muted/30 rounded-xl p-4">
              <p className="text-muted-foreground text-sm mb-1">المبلغ المدفوع</p>
              <p className="text-3xl font-bold text-foreground">{completedSale?.total.toFixed(2)} {currency}</p>
            </div>
            <div className="flex gap-2">
              <Button
                className="flex-1 bg-amber-600 hover:bg-amber-500 text-white"
                onClick={() => { setCompletedSale(null); setLocation("/invoices"); }}
              >
                <Printer className="w-4 h-4 ml-1" />
                عرض الفاتورة
              </Button>
              <Button variant="outline" className="flex-1 border-amber-600/40" onClick={() => setCompletedSale(null)}>
                بيع جديد
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Camera Barcode Scanner */}
      <BarcodeScanner
        open={scannerOpen}
        onClose={() => setScannerOpen(false)}
        onScan={handleCameraScan}
        title="مسح باركود المنتج"
        hint="وجّه الكاميرا نحو باركود المنتج لإضافته للسلة تلقائياً"
      />
    </div>
  );
}
