import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { invokeLLM } from "./_core/llm";
import { sendEmail, testSmtpConnection } from "./email";
import {
  getAllUsers,
  getCategories,
  getCustomers,
  getCustomerById,
  getDailySalesChart,
  getInventoryValue,
  getLowStockProducts,
  getMonthlySalesChart,
  getNextInvoiceNumber,
  getNotifications,
  getProductByCode,
  getProductById,
  getProducts,
  getSaleById,
  getSaleByInvoiceNumber,
  getSales,
  getSalesStats,
  getShopSettings,
  getTopProducts,
  addStockMovement,
  createProduct,
  createSale,
  deleteCustomer,
  deleteNotification,
  deleteProduct,
  markAllNotificationsRead,
  markNotificationRead,
  markNotificationSentToSupplier,
  snoozeNotification,
  updateCustomer,
  updateProduct,
  updateShopSettings,
  updateUserRole,
} from "./db";

// Admin-only middleware
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "هذه العملية تتطلب صلاحيات المدير" });
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── Shop Settings ──────────────────────────────────────────────────────────
  shop: router({
    getSettings: publicProcedure.query(async () => {
      return getShopSettings();
    }),

    updateSettings: adminProcedure
      .input(
        z.object({
          shopName: z.string().optional(),
          shopNameEn: z.string().optional(),
          address: z.string().optional(),
          phone: z.string().optional(),
          logoUrl: z.string().optional(),
          stampText: z.string().optional(),
          taxNumber: z.string().optional(),
          currency: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        await updateShopSettings(input);
        return { success: true };
      }),
  }),

  // ─── Users ──────────────────────────────────────────────────────────────────
  users: router({
    list: adminProcedure.query(async () => {
      return getAllUsers();
    }),

    updateRole: adminProcedure
      .input(z.object({ userId: z.number(), role: z.enum(["admin", "user"]) }))
      .mutation(async ({ input }) => {
        await updateUserRole(input.userId, input.role);
        return { success: true };
      }),
  }),

  // ─── Categories ─────────────────────────────────────────────────────────────
  categories: router({
    list: publicProcedure.query(async () => {
      return getCategories();
    }),
  }),

  // ─── Products ───────────────────────────────────────────────────────────────
  products: router({
    list: protectedProcedure
      .input(z.object({ categoryId: z.number().optional() }).optional())
      .query(async ({ input }) => {
        return getProducts(input?.categoryId);
      }),

    getByCode: protectedProcedure
      .input(z.object({ code: z.string() }))
      .query(async ({ input }) => {
        return getProductByCode(input.code);
      }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return getProductById(input.id);
      }),

    create: protectedProcedure
      .input(
        z.object({
          code: z.string().min(1),
          name: z.string().min(1),
          nameEn: z.string().optional(),
          categoryId: z.number(),
          description: z.string().optional(),
          imageUrl: z.string().optional(),
          costPrice: z.number().min(0),
          sellingPrice: z.number().min(0),
          quantity: z.number().min(0).default(0),
          lowStockThreshold: z.number().min(0).default(5),
          supplier: z.string().optional(),
          unit: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const product = await createProduct({
          ...input,
          costPrice: String(input.costPrice),
          sellingPrice: String(input.sellingPrice),
        });
        if (input.quantity > 0) {
          await addStockMovement({
            productId: product.id,
            type: "in",
            quantity: input.quantity,
            note: "إضافة مخزون أولي",
            userId: ctx.user.id,
          });
        }
        return product;
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          name: z.string().optional(),
          nameEn: z.string().optional(),
          categoryId: z.number().optional(),
          description: z.string().optional(),
          imageUrl: z.string().optional(),
          costPrice: z.number().optional(),
          sellingPrice: z.number().optional(),
          lowStockThreshold: z.number().optional(),
          supplier: z.string().optional(),
          unit: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, costPrice, sellingPrice, ...rest } = input;
        await updateProduct(id, {
          ...rest,
          ...(costPrice !== undefined ? { costPrice: String(costPrice) } : {}),
          ...(sellingPrice !== undefined ? { sellingPrice: String(sellingPrice) } : {}),
        });
        return { success: true };
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await deleteProduct(input.id);
        return { success: true };
      }),

    getLowStock: protectedProcedure.query(async () => {
      return getLowStockProducts();
    }),

    addStock: protectedProcedure
      .input(
        z.object({
          productId: z.number(),
          quantity: z.number().min(1),
          note: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        return addStockMovement({
          productId: input.productId,
          type: "in",
          quantity: input.quantity,
          note: input.note,
          userId: ctx.user.id,
        });
      }),

    adjustStock: adminProcedure
      .input(
        z.object({
          productId: z.number(),
          quantity: z.number().min(0),
          note: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        return addStockMovement({
          productId: input.productId,
          type: "adjustment",
          quantity: input.quantity,
          note: input.note ?? "تعديل مخزون",
          userId: ctx.user.id,
        });
      }),
  }),

  // ─── Sales / POS ────────────────────────────────────────────────────────────
  sales: router({
    list: protectedProcedure
      .input(z.object({ limit: z.number().optional(), offset: z.number().optional() }).optional())
      .query(async ({ input }) => {
        return getSales(input?.limit ?? 50, input?.offset ?? 0);
      }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return getSaleById(input.id);
      }),

    getByInvoiceNumber: protectedProcedure
      .input(z.object({ invoiceNumber: z.string() }))
      .query(async ({ input }) => {
        return getSaleByInvoiceNumber(input.invoiceNumber);
      }),

    create: protectedProcedure
      .input(
        z.object({
          customerName: z.string().optional(),
          items: z.array(
            z.object({
              productId: z.number(),
              quantity: z.number().min(1),
              unitPrice: z.number().min(0),
            })
          ).min(1),
          discountType: z.enum(["percentage", "fixed"]).optional(),
          discountValue: z.number().optional(),
          paymentMethod: z.enum(["cash", "card", "transfer"]).optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        return createSale({ ...input, userId: ctx.user.id });
      }),

    getNextInvoiceNumber: protectedProcedure.query(async () => {
      return getNextInvoiceNumber();
    }),
  }),

  // ─── Analytics ──────────────────────────────────────────────────────────────
  analytics: router({
    stats: adminProcedure
      .input(z.object({ period: z.enum(["day", "month", "year"]) }))
      .query(async ({ input }) => {
        return getSalesStats(input.period);
      }),

    dailyChart: adminProcedure
      .input(z.object({ days: z.number().optional() }).optional())
      .query(async ({ input }) => {
        return getDailySalesChart(input?.days ?? 30);
      }),

    monthlyChart: adminProcedure
      .input(z.object({ months: z.number().optional() }).optional())
      .query(async ({ input }) => {
        return getMonthlySalesChart(input?.months ?? 12);
      }),

    topProducts: adminProcedure
      .input(z.object({ limit: z.number().optional() }).optional())
      .query(async ({ input }) => {
        return getTopProducts(input?.limit ?? 10);
      }),

    inventoryValue: adminProcedure.query(async () => {
      return getInventoryValue();
    }),
  }),

  // ─── Notifications ──────────────────────────────────────────────────────────
  notifications: router({
    list: protectedProcedure
      .input(z.object({ unreadOnly: z.boolean().optional() }).optional())
      .query(async ({ input }) => {
        return getNotifications(input?.unreadOnly ?? false);
      }),

    markRead: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await markNotificationRead(input.id);
        return { success: true };
      }),

    markAllRead: protectedProcedure.mutation(async () => {
      await markAllNotificationsRead();
      return { success: true };
    }),
  }),

  // ─── AI Advisor ─────────────────────────────────────────────────────────────
  ai: router({
    chat: adminProcedure
      .input(
        z.object({
          messages: z.array(
            z.object({
              role: z.enum(["user", "assistant"]),
              content: z.string(),
            })
          ),
        })
      )
      .mutation(async ({ input }) => {
        // Gather real data for context
        const [stats, topProducts, lowStock, inventoryVal, monthlySales] = await Promise.all([
          getSalesStats("month"),
          getTopProducts(5),
          getLowStockProducts(),
          getInventoryValue(),
          getMonthlySalesChart(3),
        ]);

        const systemPrompt = `أنت مستشار أعمال ذكي متخصص في محلات العطور والعود والأدهان في السوق العربي.
اسم المحل: طيب الحي للعود والأدهان.

بيانات المحل الحالية:
- مبيعات هذا الشهر: ${stats.totalRevenue.toFixed(2)} ريال (${stats.totalSales} عملية بيع)
- قيمة المخزون بسعر التكلفة: ${inventoryVal.costValue.toFixed(2)} ريال
- قيمة المخزون بسعر البيع: ${inventoryVal.sellingValue.toFixed(2)} ريال
- إجمالي القطع في المخزون: ${inventoryVal.totalItems}
- المنتجات منخفضة المخزون: ${lowStock.length} منتج
- أكثر المنتجات مبيعاً: ${topProducts.map((p) => `${p.productName} (${p.totalQty} قطعة)`).join(", ")}
- مبيعات الأشهر الأخيرة: ${monthlySales.map((m) => `${m.month}: ${Number(m.revenue).toFixed(0)} ريال`).join(", ")}

قدم تحليلاً دقيقاً ونصائح عملية بناءً على هذه البيانات. كن محدداً وعملياً. أجب باللغة العربية دائماً.`;

        const response = await invokeLLM({
          messages: [
            { role: "system", content: systemPrompt },
            ...input.messages,
          ],
        });

        return {
          content: response.choices[0]?.message?.content ?? "عذراً، لم أتمكن من معالجة طلبك.",
        };
      }),
  }),
});

export type AppRouter = typeof appRouter;
