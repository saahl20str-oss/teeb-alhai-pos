import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import {
  TrendingUp,
  DollarSign,
  ShoppingCart,
  Package,
  Award,
  BarChart3,
} from "lucide-react";

const GOLD_COLORS = ["#d97706", "#b45309", "#92400e", "#78350f", "#451a03", "#fbbf24", "#f59e0b"];

export default function Analytics() {
  const [period, setPeriod] = useState<"day" | "month" | "year">("month");

  const { data: dayStats } = trpc.analytics.stats.useQuery({ period: "day" });
  const { data: monthStats } = trpc.analytics.stats.useQuery({ period: "month" });
  const { data: yearStats } = trpc.analytics.stats.useQuery({ period: "year" });
  const { data: dailyChart = [] } = trpc.analytics.dailyChart.useQuery({ days: 30 });
  const { data: monthlyChart = [] } = trpc.analytics.monthlyChart.useQuery({ months: 12 });
  const { data: topProducts = [] } = trpc.analytics.topProducts.useQuery({ limit: 8 });
  const { data: inventoryValue } = trpc.analytics.inventoryValue.useQuery();
  const { data: settings } = trpc.shop.getSettings.useQuery();
  const currency = settings?.currencySymbol ?? "ريال";

  const chartData = period === "day" ? dailyChart.slice(-7) : monthlyChart;
  const xKey = period === "day" ? "date" : "month";

  const formatCurrency = (v: number) => `${v.toFixed(0)} ${currency}`;
  const formatDate = (d: string) => {
    if (!d) return "";
    if (d.includes("-") && d.length === 10) {
      const [y, m, day] = d.split("-");
      return `${day}/${m}`;
    }
    if (d.length === 7) {
      const [y, m] = d.split("-");
      const months = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
      return months[Number(m) - 1] ?? d;
    }
    return d;
  };

  const profit = (inventoryValue?.sellingValue ?? 0) - (inventoryValue?.costValue ?? 0);

  return (
    <div className="space-y-6" dir="rtl">
      <div>
        <h1 className="text-2xl font-bold text-amber-300" style={{ fontFamily: "'Amiri', serif" }}>الإحصائيات والتقارير</h1>
        <p className="text-muted-foreground text-sm mt-1">تحليل شامل لأداء المحل</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-amber-800/30 bg-card">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <DollarSign className="w-8 h-8 text-amber-400 bg-amber-900/30 p-1.5 rounded-lg" />
              <Badge variant="outline" className="text-xs border-amber-700/40 text-amber-400">اليوم</Badge>
            </div>
            <p className="text-2xl font-bold text-amber-300">{(dayStats?.totalRevenue ?? 0).toFixed(0)}</p>
            <p className="text-xs text-muted-foreground mt-1">{currency} ({dayStats?.totalSales ?? 0} فاتورة)</p>
          </CardContent>
        </Card>

        <Card className="border-amber-800/30 bg-card">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <TrendingUp className="w-8 h-8 text-green-400 bg-green-900/30 p-1.5 rounded-lg" />
              <Badge variant="outline" className="text-xs border-green-700/40 text-green-400">الشهر</Badge>
            </div>
            <p className="text-2xl font-bold text-green-300">{(monthStats?.totalRevenue ?? 0).toFixed(0)}</p>
            <p className="text-xs text-muted-foreground mt-1">{currency} ({monthStats?.totalSales ?? 0} فاتورة)</p>
          </CardContent>
        </Card>

        <Card className="border-amber-800/30 bg-card">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <BarChart3 className="w-8 h-8 text-blue-400 bg-blue-900/30 p-1.5 rounded-lg" />
              <Badge variant="outline" className="text-xs border-blue-700/40 text-blue-400">السنة</Badge>
            </div>
            <p className="text-2xl font-bold text-blue-300">{(yearStats?.totalRevenue ?? 0).toFixed(0)}</p>
            <p className="text-xs text-muted-foreground mt-1">{currency} ({yearStats?.totalSales ?? 0} فاتورة)</p>
          </CardContent>
        </Card>

        <Card className="border-amber-800/30 bg-card">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <Package className="w-8 h-8 text-purple-400 bg-purple-900/30 p-1.5 rounded-lg" />
              <Badge variant="outline" className="text-xs border-purple-700/40 text-purple-400">المخزون</Badge>
            </div>
            <p className="text-2xl font-bold text-purple-300">{(inventoryValue?.sellingValue ?? 0).toFixed(0)}</p>
            <p className="text-xs text-muted-foreground mt-1">{currency} قيمة المخزون</p>
          </CardContent>
        </Card>
      </div>

      {/* Inventory value breakdown */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="border-amber-800/30 bg-card">
          <CardContent className="p-4 text-center">
            <p className="text-xs text-muted-foreground mb-1">قيمة التكلفة</p>
            <p className="text-xl font-bold text-orange-300">{(inventoryValue?.costValue ?? 0).toFixed(2)} {currency}</p>
          </CardContent>
        </Card>
        <Card className="border-amber-800/30 bg-card">
          <CardContent className="p-4 text-center">
            <p className="text-xs text-muted-foreground mb-1">قيمة البيع</p>
            <p className="text-xl font-bold text-amber-300">{(inventoryValue?.sellingValue ?? 0).toFixed(2)} {currency}</p>
          </CardContent>
        </Card>
        <Card className="border-amber-800/30 bg-card">
          <CardContent className="p-4 text-center">
            <p className="text-xs text-muted-foreground mb-1">هامش الربح المتوقع</p>
            <p className="text-xl font-bold text-green-300">{profit.toFixed(2)} {currency}</p>
          </CardContent>
        </Card>
      </div>

      {/* Sales chart */}
      <Card className="border-amber-800/30 bg-card">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base text-amber-300 flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              مخطط المبيعات
            </CardTitle>
            <div className="flex gap-1">
              {(["day", "month", "year"] as const).map((p) => (
                <button
                  key={p}
                  onClick={() => setPeriod(p)}
                  className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors ${
                    period === p
                      ? "bg-amber-600/30 text-amber-300 border border-amber-600/50"
                      : "text-muted-foreground hover:text-amber-300"
                  }`}
                >
                  {p === "day" ? "أسبوع" : p === "month" ? "سنة" : "سنوي"}
                </button>
              ))}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {chartData.length === 0 ? (
            <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">
              لا توجد بيانات مبيعات بعد
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={240}>
              <AreaChart data={chartData} margin={{ top: 5, right: 5, left: 5, bottom: 5 }}>
                <defs>
                  <linearGradient id="goldGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#d97706" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#d97706" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis
                  dataKey={xKey}
                  tickFormatter={formatDate}
                  tick={{ fill: "#9ca3af", fontSize: 11 }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  tickFormatter={formatCurrency}
                  tick={{ fill: "#9ca3af", fontSize: 11 }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip
                  contentStyle={{ background: "#1c1a14", border: "1px solid #92400e", borderRadius: "8px", color: "#fbbf24" }}
                  formatter={(v: number) => [`${v.toFixed(2)} ${currency}`, "المبيعات"]}
                  labelFormatter={formatDate}
                />
                <Area type="monotone" dataKey="revenue" stroke="#d97706" strokeWidth={2} fill="url(#goldGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>

      {/* Top products */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="border-amber-800/30 bg-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-base text-amber-300 flex items-center gap-2">
              <Award className="w-4 h-4" />
              أكثر المنتجات مبيعاً
            </CardTitle>
          </CardHeader>
          <CardContent>
            {topProducts.length === 0 ? (
              <p className="text-muted-foreground text-sm text-center py-4">لا توجد بيانات بعد</p>
            ) : (
              <div className="space-y-3">
                {topProducts.slice(0, 6).map((p, idx) => (
                  <div key={p.productId} className="flex items-center gap-3">
                    <span className="w-6 h-6 rounded-full bg-amber-900/40 text-amber-400 text-xs flex items-center justify-center font-bold shrink-0">
                      {idx + 1}
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{p.productName}</p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <div
                          className="h-1.5 rounded-full bg-amber-600"
                          style={{ width: `${Math.min(100, (p.totalQty / (topProducts[0]?.totalQty ?? 1)) * 100)}%` }}
                        />
                      </div>
                    </div>
                    <div className="text-left shrink-0">
                      <p className="text-xs font-bold text-amber-400">{p.totalQty} قطعة</p>
                      <p className="text-xs text-muted-foreground">{p.totalRevenue.toFixed(0)} {currency}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Bar chart */}
        <Card className="border-amber-800/30 bg-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-base text-amber-300 flex items-center gap-2">
              <ShoppingCart className="w-4 h-4" />
              عدد الفواتير الشهرية
            </CardTitle>
          </CardHeader>
          <CardContent>
            {monthlyChart.length === 0 ? (
              <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">
                لا توجد بيانات بعد
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={monthlyChart} margin={{ top: 5, right: 5, left: 5, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                  <XAxis dataKey="month" tickFormatter={formatDate} tick={{ fill: "#9ca3af", fontSize: 10 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: "#9ca3af", fontSize: 10 }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{ background: "#1c1a14", border: "1px solid #92400e", borderRadius: "8px", color: "#fbbf24" }}
                    formatter={(v: number) => [v, "فاتورة"]}
                    labelFormatter={formatDate}
                  />
                  <Bar dataKey="count" fill="#d97706" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
