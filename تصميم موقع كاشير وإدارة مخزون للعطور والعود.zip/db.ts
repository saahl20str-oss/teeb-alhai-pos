import { and, desc, eq, gte, lt, lte, sql, sum, count } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  InsertProduct,
  InsertSale,
  Customer,
  categories,
  customers,
  notifications,
  products,
  saleItems,
  sales,
  shopSettings,
  stockMovements,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ────────────────────────────────────────────────────────────────────
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  type TextField = (typeof textFields)[number];
  const assignNullable = (field: TextField) => {
    const value = user[field];
    if (value === undefined) return;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  };
  textFields.forEach(assignNullable);
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllUsers() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(users).orderBy(desc(users.createdAt));
}

export async function updateUserRole(userId: number, role: "admin" | "user") {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ role }).where(eq(users.id, userId));
}

// ─── Shop Settings ────────────────────────────────────────────────────────────
export async function getShopSettings() {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(shopSettings).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function updateShopSettings(data: Partial<typeof shopSettings.$inferInsert>) {
  const db = await getDb();
  if (!db) return;
  const existing = await getShopSettings();
  if (existing) {
    await db.update(shopSettings).set(data).where(eq(shopSettings.id, existing.id));
  } else {
    await db.insert(shopSettings).values(data as typeof shopSettings.$inferInsert);
  }
}

// ─── Categories ───────────────────────────────────────────────────────────────
export async function getCategories() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(categories).orderBy(categories.id);
}

// ─── Products ─────────────────────────────────────────────────────────────────
export async function getProducts(categoryId?: number) {
  const db = await getDb();
  if (!db) return [];
  const query = db.select().from(products);
  if (categoryId) {
    return query.where(and(eq(products.categoryId, categoryId), eq(products.isActive, true)));
  }
  return query.where(eq(products.isActive, true)).orderBy(desc(products.createdAt));
}

export async function getProductByCode(code: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(products).where(eq(products.code, code)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getProductById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(products).where(eq(products.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function createProduct(data: InsertProduct) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.insert(products).values(data);
  const result = await db.select().from(products).where(eq(products.code, data.code)).limit(1);
  return result[0];
}

export async function updateProduct(id: number, data: Partial<InsertProduct>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(products).set(data).where(eq(products.id, id));
}

export async function deleteProduct(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(products).set({ isActive: false }).where(eq(products.id, id));
}

export async function getLowStockProducts() {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(products)
    .where(
      and(
        eq(products.isActive, true),
        sql`${products.quantity} <= ${products.lowStockThreshold}`
      )
    );
}

// ─── Stock Movements ──────────────────────────────────────────────────────────
export async function addStockMovement(data: {
  productId: number;
  type: "in" | "out" | "adjustment";
  quantity: number;
  note?: string;
  userId?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");

  const product = await getProductById(data.productId);
  if (!product) throw new Error("Product not found");

  const previousQuantity = product.quantity;
  let newQuantity: number;
  if (data.type === "in") newQuantity = previousQuantity + data.quantity;
  else if (data.type === "out") newQuantity = previousQuantity - data.quantity;
  else newQuantity = data.quantity;

  if (newQuantity < 0) throw new Error("الكمية غير كافية في المخزون");

  await db.update(products).set({ quantity: newQuantity }).where(eq(products.id, data.productId));
  await db.insert(stockMovements).values({
    productId: data.productId,
    type: data.type,
    quantity: data.quantity,
    previousQuantity,
    newQuantity,
    note: data.note,
    userId: data.userId,
  });

  // Check low stock after movement
  const updatedProduct = await getProductById(data.productId);
  if (updatedProduct && updatedProduct.quantity <= updatedProduct.lowStockThreshold) {
    await createLowStockNotification(updatedProduct);
  }

  return { previousQuantity, newQuantity };
}

export async function getStockMovements(productId?: number, limit = 50) {
  const db = await getDb();
  if (!db) return [];
  const query = db.select().from(stockMovements);
  if (productId) {
    return query.where(eq(stockMovements.productId, productId)).orderBy(desc(stockMovements.createdAt)).limit(limit);
  }
  return query.orderBy(desc(stockMovements.createdAt)).limit(limit);
}

// ─── Sales ────────────────────────────────────────────────────────────────────
export async function getNextInvoiceNumber() {
  const db = await getDb();
  if (!db) return "INV-0001";
  const result = await db.select({ cnt: count() }).from(sales);
  const num = (result[0]?.cnt ?? 0) + 1;
  return `INV-${String(num).padStart(4, "0")}`;
}

export async function createSale(data: {
  userId?: number;
  customerName?: string;
  items: Array<{ productId: number; quantity: number; unitPrice: number }>;
  discountType?: "percentage" | "fixed";
  discountValue?: number;
  paymentMethod?: "cash" | "card" | "transfer";
  notes?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");

  const invoiceNumber = await getNextInvoiceNumber();
  let subtotal = 0;
  const itemsWithDetails = [];

  for (const item of data.items) {
    const product = await getProductById(item.productId);
    if (!product) throw new Error(`Product ${item.productId} not found`);
    if (product.quantity < item.quantity) throw new Error(`الكمية غير كافية للمنتج: ${product.name}`);
    const itemTotal = item.unitPrice * item.quantity;
    subtotal += itemTotal;
    itemsWithDetails.push({ product, item, itemTotal });
  }

  let discountAmount = 0;
  if (data.discountType === "percentage" && data.discountValue) {
    discountAmount = (subtotal * data.discountValue) / 100;
  } else if (data.discountType === "fixed" && data.discountValue) {
    discountAmount = data.discountValue;
  }
  const total = subtotal - discountAmount;

  await db.insert(sales).values({
    invoiceNumber,
    userId: data.userId,
    customerName: data.customerName,
    subtotal: String(subtotal),
    discountType: data.discountType,
    discountValue: data.discountValue ? String(data.discountValue) : "0",
    discountAmount: String(discountAmount),
    total: String(total),
    paymentMethod: data.paymentMethod ?? "cash",
    notes: data.notes,
    status: "completed",
  });

  const saleResult = await db.select().from(sales).where(eq(sales.invoiceNumber, invoiceNumber)).limit(1);
  const sale = saleResult[0];

  for (const { product, item, itemTotal } of itemsWithDetails) {
    await db.insert(saleItems).values({
      saleId: sale.id,
      productId: item.productId,
      productName: product.name,
      productCode: product.code,
      quantity: item.quantity,
      unitPrice: String(item.unitPrice),
      total: String(itemTotal),
    });
    await addStockMovement({
      productId: item.productId,
      type: "out",
      quantity: item.quantity,
      note: `بيع - فاتورة ${invoiceNumber}`,
      userId: data.userId,
    });
  }

  return sale;
}

export async function getSales(limit = 50, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(sales).orderBy(desc(sales.createdAt)).limit(limit).offset(offset);
}

export async function getSaleById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const saleResult = await db.select().from(sales).where(eq(sales.id, id)).limit(1);
  if (!saleResult.length) return null;
  const items = await db.select().from(saleItems).where(eq(saleItems.saleId, id));
  return { ...saleResult[0], items };
}

export async function getSaleByInvoiceNumber(invoiceNumber: string) {
  const db = await getDb();
  if (!db) return null;
  const saleResult = await db.select().from(sales).where(eq(sales.invoiceNumber, invoiceNumber)).limit(1);
  if (!saleResult.length) return null;
  const items = await db.select().from(saleItems).where(eq(saleItems.saleId, saleResult[0].id));
  return { ...saleResult[0], items };
}

// ─── Analytics ────────────────────────────────────────────────────────────────
export async function getSalesStats(period: "day" | "month" | "year") {
  const db = await getDb();
  if (!db) return { totalRevenue: 0, totalSales: 0, data: [] };

  const now = new Date();
  let startDate: Date;
  if (period === "day") {
    startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  } else if (period === "month") {
    startDate = new Date(now.getFullYear(), now.getMonth(), 1);
  } else {
    startDate = new Date(now.getFullYear(), 0, 1);
  }

  const result = await db
    .select({
      total: sum(sales.total),
      cnt: count(),
    })
    .from(sales)
    .where(and(gte(sales.createdAt, startDate), eq(sales.status, "completed")));

  return {
    totalRevenue: Number(result[0]?.total ?? 0),
    totalSales: Number(result[0]?.cnt ?? 0),
  };
}

export async function getDailySalesChart(days = 30) {
  const db = await getDb();
  if (!db) return [];
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - days);

  const result = await db
    .select({
      date: sql<string>`DATE(${sales.createdAt})`,
      revenue: sum(sales.total),
      cnt: count(),
    })
    .from(sales)
    .where(and(gte(sales.createdAt, startDate), eq(sales.status, "completed")))
    .groupBy(sql`DATE(${sales.createdAt})`)
    .orderBy(sql`DATE(${sales.createdAt})`);

  return result.map((r) => ({
    date: r.date,
    revenue: Number(r.revenue ?? 0),
    count: Number(r.cnt ?? 0),
  }));
}

export async function getMonthlySalesChart(months = 12) {
  const db = await getDb();
  if (!db) return [];
  const startDate = new Date();
  startDate.setMonth(startDate.getMonth() - months);

  const result = await db
    .select({
      month: sql<string>`DATE_FORMAT(${sales.createdAt}, '%Y-%m')`,
      revenue: sum(sales.total),
      cnt: count(),
    })
    .from(sales)
    .where(and(gte(sales.createdAt, startDate), eq(sales.status, "completed")))
    .groupBy(sql`DATE_FORMAT(${sales.createdAt}, '%Y-%m')`)
    .orderBy(sql`DATE_FORMAT(${sales.createdAt}, '%Y-%m')`);

  return result.map((r) => ({
    month: r.month,
    revenue: Number(r.revenue ?? 0),
    count: Number(r.cnt ?? 0),
  }));
}

export async function getTopProducts(limit = 10) {
  const db = await getDb();
  if (!db) return [];
  const result = await db
    .select({
      productId: saleItems.productId,
      productName: saleItems.productName,
      totalQty: sum(saleItems.quantity),
      totalRevenue: sum(saleItems.total),
    })
    .from(saleItems)
    .groupBy(saleItems.productId, saleItems.productName)
    .orderBy(desc(sum(saleItems.quantity)))
    .limit(limit);

  return result.map((r) => ({
    productId: r.productId,
    productName: r.productName,
    totalQty: Number(r.totalQty ?? 0),
    totalRevenue: Number(r.totalRevenue ?? 0),
  }));
}

export async function getInventoryValue() {
  const db = await getDb();
  if (!db) return { costValue: 0, sellingValue: 0, totalItems: 0 };
  const result = await db
    .select({
      costValue: sum(sql`${products.costPrice} * ${products.quantity}`),
      sellingValue: sum(sql`${products.sellingPrice} * ${products.quantity}`),
      totalItems: sum(products.quantity),
    })
    .from(products)
    .where(eq(products.isActive, true));

  return {
    costValue: Number(result[0]?.costValue ?? 0),
    sellingValue: Number(result[0]?.sellingValue ?? 0),
    totalItems: Number(result[0]?.totalItems ?? 0),
  };
}

// ─── Notifications ────────────────────────────────────────────────────────────
export async function createLowStockNotification(product: { id: number; name: string; quantity: number; lowStockThreshold: number }) {
  const db = await getDb();
  if (!db) return;
  await db.insert(notifications).values({
    type: "low_stock",
    title: `تنبيه: مخزون منخفض`,
    message: `المنتج "${product.name}" وصل إلى ${product.quantity} قطعة (الحد الأدنى: ${product.lowStockThreshold})`,
    productId: product.id,
    isRead: false,
  });
}

export async function getNotifications(unreadOnly = false) {
  const db = await getDb();
  if (!db) return [];
  if (unreadOnly) {
    return db.select().from(notifications).where(eq(notifications.isRead, false)).orderBy(desc(notifications.createdAt)).limit(20);
  }
  return db.select().from(notifications).orderBy(desc(notifications.createdAt)).limit(50);
}

export async function markNotificationRead(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(notifications).set({ isRead: true }).where(eq(notifications.id, id));
}

export async function markAllNotificationsRead() {
  const db = await getDb();
  if (!db) return;
  await db.update(notifications).set({ isRead: true }).where(eq(notifications.isRead, false));
}

// ─── Customers ───────────────────────────────────────────────────────────────
export async function getCustomers(search?: string): Promise<Customer[]> {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select().from(customers).orderBy(desc(customers.lastVisit)).limit(200);
  if (!search) return rows;
  const q = search.toLowerCase();
  return rows.filter(
    (c) =>
      c.name.toLowerCase().includes(q) ||
      (c.phone ?? "").includes(q) ||
      (c.email ?? "").toLowerCase().includes(q)
  );
}

export async function getCustomerById(id: number): Promise<Customer | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(customers).where(eq(customers.id, id)).limit(1);
  return rows[0];
}

export async function upsertCustomerFromSale(name: string, phone?: string): Promise<number | undefined> {
  if (!name && !phone) return undefined;
  const db = await getDb();
  if (!db) return undefined;
  // Try to find by phone first, then by name
  let existing: Customer | undefined;
  if (phone) {
    const rows = await db.select().from(customers).where(eq(customers.phone, phone)).limit(1);
    existing = rows[0];
  }
  if (!existing && name) {
    const rows = await db.select().from(customers).where(eq(customers.name, name)).limit(1);
    existing = rows[0];
  }
  if (existing) {
    await db.update(customers).set({
      totalPurchases: (existing.totalPurchases ?? 0) + 1,
      lastVisit: new Date(),
      updatedAt: new Date(),
    }).where(eq(customers.id, existing.id));
    return existing.id;
  } else {
    const result = await db.insert(customers).values({
      name: name || phone!,
      phone: phone ?? null,
      totalPurchases: 1,
      totalSpent: "0",
      lastVisit: new Date(),
    });
    return (result as unknown as { insertId: number }).insertId;
  }
}

export async function deleteCustomer(id: number): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.delete(customers).where(eq(customers.id, id));
}

export async function updateCustomer(id: number, data: Partial<Customer>): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.update(customers).set({ ...data, updatedAt: new Date() }).where(eq(customers.id, id));
}

// ─── Notifications Extended ──────────────────────────────────────────────────
export async function deleteNotification(id: number): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.delete(notifications).where(eq(notifications.id, id));
}

export async function snoozeNotification(id: number, until: Date): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.update(notifications).set({ snoozedUntil: until }).where(eq(notifications.id, id));
}

export async function markNotificationSentToSupplier(id: number): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.update(notifications).set({ sentToSupplier: true }).where(eq(notifications.id, id));
}
