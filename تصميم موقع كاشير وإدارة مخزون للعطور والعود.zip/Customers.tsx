import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Users, Search, Phone, Mail, ShoppingBag, TrendingUp,
  Edit2, Trash2, Loader2, Calendar, Star,
} from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type Customer = {
  id: number;
  name: string;
  phone: string;
  email: string | null;
  notes: string | null;
  totalPurchases: number;
  totalSpent: string;
  lastVisit: Date | null;
  createdAt: Date;
};

export default function CustomersPage() {
  const { user } = useAuth();
  const utils = trpc.useUtils();
  const isAdmin = user?.role === "admin";
  const userPermissions = (user as { permissions?: string[] } | null)?.permissions ?? [];
  const canView = isAdmin || userPermissions.includes("customers.view");

  if (!canView) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background" dir="rtl">
        <div className="text-center p-8">
          <div className="text-6xl mb-4">🔒</div>
          <h2 className="text-2xl font-bold text-amber-400 mb-2">غير مصرح</h2>
          <p className="text-muted-foreground">ليس لديك صلاحية لعرض قاعدة العملاء</p>
        </div>
      </div>
    );
  }

  const [search, setSearch] = useState("");
  const [editCustomer, setEditCustomer] = useState<Customer | null>(null);
  const [editForm, setEditForm] = useState({ name: "", phone: "", email: "", notes: "" });
  const [deleteConfirm, setDeleteConfirm] = useState<Customer | null>(null);

  const { data: customers = [], isLoading } = trpc.customers.list.useQuery({ limit: 500 });

  const updateCustomer = trpc.customers.update.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث بيانات العميل");
      utils.customers.list.invalidate();
      setEditCustomer(null);
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteCustomer = trpc.customers.delete.useMutation({
    onSuccess: () => {
      toast.success("تم حذف العميل");
      utils.customers.list.invalidate();
      setDeleteConfirm(null);
    },
    onError: (e) => toast.error(e.message),
  });

  const openEdit = (c: Customer) => {
    setEditCustomer(c);
    setEditForm({
      name: c.name,
      phone: c.phone,
      email: c.email ?? "",
      notes: c.notes ?? "",
    });
  };

  const filtered = customers.filter((c) => {
    const q = search.toLowerCase();
    return (
      c.name.toLowerCase().includes(q) ||
      c.phone.includes(q) ||
      (c.email ?? "").toLowerCase().includes(q)
    );
  });

  const totalRevenue = customers.reduce((s, c) => s + Number(c.totalSpent), 0);
  const totalPurchases = customers.reduce((s, c) => s + c.totalPurchases, 0);
  const topCustomers = [...customers]
    .sort((a, b) => Number(b.totalSpent) - Number(a.totalSpent))
    .slice(0, 3);

  const { data: settings } = trpc.shop.getSettings.useQuery();
  const currency = settings?.currencySymbol ?? "ريال";

  const formatDate = (d: Date | null) => {
    if (!d) return "—";
    return new Date(d).toLocaleDateString("ar-SA", { year: "numeric", month: "short", day: "numeric" });
  };

  return (
    <div className="p-4 md:p-6 space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-amber-300 flex items-center gap-2">
            <Users className="w-6 h-6" />
            قاعدة العملاء
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            بيانات العملاء المسجلين تلقائياً من عمليات الشراء
          </p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-amber-800/30 bg-card">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-1">
              <Users className="w-4 h-4 text-amber-400" />
              <span className="text-xs text-muted-foreground">إجمالي العملاء</span>
            </div>
            <p className="text-2xl font-bold text-amber-300">{customers.length}</p>
          </CardContent>
        </Card>
        <Card className="border-amber-800/30 bg-card">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-1">
              <ShoppingBag className="w-4 h-4 text-amber-400" />
              <span className="text-xs text-muted-foreground">إجمالي المشتريات</span>
            </div>
            <p className="text-2xl font-bold text-amber-300">{totalPurchases}</p>
          </CardContent>
        </Card>
        <Card className="border-amber-800/30 bg-card">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="w-4 h-4 text-amber-400" />
              <span className="text-xs text-muted-foreground">إجمالي الإنفاق</span>
            </div>
            <p className="text-xl font-bold text-amber-300">
              {totalRevenue.toFixed(0)} {currency}
            </p>
          </CardContent>
        </Card>
        <Card className="border-amber-800/30 bg-card">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-1">
              <Star className="w-4 h-4 text-amber-400" />
              <span className="text-xs text-muted-foreground">متوسط الإنفاق</span>
            </div>
            <p className="text-xl font-bold text-amber-300">
              {customers.length > 0 ? (totalRevenue / customers.length).toFixed(0) : 0} {currency}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Top Customers */}
      {topCustomers.length > 0 && (
        <Card className="border-amber-800/30 bg-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-amber-400 flex items-center gap-2">
              <Star className="w-4 h-4" />
              أفضل العملاء
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-3">
              {topCustomers.map((c, i) => (
                <div key={c.id} className="flex items-center gap-2 bg-amber-900/20 rounded-lg px-3 py-2 border border-amber-800/30">
                  <span className={cn(
                    "w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold",
                    i === 0 ? "bg-amber-500 text-black" : i === 1 ? "bg-amber-700 text-white" : "bg-amber-900 text-amber-300"
                  )}>
                    {i + 1}
                  </span>
                  <div>
                    <p className="text-sm font-medium text-foreground">{c.name}</p>
                    <p className="text-xs text-muted-foreground">{Number(c.totalSpent).toFixed(0)} {currency} · {c.totalPurchases} زيارة</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Search */}
      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="ابحث بالاسم أو رقم الهاتف أو البريد الإلكتروني..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pr-9 bg-card border-amber-800/30 text-right"
        />
      </div>

      {/* Customers Table */}
      {isLoading ? (
        <div className="flex items-center justify-center py-16">
          <Loader2 className="w-8 h-8 animate-spin text-amber-400" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <Users className="w-12 h-12 text-muted-foreground mx-auto mb-3 opacity-40" />
          <p className="text-muted-foreground">
            {search ? "لا يوجد عملاء يطابقون البحث" : "لا يوجد عملاء مسجلون بعد"}
          </p>
          {!search && (
            <p className="text-xs text-muted-foreground mt-2">
              يتم تسجيل العملاء تلقائياً عند إدخال بياناتهم في الكاشير
            </p>
          )}
        </div>
      ) : (
        <div className="space-y-2">
          <p className="text-xs text-muted-foreground">{filtered.length} عميل</p>
          <div className="grid gap-3">
            {filtered.map((customer) => (
              <Card key={customer.id} className="border-amber-800/20 bg-card hover:border-amber-700/40 transition-colors">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    {/* Avatar + Info */}
                    <div className="flex items-start gap-3 flex-1 min-w-0">
                      <div className="w-10 h-10 rounded-full bg-amber-900/40 border border-amber-700/30 flex items-center justify-center shrink-0">
                        <span className="text-amber-300 font-bold text-sm">
                          {customer.name.charAt(0)}
                        </span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="font-semibold text-foreground">{customer.name}</p>
                          {customer.totalPurchases >= 5 && (
                            <Badge className="bg-amber-600/20 text-amber-300 border-amber-600/30 text-xs">
                              عميل مميز
                            </Badge>
                          )}
                        </div>
                        <div className="flex flex-wrap gap-x-4 gap-y-1 mt-1">
                          <span className="text-sm text-muted-foreground flex items-center gap-1">
                            <Phone className="w-3 h-3" />
                            {customer.phone}
                          </span>
                          {customer.email && (
                            <span className="text-sm text-muted-foreground flex items-center gap-1">
                              <Mail className="w-3 h-3" />
                              {customer.email}
                            </span>
                          )}
                        </div>
                        <div className="flex flex-wrap gap-x-4 gap-y-1 mt-1.5">
                          <span className="text-xs text-amber-400 flex items-center gap-1">
                            <ShoppingBag className="w-3 h-3" />
                            {customer.totalPurchases} عملية شراء
                          </span>
                          <span className="text-xs text-amber-400 flex items-center gap-1">
                            <TrendingUp className="w-3 h-3" />
                            {Number(customer.totalSpent).toFixed(2)} {currency}
                          </span>
                          {customer.lastVisit && (
                            <span className="text-xs text-muted-foreground flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              آخر زيارة: {formatDate(customer.lastVisit)}
                            </span>
                          )}
                        </div>
                        {customer.notes && (
                          <p className="text-xs text-muted-foreground mt-1 italic">
                            {customer.notes}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Actions (admin only) */}
                    {isAdmin && (
                      <div className="flex gap-1 shrink-0">
                        <Button
                          size="icon"
                          variant="ghost"
                          className="w-8 h-8 text-amber-400 hover:bg-amber-900/30"
                          onClick={() => openEdit(customer as Customer)}
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="w-8 h-8 text-red-400 hover:bg-red-900/30"
                          onClick={() => setDeleteConfirm(customer as Customer)}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Edit Dialog */}
      <Dialog open={!!editCustomer} onOpenChange={(o) => !o && setEditCustomer(null)}>
        <DialogContent className="bg-card border-amber-800/30" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-amber-300">تعديل بيانات العميل</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-muted-foreground">الاسم</label>
              <Input
                value={editForm.name}
                onChange={(e) => setEditForm((f) => ({ ...f, name: e.target.value }))}
                className="bg-background border-amber-800/30 text-right mt-1"
              />
            </div>
            <div>
              <label className="text-sm text-muted-foreground">رقم الهاتف</label>
              <Input
                value={editForm.phone}
                onChange={(e) => setEditForm((f) => ({ ...f, phone: e.target.value }))}
                className="bg-background border-amber-800/30 text-right mt-1"
                dir="ltr"
              />
            </div>
            <div>
              <label className="text-sm text-muted-foreground">البريد الإلكتروني (اختياري)</label>
              <Input
                value={editForm.email}
                onChange={(e) => setEditForm((f) => ({ ...f, email: e.target.value }))}
                className="bg-background border-amber-800/30 mt-1"
                dir="ltr"
              />
            </div>
            <div>
              <label className="text-sm text-muted-foreground">ملاحظات (اختياري)</label>
              <Input
                value={editForm.notes}
                onChange={(e) => setEditForm((f) => ({ ...f, notes: e.target.value }))}
                className="bg-background border-amber-800/30 text-right mt-1"
              />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setEditCustomer(null)}>إلغاء</Button>
            <Button
              className="bg-amber-600 hover:bg-amber-700 text-black"
              disabled={!editForm.name || !editForm.phone || updateCustomer.isPending}
              onClick={() => {
                if (!editCustomer) return;
                updateCustomer.mutate({
                  id: editCustomer.id,
                  name: editForm.name,
                  phone: editForm.phone,
                  email: editForm.email || undefined,
                  notes: editForm.notes || undefined,
                });
              }}
            >
              {updateCustomer.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "حفظ التغييرات"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm Dialog */}
      <Dialog open={!!deleteConfirm} onOpenChange={(o) => !o && setDeleteConfirm(null)}>
        <DialogContent className="bg-card border-amber-800/30" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-red-400">تأكيد الحذف</DialogTitle>
          </DialogHeader>
          <p className="text-muted-foreground">
            هل أنت متأكد من حذف العميل <strong className="text-foreground">{deleteConfirm?.name}</strong>؟
            لن يمكن التراجع عن هذا الإجراء.
          </p>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDeleteConfirm(null)}>إلغاء</Button>
            <Button
              variant="destructive"
              disabled={deleteCustomer.isPending}
              onClick={() => deleteConfirm && deleteCustomer.mutate({ id: deleteConfirm.id })}
            >
              {deleteCustomer.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "حذف"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
