import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  LayoutDashboard,
  Package,
  ShoppingCart,
  FileText,
  BarChart3,
  Bot,
  Settings,
  Users,
  LogOut,
  Menu,
  X,
  Bell,
  ChevronLeft,
} from "lucide-react";
import { cn } from "@/lib/utils";

const LOGO_URL = "/manus-storage/teeb-logo_ab292981.jpeg";

interface NavItem {
  href: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  adminOnly?: boolean;
}

const navItems: NavItem[] = [
  { href: "/dashboard", label: "لوحة التحكم", icon: LayoutDashboard },
  { href: "/inventory", label: "المخزون", icon: Package },
  { href: "/pos", label: "الكاشير", icon: ShoppingCart },
  { href: "/invoices", label: "الفواتير", icon: FileText },
  { href: "/analytics", label: "الإحصائيات", icon: BarChart3, adminOnly: true },
  { href: "/ai-advisor", label: "المستشار الذكي", icon: Bot, adminOnly: true },
  { href: "/users", label: "المستخدمون", icon: Users, adminOnly: true },
  { href: "/settings", label: "الإعدادات", icon: Settings, adminOnly: true },
];

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const { data: settings } = trpc.shop.getSettings.useQuery();
  const { data: notifications } = trpc.notifications.list.useQuery({ unreadOnly: true });

  const unreadCount = notifications?.filter((n) => !n.isRead).length ?? 0;
  const logoUrl = settings?.logoUrl ?? LOGO_URL;
  const shopName = settings?.shopName ?? "طيب الحي";
  const isAdmin = user?.role === "admin";

  const visibleNavItems = navItems.filter((item) => !item.adminOnly || isAdmin);

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Logo & shop name */}
      <div className="p-5 border-b border-amber-800/30">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-amber-500/60 shrink-0 shadow-lg shadow-amber-900/40">
            <img src={logoUrl} alt="شعار" className="w-full h-full object-cover" onError={(e) => { (e.target as HTMLImageElement).src = LOGO_URL; }} />
          </div>
          <div className="min-w-0">
            <p className="font-bold text-amber-300 text-sm truncate">{shopName}</p>
            <p className="text-xs text-muted-foreground truncate">{user?.name}</p>
            <Badge variant="outline" className={cn("text-xs mt-0.5 border-0 px-1.5", isAdmin ? "bg-amber-900/50 text-amber-300" : "bg-blue-900/50 text-blue-300")}>
              {isAdmin ? "مدير" : "موظف"}
            </Badge>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {visibleNavItems.map((item) => {
          const isActive = location === item.href || location.startsWith(item.href + "/");
          return (
            <Link key={item.href} href={item.href}>
              <a
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200",
                  isActive
                    ? "bg-amber-600/20 text-amber-300 border border-amber-600/30"
                    : "text-muted-foreground hover:bg-amber-900/20 hover:text-amber-300"
                )}
                onClick={() => setSidebarOpen(false)}
              >
                <item.icon className="w-4 h-4 shrink-0" />
                {item.label}
              </a>
            </Link>
          );
        })}
      </nav>

      {/* Logout */}
      <div className="p-3 border-t border-amber-800/30">
        <Button
          variant="ghost"
          className="w-full justify-start gap-3 text-muted-foreground hover:text-red-400 hover:bg-red-900/20"
          onClick={logout}
        >
          <LogOut className="w-4 h-4" />
          تسجيل الخروج
        </Button>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen bg-background" dir="rtl">
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex flex-col w-64 shrink-0 border-l border-amber-800/30 bg-sidebar">
        <SidebarContent />
      </aside>

      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setSidebarOpen(false)} />
          <aside className="absolute right-0 top-0 bottom-0 w-72 bg-sidebar border-l border-amber-800/30 shadow-2xl">
            <SidebarContent />
          </aside>
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header className="sticky top-0 z-40 flex items-center justify-between px-4 py-3 border-b border-amber-800/30 bg-background/80 backdrop-blur-sm">
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden text-amber-400"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="w-5 h-5" />
          </Button>

          <div className="flex items-center gap-2 mr-auto">
            {/* Notifications bell */}
            <Link href="/dashboard">
              <a className="relative p-2 rounded-lg text-muted-foreground hover:text-amber-300 hover:bg-amber-900/20 transition-colors">
                <Bell className="w-5 h-5" />
                {unreadCount > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center font-bold">
                    {unreadCount > 9 ? "9+" : unreadCount}
                  </span>
                )}
              </a>
            </Link>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 p-4 lg:p-6 overflow-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
