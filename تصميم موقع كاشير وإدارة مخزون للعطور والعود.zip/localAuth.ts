/**
 * Local (independent) authentication module for Teeb Al Hai.
 * Provides email + password login without any external OAuth dependency.
 * Uses bcryptjs for password hashing and the existing JWT session infrastructure.
 */
import bcrypt from "bcryptjs";
import type { Request, Response } from "express";
import { SignJWT } from "jose";
import { getDb } from "./db";
import { users } from "../drizzle/schema";
import { eq, isNull, or } from "drizzle-orm";
import { ENV } from "./_core/env";
import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";

const SALT_ROUNDS = 12;

function getSessionSecret() {
  return new TextEncoder().encode(ENV.cookieSecret);
}

async function signLocalSession(userId: number, openId: string, name: string): Promise<string> {
  const issuedAt = Date.now();
  const expiresInMs = ONE_YEAR_MS;
  const expirationSeconds = Math.floor((issuedAt + expiresInMs) / 1000);

  return new SignJWT({
    openId,
    appId: ENV.appId || "teeb-local",
    name,
    localAuth: true,
    userId,
  })
    .setProtectedHeader({ alg: "HS256", typ: "JWT" })
    .setExpirationTime(expirationSeconds)
    .sign(getSessionSecret());
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, SALT_ROUNDS);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

/**
 * Check if any admin user exists in the database.
 * Used to determine if this is a first-run setup.
 */
export async function hasAnyAdmin(): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;
  // Only count admins that have a local password (not OAuth-only accounts)
  const result = await db
    .select({ id: users.id, passwordHash: users.passwordHash })
    .from(users)
    .where(eq(users.role, "admin"))
    .limit(10);
  // Filter: must have a non-empty passwordHash
  const localAdmins = result.filter((u) => u.passwordHash && u.passwordHash.length > 0);
  return localAdmins.length > 0;
}

/**
 * Register the first admin user (only allowed when no admin exists).
 */
export async function registerFirstAdmin(
  name: string,
  email: string,
  password: string
): Promise<{ success: boolean; error?: string }> {
  const db = await getDb();
  if (!db) return { success: false, error: "قاعدة البيانات غير متاحة" };

  // Check no admin exists
  const adminExists = await hasAnyAdmin();
  if (adminExists) {
    return { success: false, error: "يوجد مدير بالفعل. لا يمكن إنشاء مدير جديد." };
  }

  // Check email not taken
  const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
  if (existing.length > 0) {
    return { success: false, error: "البريد الإلكتروني مستخدم بالفعل" };
  }

  const passwordHash = await hashPassword(password);
  const openId = `local_${Date.now()}_${Math.random().toString(36).slice(2)}`;

  await db.insert(users).values({
    openId,
    name,
    email,
    loginMethod: "local",
    role: "admin",
    passwordHash,
    isActive: true,
    lastSignedIn: new Date(),
  });

  return { success: true };
}

/**
 * Login with email + password.
 * Returns the user record on success.
 */
export async function loginWithPassword(
  email: string,
  password: string
): Promise<{ success: boolean; user?: typeof users.$inferSelect; error?: string }> {
  const db = await getDb();
  if (!db) return { success: false, error: "قاعدة البيانات غير متاحة" };

  const result = await db
    .select()
    .from(users)
    .where(eq(users.email, email))
    .limit(1);

  const user = result[0];
  if (!user) {
    return { success: false, error: "البريد الإلكتروني أو كلمة المرور غير صحيحة" };
  }

  if (!user.isActive) {
    return { success: false, error: "هذا الحساب معطّل. تواصل مع المدير." };
  }

  if (!user.passwordHash) {
    return { success: false, error: "هذا الحساب لا يدعم تسجيل الدخول بكلمة المرور" };
  }

  const valid = await verifyPassword(password, user.passwordHash);
  if (!valid) {
    return { success: false, error: "البريد الإلكتروني أو كلمة المرور غير صحيحة" };
  }

  // Update last signed in
  await db.update(users).set({ lastSignedIn: new Date() }).where(eq(users.id, user.id));

  return { success: true, user };
}

/**
 * Express route handler: POST /api/auth/local/login
 */
export async function handleLocalLogin(req: Request, res: Response) {
  const { email, password } = req.body ?? {};

  if (!email || !password) {
    return res.status(400).json({ success: false, error: "البريد الإلكتروني وكلمة المرور مطلوبان" });
  }

  const result = await loginWithPassword(email, password);
  if (!result.success || !result.user) {
    return res.status(401).json({ success: false, error: result.error });
  }

  const token = await signLocalSession(result.user.id, result.user.openId, result.user.name ?? "");
  const cookieOptions = getSessionCookieOptions(req);
  res.cookie(COOKIE_NAME, token, cookieOptions);

  return res.json({
    success: true,
    user: {
      id: result.user.id,
      name: result.user.name,
      email: result.user.email,
      role: result.user.role,
    },
  });
}

/**
 * Express route handler: POST /api/auth/local/register-admin
 * Only works when no admin exists (first run).
 */
export async function handleRegisterAdmin(req: Request, res: Response) {
  const { name, email, password } = req.body ?? {};

  if (!name || !email || !password) {
    return res.status(400).json({ success: false, error: "جميع الحقول مطلوبة" });
  }

  if (password.length < 8) {
    return res.status(400).json({ success: false, error: "كلمة المرور يجب أن تكون 8 أحرف على الأقل" });
  }

  const result = await registerFirstAdmin(name, email, password);
  if (!result.success) {
    return res.status(400).json({ success: false, error: result.error });
  }

  return res.json({ success: true, message: "تم إنشاء حساب المدير بنجاح. يمكنك الآن تسجيل الدخول." });
}

/**
 * Express route handler: GET /api/auth/local/setup-status
 * Returns whether first-run setup is needed.
 */
export async function handleSetupStatus(_req: Request, res: Response) {
  const adminExists = await hasAnyAdmin();
  return res.json({ needsSetup: !adminExists });
}

/**
 * Create a staff user directly (admin only, called from tRPC router).
 */
export async function createStaffUser(
  name: string,
  email: string,
  password: string,
  permissions: string[]
): Promise<{ success: boolean; error?: string; userId?: number }> {
  const db = await getDb();
  if (!db) return { success: false, error: "قاعدة البيانات غير متاحة" };

  // Check email not taken
  const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
  if (existing.length > 0) {
    return { success: false, error: "البريد الإلكتروني مستخدم بالفعل" };
  }

  const passwordHash = await hashPassword(password);
  const openId = `local_staff_${Date.now()}_${Math.random().toString(36).slice(2)}`;

  const result = await db.insert(users).values({
    openId,
    name,
    email,
    loginMethod: "local",
    role: "user",
    passwordHash,
    permissions: permissions as unknown as string[],
    isActive: true,
    lastSignedIn: new Date(),
  });

  return { success: true, userId: Number((result as { insertId?: unknown }).insertId ?? 0) };
}

/**
 * Reset a user's password (admin only).
 */
export async function resetUserPassword(
  userId: number,
  newPassword: string
): Promise<{ success: boolean; error?: string }> {
  const db = await getDb();
  if (!db) return { success: false, error: "قاعدة البيانات غير متاحة" };

  if (newPassword.length < 8) {
    return { success: false, error: "كلمة المرور يجب أن تكون 8 أحرف على الأقل" };
  }

  const passwordHash = await hashPassword(newPassword);
  await db.update(users).set({ passwordHash }).where(eq(users.id, userId));

  return { success: true };
}
