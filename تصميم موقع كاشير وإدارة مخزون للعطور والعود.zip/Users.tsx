import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Users, UserPlus, Shield, Edit2, Trash2, Phone,
  CheckCircle, XCircle, Crown, Loader2, RefreshCw, Info,
  Eye, EyeOff, KeyRound,
} from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

// ─── Permission definitions ───────────────────────────────────────────────────
const PERMISSION_GROUPS = [
  {
    group: "الكاشير والمبيعات",
    icon: "🛒",
    permissions: [
      { key: "pos.access", label: "الوصول للكاشير", desc: "إجراء عمليات البيع" },
      { key: "pos.discount", label: "منح الخصومات", desc: "تطبيق خصومات على الفواتير" },
      { key: "pos.refund", label: "استرداد المبالغ", desc: "إلغاء وإرجاع المبيعات" },
    ],
  },
  {
    group: "المخزون",
    icon: "📦",
    permissions: [
      { key: "inventory.view", label: "عرض المخزون", desc: "مشاهدة قائمة المنتجات والكميات" },
      { key: "inventory.add", label: "إضافة مخزون", desc: "إدخال بضاعة جديدة" },
      { key: "inventory.edit", label: "تعديل المنتجات", desc: "تعديل بيانات المنتجات والأسعار" },
      { key: "inventory.delete", label: "حذف المنتجات", desc: "إلغاء وحذف المنتجات" },
    ],
  },
  {
    group: "الفواتير والعملاء",
    icon: "🧾",
    permissions: [
      { key: "invoices.view", label: "عرض الفواتير", desc: "مشاهدة سجل الفواتير" },
      { key: "invoices.print", label: "طباعة الفواتير", desc: "طباعة وتحميل الفواتير" },
      { key: "customers.view", label: "عرض قاعدة العملاء", desc: "الاطلاع على بيانات العملاء" },
      { key: "customers.contact", label: "التواصل مع العملاء", desc: "إرسال عروض ورسائل للعملاء" },
    ],
  },
  {
    group: "الإشعارات",
    icon: "🔔",
    permissions: [
      { key: "notifications.view", label: "عرض الإشعارات", desc: "مشاهدة تنبيهات المخزون" },
      { key: "notifications.manage", label: "إدارة الإشعارات", desc: "حذف وتأجيل الإشعارات" },
    ],
  },
];

const ALL_PERMISSIONS = PERMISSION_GROUPS.flatMap((g) => g.permissions.map((p) => p.key));

type UserRow = {
  id: number;
  name: string | null;
  email: string | null;
  role: "admin" | "user";
  displayName: string | null;
  phone: string | null;
  permissions: string[] | null;
  isActive: boolean;
  createdAt: Date;
  lastSignedIn: Date;
};

const DEFAULT_STAFF_PERMISSIONS = ["pos.access", "inventory.view", "inventory.add", "invoices.view", "invoices.print", "notifications.view"];

export default function UsersPage() {
  const { user: currentUser } = useAuth();
  const utils = trpc.useUtils();

  const { data: users = [], isLoading } = trpc.users.list.useQuery();

  const [editUser, setEditUser] = useState<UserRow | null>(null);
  const [showAddStaff, setShowAddStaff] = useState(false);
  const [showResetPassword, setShowResetPassword] = useState<UserRow | null>(null);
  const [newPassword, setNewPassword] = useState("");
  const [showNewPassword, setShowNewPassword] = useState(false);

  const [addForm, setAddForm] = useState({
    name: "",
    email: "",
    password: "",
    displayName: "",
    phone: "",
    permissions: DEFAULT_STAFF_PERMISSIONS as string[],
  });
  const [showAddPassword, setShowAddPassword] = useState(false);

  const [editForm, setEditForm] = useState({
    displayName: "",
    phone: "",
    role: "user" as "admin" | "user",
    permissions: [] as string[],
    isActive: true,
  });

  const updateProfile = trpc.users.updateProfile.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث بيانات المستخدم");
      utils.users.list.invalidate();
      setEditUser(null);
    },
    onError: (e) => toast.error(e.message),
  });

  const deactivate = trpc.users.deactivate.useMutation({
    onSuccess: () => { toast.success("تم تعطيل الحساب"); utils.users.list.invalidate(); },
    onError: (e) => toast.error(e.message),
  });

  const createStaff = trpc.users.createStaff.useMutation({
    onSuccess: () => {
      toast.success("تم إضافة الموظف بنجاح! يمكنه الآن تسجيل الدخول.");
      utils.users.list.invalidate();
      setShowAddStaff(false);
      setAddForm({ name: "", email: "", password: "", displayName: "", phone: "", permissions: DEFAULT_STAFF_PERMISSIONS });
    },
    onError: (e) => toast.error(e.message),
  });

  const resetPassword = trpc.users.resetPassword.useMutation({
    onSuccess: () => {
      toast.success("تم تغيير كلمة المرور بنجاح");
      setShowResetPassword(null);
      setNewPassword("");
    },
    onError: (e) => toast.error(e.message),
  });

  const openEdit = (u: UserRow) => {
    setEditUser(u);
    setEditForm({
      displayName: u.displayName ?? u.name ?? "",
      phone: u.phone ?? "",
      role: u.role,
      permissions: (u.permissions as string[]) ?? [],
      isActive: u.isActive,
    });
  };

  const togglePermission = (key: string, target: "edit" | "add") => {
    if (target === "edit") {
      setEditForm((f) => ({
        ...f,
        permissions: f.permissions.includes(key)
          ? f.permissions.filter((p) => p !== key)
          : [...f.permissions, key],
      }));
    } else {
      setAddForm((f) => ({
        ...f,
        permissions: f.permissions.includes(key)
          ? f.permissions.filter((p) => p !== key)
          : [...f.permissions, key],
      }));
    }
  };

  const setAllPermissions = (target: "edit" | "add", val: boolean) => {
    if (target === "edit") setEditForm((f) => ({ ...f, permissions: val ? ALL_PERMISSIONS : [] }));
    else setAddForm((f) => ({ ...f, permissions: val ? ALL_PERMISSIONS : [] }));
  };

  const activeUsers = (users as UserRow[]).filter((u) => u.isActive !== false);
  const inactiveUsers = (users as UserRow[]).filter((u) => u.isActive === false);

  const passwordStrength = (pw: string) => {
    if (pw.length === 0) return null;
    if (pw.length < 8) return { label: "ضعيفة", color: "bg-red-500", width: "25%" };
    if (pw.length < 12) return { label: "متوسطة", color: "bg-yellow-500", width: "60%" };
    return { label: "قوية", color: "bg-green-500", width: "100%" };
  };

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-amber-300 flex items-center gap-2" style={{ fontFamily: "'Amiri', serif" }}>
            <Users className="w-6 h-6" /> إدارة المستخدمين
          </h1>
          <p className="text-muted-foreground text-sm mt-1">إدارة الموظفين وصلاحياتهم بدقة</p>
        </div>
        <Button onClick={() => setShowAddStaff(true)} className="bg-amber-600 hover:bg-amber-500 text-white gap-2">
          <UserPlus className="w-4 h-4" /> إضافة موظف جديد
        </Button>
      </div>

      {/* Info card */}
      <Card className="border-amber-700/40 bg-amber-900/10">
        <CardContent className="p-4 flex items-start gap-3">
          <Info className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-amber-300">نظام الصلاحيات والملكية</p>
            <p className="text-xs text-muted-foreground mt-1">
              صاحب المشروع (المدير) لديه صلاحية كاملة على جميع أقسام النظام. يمكنه إضافة موظفين مباشرة بإيميل وكلمة مرور وتحديد صلاحياتهم بدقة.
              الموظفون يصلون فقط للأقسام التي منحت لهم صلاحية الوصول إليها.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Role cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Card className="border-amber-800/30 bg-amber-900/10">
          <CardContent className="p-4 flex items-center gap-3">
            <Crown className="w-8 h-8 text-amber-400 shrink-0" />
            <div>
              <p className="font-bold text-amber-300 text-sm">مدير (صاحب المشروع)</p>
              <p className="text-xs text-muted-foreground">وصول كامل: المبيعات، المخزون، التقارير، الإعدادات، المستخدمون، المستشار الذكي</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-blue-800/30 bg-blue-900/10">
          <CardContent className="p-4 flex items-center gap-3">
            <Shield className="w-8 h-8 text-blue-400 shrink-0" />
            <div>
              <p className="font-bold text-blue-300 text-sm">موظف (صلاحيات محددة)</p>
              <p className="text-xs text-muted-foreground">يصل فقط للأقسام التي حددها المدير من 11 صلاحية موزعة على 4 مجموعات</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Active users */}
      {isLoading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-amber-400" />
        </div>
      ) : (
        <Card className="border-border bg-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-amber-300 flex items-center gap-2">
              <CheckCircle className="w-4 h-4" /> المستخدمون النشطون ({activeUsers.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {activeUsers.map((u) => (
                <div key={u.id} className="flex items-center justify-between p-4 rounded-xl border border-border bg-muted/10 hover:bg-muted/20 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className={cn("w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm", u.role === "admin" ? "bg-amber-600" : "bg-blue-600")}>
                      {(u.displayName ?? u.name ?? "؟").charAt(0)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-semibold text-foreground">{u.displayName ?? u.name ?? "—"}</p>
                        <Badge variant="outline" className={cn("text-xs h-5", u.role === "admin" ? "border-amber-600/50 text-amber-400" : "border-blue-600/50 text-blue-400")}>
                          {u.role === "admin" ? <><Crown className="w-3 h-3 ml-1" />مدير</> : <><Shield className="w-3 h-3 ml-1" />موظف</>}
                        </Badge>
                        {u.id === currentUser?.id && (
                          <Badge className="text-xs h-5 bg-green-900/30 text-green-400 border-green-700/40">أنت</Badge>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground">{u.email}</p>
                      {u.phone && (
                        <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                          <Phone className="w-3 h-3" /> {u.phone}
                        </p>
                      )}
                      {u.role === "user" && (
                        <p className="text-xs text-muted-foreground/60 mt-0.5">
                          {((u.permissions as string[]) ?? []).length} صلاحية مفعّلة
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-8 w-8 p-0 text-amber-400 hover:bg-amber-900/20"
                      onClick={() => openEdit(u)}
                      title="تعديل"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-8 w-8 p-0 text-blue-400 hover:bg-blue-900/20"
                      onClick={() => { setShowResetPassword(u); setNewPassword(""); }}
                      title="تغيير كلمة المرور"
                    >
                      <KeyRound className="w-3.5 h-3.5" />
                    </Button>
                    {u.id !== currentUser?.id && (
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-8 w-8 p-0 text-red-400 hover:bg-red-900/20"
                        onClick={() => {
                          if (confirm(`هل تريد تعطيل حساب "${u.displayName ?? u.name}"؟`)) {
                            deactivate.mutate({ userId: u.id });
                          }
                        }}
                        title="تعطيل"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    )}
                  </div>
                </div>
              ))}
              {activeUsers.length === 0 && (
                <p className="text-center text-muted-foreground text-sm py-6">لا يوجد مستخدمون نشطون</p>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Inactive users */}
      {inactiveUsers.length > 0 && (
        <Card className="border-border bg-card opacity-70">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-muted-foreground flex items-center gap-2">
              <XCircle className="w-4 h-4" /> حسابات معطلة ({inactiveUsers.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {inactiveUsers.map((u) => (
                <div key={u.id} className="flex items-center justify-between p-3 rounded-lg border border-border bg-muted/10">
                  <div>
                    <p className="text-sm text-muted-foreground line-through">{u.displayName ?? u.name ?? "—"}</p>
                    <p className="text-xs text-muted-foreground/60">{u.email}</p>
                  </div>
                  <Button size="sm" variant="outline" className="h-8 text-xs" onClick={() => updateProfile.mutate({ userId: u.id, isActive: true })}>
                    <RefreshCw className="w-3 h-3 ml-1" /> تفعيل
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* ─── Add Staff Dialog ─── */}
      <Dialog open={showAddStaff} onOpenChange={setShowAddStaff}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-amber-300 flex items-center gap-2">
              <UserPlus className="w-4 h-4" /> إضافة موظف جديد
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-5 py-2">
            <div className="p-3 rounded-lg bg-green-900/20 border border-green-700/30">
              <p className="text-xs text-green-300">
                <Info className="w-3.5 h-3.5 inline ml-1" />
                سيتمكن الموظف من تسجيل الدخول مباشرة بالبريد الإلكتروني وكلمة المرور التي تحددها.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">الاسم الكامل *</Label>
                <Input
                  value={addForm.name}
                  onChange={(e) => setAddForm((f) => ({ ...f, name: e.target.value }))}
                  placeholder="اسم الموظف"
                  className="bg-input border-border"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">الاسم المعروض</Label>
                <Input
                  value={addForm.displayName}
                  onChange={(e) => setAddForm((f) => ({ ...f, displayName: e.target.value }))}
                  placeholder="اختياري"
                  className="bg-input border-border"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">البريد الإلكتروني *</Label>
                <Input
                  type="email"
                  value={addForm.email}
                  onChange={(e) => setAddForm((f) => ({ ...f, email: e.target.value }))}
                  placeholder="staff@example.com"
                  dir="ltr"
                  className="bg-input border-border"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">رقم الهاتف</Label>
                <Input
                  value={addForm.phone}
                  onChange={(e) => setAddForm((f) => ({ ...f, phone: e.target.value }))}
                  placeholder="+966..."
                  className="bg-input border-border"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">كلمة المرور * (8 أحرف على الأقل)</Label>
              <div className="relative">
                <Input
                  type={showAddPassword ? "text" : "password"}
                  value={addForm.password}
                  onChange={(e) => setAddForm((f) => ({ ...f, password: e.target.value }))}
                  placeholder="••••••••"
                  dir="ltr"
                  className="bg-input border-border pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowAddPassword(!showAddPassword)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  tabIndex={-1}
                >
                  {showAddPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              {addForm.password && (() => {
                const s = passwordStrength(addForm.password);
                return s ? (
                  <div className="space-y-1">
                    <div className="h-1 bg-muted rounded-full overflow-hidden">
                      <div className={`h-full ${s.color} rounded-full transition-all`} style={{ width: s.width }} />
                    </div>
                    <p className="text-xs text-muted-foreground">قوة كلمة المرور: {s.label}</p>
                  </div>
                ) : null;
              })()}
            </div>

            <div className="space-y-3">
              <Separator className="bg-amber-800/20" />
              <div className="flex items-center justify-between">
                <Label className="text-sm font-semibold text-amber-300 flex items-center gap-1.5">
                  <Shield className="w-4 h-4" /> الصلاحيات
                </Label>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" className="h-7 text-xs border-green-700/40 text-green-400" onClick={() => setAllPermissions("add", true)}>تحديد الكل</Button>
                  <Button size="sm" variant="outline" className="h-7 text-xs border-red-700/40 text-red-400" onClick={() => setAllPermissions("add", false)}>إلغاء الكل</Button>
                </div>
              </div>
              {PERMISSION_GROUPS.map((group) => (
                <div key={group.group} className="space-y-2">
                  <p className="text-xs font-medium text-muted-foreground">{group.icon} {group.group}</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {group.permissions.map((perm) => (
                      <label key={perm.key} className={cn("flex items-start gap-2.5 p-2.5 rounded-lg border cursor-pointer transition-colors", addForm.permissions.includes(perm.key) ? "border-amber-600/50 bg-amber-900/15" : "border-border hover:bg-muted/20")}>
                        <Switch checked={addForm.permissions.includes(perm.key)} onCheckedChange={() => togglePermission(perm.key, "add")} className="mt-0.5 shrink-0" />
                        <div>
                          <p className="text-xs font-medium text-foreground">{perm.label}</p>
                          <p className="text-xs text-muted-foreground">{perm.desc}</p>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="ghost" onClick={() => setShowAddStaff(false)}>إلغاء</Button>
            <Button
              className="bg-amber-600 hover:bg-amber-500 text-white"
              disabled={!addForm.name || !addForm.email || addForm.password.length < 8 || createStaff.isPending}
              onClick={() => createStaff.mutate(addForm)}
            >
              {createStaff.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <><UserPlus className="w-4 h-4 ml-1" />إضافة الموظف</>}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ─── Edit User Dialog ─── */}
      <Dialog open={!!editUser} onOpenChange={(o) => !o && setEditUser(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-amber-300 flex items-center gap-2">
              <Edit2 className="w-4 h-4" /> تعديل: {editUser?.displayName ?? editUser?.name}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-5 py-2">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">الاسم المعروض</Label>
                <Input value={editForm.displayName} onChange={(e) => setEditForm((f) => ({ ...f, displayName: e.target.value }))} className="bg-input border-border" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">رقم الهاتف</Label>
                <Input value={editForm.phone} onChange={(e) => setEditForm((f) => ({ ...f, phone: e.target.value }))} placeholder="+966..." className="bg-input border-border" />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">الدور الوظيفي</Label>
              <Select value={editForm.role} onValueChange={(v) => setEditForm((f) => ({ ...f, role: v as "admin" | "user" }))}>
                <SelectTrigger className="bg-input border-border">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="user">موظف (صلاحيات محددة)</SelectItem>
                  <SelectItem value="admin">مدير (صلاحيات كاملة)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center gap-3">
              <Switch checked={editForm.isActive} onCheckedChange={(v) => setEditForm((f) => ({ ...f, isActive: v }))} />
              <Label className="text-sm">الحساب نشط</Label>
            </div>

            {editForm.role === "user" && (
              <div className="space-y-3">
                <Separator className="bg-amber-800/20" />
                <div className="flex items-center justify-between">
                  <Label className="text-sm font-semibold text-amber-300 flex items-center gap-1.5">
                    <Shield className="w-4 h-4" /> الصلاحيات
                  </Label>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" className="h-7 text-xs border-green-700/40 text-green-400" onClick={() => setAllPermissions("edit", true)}>تحديد الكل</Button>
                    <Button size="sm" variant="outline" className="h-7 text-xs border-red-700/40 text-red-400" onClick={() => setAllPermissions("edit", false)}>إلغاء الكل</Button>
                  </div>
                </div>
                {PERMISSION_GROUPS.map((group) => (
                  <div key={group.group} className="space-y-2">
                    <p className="text-xs font-medium text-muted-foreground">{group.icon} {group.group}</p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {group.permissions.map((perm) => (
                        <label key={perm.key} className={cn("flex items-start gap-2.5 p-2.5 rounded-lg border cursor-pointer transition-colors", editForm.permissions.includes(perm.key) ? "border-amber-600/50 bg-amber-900/15" : "border-border hover:bg-muted/20")}>
                          <Switch checked={editForm.permissions.includes(perm.key)} onCheckedChange={() => togglePermission(perm.key, "edit")} className="mt-0.5 shrink-0" />
                          <div>
                            <p className="text-xs font-medium text-foreground">{perm.label}</p>
                            <p className="text-xs text-muted-foreground">{perm.desc}</p>
                          </div>
                        </label>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <DialogFooter className="gap-2">
            <Button variant="ghost" onClick={() => setEditUser(null)}>إلغاء</Button>
            <Button
              className="bg-amber-600 hover:bg-amber-500 text-white"
              disabled={updateProfile.isPending}
              onClick={() => updateProfile.mutate({ userId: editUser!.id, ...editForm })}
            >
              {updateProfile.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "حفظ التغييرات"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ─── Reset Password Dialog ─── */}
      <Dialog open={!!showResetPassword} onOpenChange={(o) => !o && setShowResetPassword(null)}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-blue-300 flex items-center gap-2">
              <KeyRound className="w-4 h-4" /> تغيير كلمة مرور: {showResetPassword?.displayName ?? showResetPassword?.name}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">كلمة المرور الجديدة (8 أحرف على الأقل)</Label>
              <div className="relative">
                <Input
                  type={showNewPassword ? "text" : "password"}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="••••••••"
                  dir="ltr"
                  className="bg-input border-border pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowNewPassword(!showNewPassword)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  tabIndex={-1}
                >
                  {showNewPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              {newPassword && (() => {
                const s = passwordStrength(newPassword);
                return s ? (
                  <div className="space-y-1">
                    <div className="h-1 bg-muted rounded-full overflow-hidden">
                      <div className={`h-full ${s.color} rounded-full transition-all`} style={{ width: s.width }} />
                    </div>
                    <p className="text-xs text-muted-foreground">قوة كلمة المرور: {s.label}</p>
                  </div>
                ) : null;
              })()}
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="ghost" onClick={() => setShowResetPassword(null)}>إلغاء</Button>
            <Button
              className="bg-blue-600 hover:bg-blue-500 text-white"
              disabled={newPassword.length < 8 || resetPassword.isPending}
              onClick={() => resetPassword.mutate({ userId: showResetPassword!.id, newPassword })}
            >
              {resetPassword.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <><KeyRound className="w-4 h-4 ml-1" />تغيير كلمة المرور</>}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
