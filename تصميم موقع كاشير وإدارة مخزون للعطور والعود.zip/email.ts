import nodemailer from "nodemailer";
import { getShopSettings } from "./db";

export interface SendEmailOptions {
  to: string;
  subject: string;
  text: string;
  html?: string;
}

/**
 * Send an email using the SMTP settings stored in shop_settings.
 * Throws if SMTP is not configured or sending fails.
 */
export async function sendEmail(opts: SendEmailOptions): Promise<void> {
  const settings = await getShopSettings();

  if (!settings?.smtpEmail || !settings?.smtpPassword) {
    throw new Error("لم يتم إعداد بيانات الإيميل بعد. يرجى الذهاب إلى الإعدادات وإدخال بيانات Gmail.");
  }

  const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: settings.smtpEmail,
      pass: settings.smtpPassword,
    },
  });

  const fromName = settings.smtpFromName || settings.shopName || "طيب الحي";

  await transporter.sendMail({
    from: `"${fromName}" <${settings.smtpEmail}>`,
    to: opts.to,
    subject: opts.subject,
    text: opts.text,
    html: opts.html ?? `<div dir="rtl" style="font-family: Arial, sans-serif; line-height: 1.8;">${opts.text.replace(/\n/g, "<br/>")}</div>`,
  });
}

/**
 * Test SMTP connection with given credentials (without saving).
 */
export async function testSmtpConnection(smtpEmail: string, smtpPassword: string): Promise<void> {
  const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: smtpEmail,
      pass: smtpPassword,
    },
  });
  await transporter.verify();
}
