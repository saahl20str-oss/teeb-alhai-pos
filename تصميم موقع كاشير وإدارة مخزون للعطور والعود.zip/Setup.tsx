import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Eye, EyeOff, ShieldCheck, Loader2, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

export default function Setup() {
  const [, setLocation] = useLocation();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [checking, setChecking] = useState(true);

  // If admin already exists, redirect to login
  useEffect(() => {
    fetch("/api/auth/local/setup-status")
      .then((r) => r.json())
      .then((data) => {
        if (!data.needsSetup) {
          setLocation("/login");
        } else {
          setChecking(false);
        }
      })
      .catch(() => setChecking(false));
  }, [setLocation]);

  const handleSetup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !password) {
      toast.error("يرجى ملء جميع الحقول");
      return;
    }
    if (password.length < 8) {
      toast.error("كلمة المرور يجب أن تكون 8 أحرف على الأقل");
      return;
    }
    if (password !== confirmPassword) {
      toast.error("كلمتا المرور غير متطابقتين");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/auth/local/register-admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, password }),
      });
      const data = await res.json();
      if (data.success) {
        setDone(true);
        toast.success("تم إنشاء حساب المدير بنجاح!");
        setTimeout(() => setLocation("/login"), 2500);
      } else {
        toast.error(data.error || "فشل إنشاء الحساب");
      }
    } catch {
      toast.error("حدث خطأ في الاتصال. حاول مرة أخرى.");
    } finally {
      setLoading(false);
    }
  };

  const passwordStrength = () => {
    if (password.length === 0) return null;
    if (password.length < 8) return { label: "ضعيفة", color: "text-red-400", width: "25%" };
    if (password.length < 12 && !/[A-Z]/.test(password)) return { label: "متوسطة", color: "text-yellow-400", width: "50%" };
    if (password.length >= 12 && /[A-Z]/.test(password) && /[0-9]/.test(password)) return { label: "قوية جداً", color: "text-green-400", width: "100%" };
    return { label: "جيدة", color: "text-amber-400", width: "75%" };
  };

  const strength = passwordStrength();

  if (checking) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0a0a0a]">
        <Loader2 className="h-8 w-8 animate-spin text-amber-400" />
      </div>
    );
  }

  return (
    <div
      className="min-h-screen flex items-center justify-center relative overflow-hidden"
      style={{ background: "linear-gradient(135deg, #0a0a0a 0%, #1a0f00 50%, #0a0a0a 100%)" }}
    >
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 rounded-full bg-amber-900/10 blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-96 h-96 rounded-full bg-amber-800/10 blur-3xl" />
      </div>

      <div className="relative z-10 w-full max-w-md px-4">
        {/* Header */}
        <div className="flex flex-col items-center mb-8">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-amber-700 to-amber-500 flex items-center justify-center shadow-2xl shadow-amber-900/50 mb-4 border-4 border-amber-400/30">
            <ShieldCheck className="h-10 w-10 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-amber-300 text-center" style={{ fontFamily: "'Amiri', serif" }}>
            طيب الحي للعود والأدهان
          </h1>
          <p className="text-amber-500/70 text-sm mt-1">الإعداد الأولي للنظام</p>
        </div>

        {done ? (
          <Card className="bg-black/60 border-amber-800/30 backdrop-blur-xl shadow-2xl">
            <CardContent className="pt-10 pb-10 px-6 flex flex-col items-center gap-4">
              <CheckCircle2 className="h-16 w-16 text-green-400" />
              <h2 className="text-xl font-bold text-green-300">تم إنشاء الحساب بنجاح!</h2>
              <p className="text-amber-400/70 text-sm text-center">
                سيتم توجيهك لصفحة تسجيل الدخول خلال ثوانٍ...
              </p>
              <Loader2 className="h-5 w-5 animate-spin text-amber-400" />
            </CardContent>
          </Card>
        ) : (
          <Card className="bg-black/60 border-amber-800/30 backdrop-blur-xl shadow-2xl">
            <CardHeader className="pb-2 pt-6 px-6">
              <h2 className="text-xl font-semibold text-amber-200 text-center">إنشاء حساب المدير</h2>
              <p className="text-amber-500/60 text-sm text-center mt-1">
                هذا الإعداد يتم مرة واحدة فقط عند أول تشغيل للنظام
              </p>
            </CardHeader>
            <CardContent className="px-6 pb-6">
              <form onSubmit={handleSetup} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-amber-300 text-sm">الاسم الكامل</Label>
                  <Input
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="اسم صاحب المحل"
                    className="bg-amber-950/20 border-amber-800/40 text-amber-100 placeholder:text-amber-700/50 focus:border-amber-500"
                    disabled={loading}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email" className="text-amber-300 text-sm">البريد الإلكتروني</Label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="example@email.com"
                    dir="ltr"
                    className="bg-amber-950/20 border-amber-800/40 text-amber-100 placeholder:text-amber-700/50 focus:border-amber-500"
                    disabled={loading}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password" className="text-amber-300 text-sm">كلمة المرور</Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="8 أحرف على الأقل"
                      dir="ltr"
                      className="bg-amber-950/20 border-amber-800/40 text-amber-100 placeholder:text-amber-700/50 focus:border-amber-500 pr-10"
                      disabled={loading}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-amber-600 hover:text-amber-400"
                      tabIndex={-1}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  {strength && (
                    <div className="space-y-1">
                      <div className="h-1 bg-amber-950/40 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-current rounded-full transition-all duration-300"
                          style={{ width: strength.width }}
                        />
                      </div>
                      <p className={`text-xs ${strength.color}`}>قوة كلمة المرور: {strength.label}</p>
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmPassword" className="text-amber-300 text-sm">تأكيد كلمة المرور</Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="أعد إدخال كلمة المرور"
                    dir="ltr"
                    className={`bg-amber-950/20 border-amber-800/40 text-amber-100 placeholder:text-amber-700/50 focus:border-amber-500 ${
                      confirmPassword && confirmPassword !== password ? "border-red-500/60" : ""
                    }`}
                    disabled={loading}
                  />
                  {confirmPassword && confirmPassword !== password && (
                    <p className="text-red-400 text-xs">كلمتا المرور غير متطابقتين</p>
                  )}
                </div>

                <Button
                  type="submit"
                  disabled={loading || (!!confirmPassword && confirmPassword !== password)}
                  className="w-full bg-gradient-to-r from-amber-700 to-amber-600 hover:from-amber-600 hover:to-amber-500 text-white font-semibold py-2.5 shadow-lg shadow-amber-900/30 transition-all duration-200 active:scale-[0.98] mt-2"
                >
                  {loading ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin ml-2" />
                      جاري الإنشاء...
                    </>
                  ) : (
                    <>
                      <ShieldCheck className="h-4 w-4 ml-2" />
                      إنشاء حساب المدير
                    </>
                  )}
                </Button>
              </form>

              <div className="mt-4 p-3 bg-amber-950/20 rounded-lg border border-amber-800/20">
                <p className="text-amber-500/70 text-xs text-center leading-relaxed">
                  بعد إنشاء حساب المدير، يمكنك إضافة موظفين من لوحة التحكم
                  وتحديد صلاحيات كل موظف بشكل مستقل
                </p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
