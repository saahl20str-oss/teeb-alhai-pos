import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import {
  TrendingUp,
  Package,
  ShoppingCart,
  AlertTriangle,
  Bell,
  ArrowLeft,
  DollarSign,
  BarChart3,
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function Dashboard() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const { data: settings } = trpc.shop.getSettings.useQuery();
  const currency = settings?.currencySymbol ?? "ريال";

  const { data: dayStats } = trpc.analytics.stats.useQuery({ period: "day" }, { enabled: isAdmin });
  const { data: monthStats } = trpc.analytics.stats.useQuery({ period: "month" }, { enabled: isAdmin });
  const { data: lowStock } = trpc.products.getLowStock.useQuery();
  const { data: notifications } = trpc.notifications.list.useQuery({ unreadOnly: false });
  const { data: recentSales } = trpc.sales.list.useQuery({ limit: 5 });
  const { data: inventoryValue } = trpc.analytics.inventoryValue.useQuery(undefined, { enabled: isAdmin });

  const markAllRead = trpc.notifications.markAllRead.useMutation({
    onSuccess: () => trpc.useUtils().notifications.list.invalidate(),
  });

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-amber-300" style={{ fontFamily: "'Amiri', serif" }}>
          لوحة التحكم
        </h1>
        <p className="text-muted-foreground text-sm mt-1">
          مرحباً، {user?.name} — {new Date().toLocaleDateString("ar-SA", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}
        </p>
      </div>

      {/* Stats cards */}
      {isAdmin && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="border-amber-800/30 bg-card">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <DollarSign className="w-8 h-8 text-amber-400 bg-amber-900/30 p-1.5 rounded-lg" />
                <span className="text-xs text-muted-foreground">اليوم</span>
              </div>
              <p className="text-2xl font-bold text-amber-300">{(dayStats?.totalRevenue ?? 0).toFixed(0)}</p>
              <p className="text-xs text-muted-foreground mt-1">{currency} مبيعات اليوم</p>
            </CardContent>
          </Card>

          <Card className="border-amber-800/30 bg-card">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <TrendingUp className="w-8 h-8 text-green-400 bg-green-900/30 p-1.5 rounded-lg" />
                <span className="text-xs text-muted-foreground">الشهر</span>
              </div>
              <p className="text-2xl font-bold text-green-300">{(monthStats?.totalRevenue ?? 0).toFixed(0)}</p>
              <p className="text-xs text-muted-foreground mt-1">{currency} مبيعات الشهر</p>
            </CardContent>
          </Card>

          <Card className="border-amber-800/30 bg-card">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <ShoppingCart className="w-8 h-8 text-blue-400 bg-blue-900/30 p-1.5 rounded-lg" />
                <span className="text-xs text-muted-foreground">الشهر</span>
              </div>
              <p className="text-2xl font-bold text-blue-300">{monthStats?.totalSales ?? 0}</p>
              <p className="text-xs text-muted-foreground mt-1">عملية بيع هذا الشهر</p>
            </CardContent>
          </Card>

          <Card className="border-amber-800/30 bg-card">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <Package className="w-8 h-8 text-purple-400 bg-purple-900/30 p-1.5 rounded-lg" />
                <span className="text-xs text-muted-foreground">المخزون</span>
              </div>
              <p className="text-2xl font-bold text-purple-300">{(inventoryValue?.sellingValue ?? 0).toFixed(0)}</p>
              <p className="text-xs text-muted-foreground mt-1">{currency} قيمة المخزون</p>
            </CardContent>
          </Card>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Low stock alerts */}
        <Card className="border-amber-800/30 bg-card">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2 text-amber-300">
                <AlertTriangle className="w-4 h-4 text-orange-400" />
                تنبيهات المخزون المنخفض
              </CardTitle>
              {(lowStock?.length ?? 0) > 0 && (
                <Badge className="bg-orange-900/50 text-orange-300 border-orange-700/50">
                  {lowStock?.length} منتج
                </Badge>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {!lowStock?.length ? (
              <p className="text-muted-foreground text-sm text-center py-4">✅ جميع المنتجات بمستوى جيد</p>
            ) : (
              <div className="space-y-2">
                {lowStock.slice(0, 5).map((product) => (
                  <div key={product.id} className="flex items-center justify-between p-2 rounded-lg bg-orange-900/10 border border-orange-800/30">
                    <div>
                      <p className="text-sm font-medium text-foreground">{product.name}</p>
                      <p className="text-xs text-muted-foreground">الكود: {product.code}</p>
                    </div>
                    <div className="text-left">
                      <Badge variant="destructive" className="text-xs">
                        {product.quantity} قطعة
                      </Badge>
                      <p className="text-xs text-muted-foreground mt-1">الحد: {product.lowStockThreshold}</p>
                    </div>
                  </div>
                ))}
                {(lowStock?.length ?? 0) > 5 && (
                  <Link href="/inventory">
                    <a className="text-xs text-amber-400 hover:underline block text-center mt-2">
                      عرض الكل ({lowStock.length})
                    </a>
                  </Link>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Notifications */}
        <Card className="border-amber-800/30 bg-card">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2 text-amber-300">
                <Bell className="w-4 h-4" />
                الإشعارات الأخيرة
              </CardTitle>
              {(notifications?.filter((n) => !n.isRead).length ?? 0) > 0 && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-xs text-amber-400 h-auto py-1"
                  onClick={() => markAllRead.mutate()}
                >
                  تحديد الكل كمقروء
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {!notifications?.length ? (
              <p className="text-muted-foreground text-sm text-center py-4">لا توجد إشعارات</p>
            ) : (
              <div className="space-y-2">
                {notifications.slice(0, 5).map((notif) => (
                  <div
                    key={notif.id}
                    className={cn(
                      "p-2 rounded-lg border text-sm",
                      notif.isRead
                        ? "border-border bg-muted/20 text-muted-foreground"
                        : "border-amber-700/40 bg-amber-900/10 text-foreground"
                    )}
                  >
                    <p className="font-medium text-xs">{notif.title}</p>
                    <p className="text-xs mt-0.5 opacity-80">{notif.message}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {new Date(notif.createdAt).toLocaleDateString("ar-SA")}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent sales */}
      <Card className="border-amber-800/30 bg-card">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base flex items-center gap-2 text-amber-300">
              <ShoppingCart className="w-4 h-4" />
              آخر المبيعات
            </CardTitle>
            <Link href="/invoices">
              <a className="text-xs text-amber-400 hover:underline flex items-center gap-1">
                عرض الكل <ArrowLeft className="w-3 h-3" />
              </a>
            </Link>
          </div>
        </CardHeader>
        <CardContent>
          {!recentSales?.length ? (
            <p className="text-muted-foreground text-sm text-center py-4">لا توجد مبيعات بعد</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border text-muted-foreground text-xs">
                    <th className="text-right pb-2 font-medium">رقم الفاتورة</th>
                    <th className="text-right pb-2 font-medium">العميل</th>
                    <th className="text-right pb-2 font-medium">الإجمالي</th>
                    <th className="text-right pb-2 font-medium">التاريخ</th>
                  </tr>
                </thead>
                <tbody className="space-y-1">
                  {recentSales.map((sale) => (
                    <tr key={sale.id} className="border-b border-border/50 hover:bg-muted/20">
                      <td className="py-2 text-amber-400 font-mono text-xs">{sale.invoiceNumber}</td>
                      <td className="py-2 text-muted-foreground">{sale.customerName ?? "—"}</td>
                      <td className="py-2 font-semibold text-green-400">{Number(sale.total).toFixed(2)} {currency}</td>
                      <td className="py-2 text-muted-foreground text-xs">
                        {new Date(sale.createdAt).toLocaleDateString("ar-SA")}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Quick actions */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <Link href="/pos">
          <a className="flex flex-col items-center gap-2 p-4 rounded-xl border border-amber-700/30 bg-amber-900/10 hover:bg-amber-900/20 transition-colors text-center">
            <ShoppingCart className="w-6 h-6 text-amber-400" />
            <span className="text-sm font-medium text-amber-300">بيع جديد</span>
          </a>
        </Link>
        <Link href="/inventory">
          <a className="flex flex-col items-center gap-2 p-4 rounded-xl border border-blue-700/30 bg-blue-900/10 hover:bg-blue-900/20 transition-colors text-center">
            <Package className="w-6 h-6 text-blue-400" />
            <span className="text-sm font-medium text-blue-300">إدارة المخزون</span>
          </a>
        </Link>
        <Link href="/invoices">
          <a className="flex flex-col items-center gap-2 p-4 rounded-xl border border-green-700/30 bg-green-900/10 hover:bg-green-900/20 transition-colors text-center">
            <BarChart3 className="w-6 h-6 text-green-400" />
            <span className="text-sm font-medium text-green-300">الفواتير</span>
          </a>
        </Link>
        {isAdmin && (
          <Link href="/analytics">
            <a className="flex flex-col items-center gap-2 p-4 rounded-xl border border-purple-700/30 bg-purple-900/10 hover:bg-purple-900/20 transition-colors text-center">
              <TrendingUp className="w-6 h-6 text-purple-400" />
              <span className="text-sm font-medium text-purple-300">الإحصائيات</span>
            </a>
          </Link>
        )}
      </div>
    </div>
  );
}
